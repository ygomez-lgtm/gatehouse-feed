/* Gatehouse 4.5.4 — Stage 2 candidate, bounded daily learning and source-reviewed timetable.
 * This module is deliberately loaded after pacing453.js and daily_progress44.js.
 * Existing saves / scores / XP remain unchanged until the hunter performs a real action.
 */
(()=>{'use strict';
 const C=window.ICPT_STAGE2_CORE,S=window.ICPT_SYSTEM,H=window.GH_STAGE2_HISTORY_C13,Pace=window.GH_STAGE2_READING_PACE_C13;
 if(!C||!S||typeof state==='undefined'||!window.ICPT_PACING453)return;
 const KEYS=C.KEYS;
 const names={checks:'Familiarity checks',learn:'New-word learning',first:'First delayed retrieval',due:'Spaced review'};
 const kinds={checks:'check',learn:'learn',first:'first',due:'due'};
 let importing=null,diagnostic=null,running=null,importJob=0,targetPending=false,assignmentPending=false,stageNotice=null;
 const identity=()=>JSON.stringify([state._save45?.profileId||'',state._save45?.epoch||'']);
 const owned=x=>!!x&&x.owner===identity()&&x.startedDate===localDay()&&day()===localDay();
 const knownWord=id=>typeof id==='string'&&Object.hasOwn(byId,id)&&!!byId[id]&&typeof byId[id]==='object';
 function assignmentFormat(record,d){
  if(!record||![1,2].includes(record.schema)||record.date!==d||![30,45,60].includes(record.budgetMinutes)||!KEYS.every(k=>Array.isArray(record[k])&&record[k].every(id=>typeof id==='string'))||new Set(KEYS.flatMap(k=>record[k])).size!==KEYS.reduce((sum,k)=>sum+record[k].length,0))return false;
  if(record.schema===1)return KEYS.every(k=>record[k].length<=C.limits(record.budgetMinutes)[k]);
  const q=record.quota,n=record.checks.length+record.learn.length;
  return !!q&&Number.isInteger(q.dailyQuota)&&q.dailyQuota>=0&&Number.isInteger(q.remainingCount)&&q.remainingCount>=0&&n<=q.dailyQuota&&q.dailyQuota<=q.remainingCount&&q.assignedVocabulary===n&&q.unavailableVocabulary===q.dailyQuota-n&&['first','due'].every(k=>record[k].length<=C.limits(record.budgetMinutes)[k]);
 }
 const e=esc;
 function vault(){const v=S.init();v.stage2 ||= {schema:1,days:{},durations:[],testouts:{},imports:[],recovery:{}};v.stage2.days ||= {};v.stage2.durations ||= [];v.stage2.testouts ||= {};v.stage2.imports ||= [];v.stage2.recovery ||= {};return v.stage2;}
 function queues(d=day()){
  const canonical=id=>typeof canonicalId==='function'?canonicalId(id):id;
  return Object.fromEntries(Object.entries({checks:checkQueue(d),learn:learnQueue(d),first:firstQueue(d),due:dueItems(d)}).map(([k,xs])=>[k,C.unique(xs.map(x=>canonical(x.id)))]));
 }
 function deadlineQuota(d=day()){
  const catalog=activeItems(),all=C.unique(catalog.map(x=>typeof canonicalId==='function'?canonicalId(x.id):x.id));
  let target=all,targetStatus='installed vocabulary planning target · finite source review pending',examDate=typeof EXAM==='string'?EXAM:null,dateStatus='unconfirmed legacy planning date',error='',pendingConfig=false;
  const review=state.v4?.stage2Completion?.calendarReview;
  if(review?.confirmed===true){if(C.dateParts(review.examDate)===null||review.examDate!==examDate){error='The saved issued exam date conflicts with the campaign configuration. Resolve the exam date in Settings; the deadline quota is unavailable.';examDate=null;dateStatus='conflicting saved exam date';}else dateStatus='learner-confirmed calendar · instructor acceptance pending';}
  const raw=state.v4?.stage2Completion?.campaignTargetJSON;
  if(raw!==undefined){
   const resolved=window.GH_STAGE2_COMPLETION?.currentTarget?.();
   if(resolved?.policy){target=resolved.policy.wordIds;targetStatus='saved reviewed finite campaign target';examDate=error?null:resolved.policy.exam;dateStatus=error?dateStatus:'saved reviewed target date · instructor acceptance pending';}
   else {pendingConfig=!window.GH_STAGE2_COMPLETION?.currentTarget;if(pendingConfig)targetPending=true;error=pendingConfig?'Loading the saved finite target; no assignment has been frozen.':resolved?.error||'Saved finite target is unavailable or unfamiliar. Keep a recovery backup and review its configuration in Settings.';examDate=null;targetStatus='saved target unavailable';}
  }
  const remainingIds=C.unique(target).filter(knownWord).filter(id=>!learningRec(id).learned&&!rec(id).seen&&!window.GH_REVIEW_WORKFLOW_R2?.isKnown(id));
  const q=C.deadlineQuota({date:d,examDate,startDate:START,remainingIds});
  return {...q,targetStatus,dateStatus,error,pendingConfig,targetCount:target.length,remainingIds,budgetMinutes:C.minutesBudget(state.settings.studyBudget454)};
 }
 function newPresetStage2(d) {
  const t=effectiveDailyCalendar46();
  if(!t.preset||Object.hasOwn(state.v4?.stage2?.days||{},d))return null;
  const raw=queues(d), reviews={...raw,checks:[],learn:[]};
  const hold=()=>({...C.allocate(d,reviews,state.settings.studyBudget454),preview:true,pendingConfig:true});
  if(!t.exam||!t.cutoff||state.v4?.stage2Completion?.campaignTargetJSON!==undefined||state.v4?.stage2Completion?.calendarReview?.confirmed===true)return hold();
  if(d>t.cutoff)return C.allocate(d,reviews,state.settings.studyBudget454);
  const next=window.GH_WEEKLY_SCHEDULE?.nextClass?.(d);
  const rows=next?.provisional===false&&Array.isArray(next.rows)?next.rows.filter(row=>!row.noClass):[];
  const chapters=new Set(rows.flatMap(row=>row.chapters||[]).filter(ch=>Number.isInteger(ch)&&ch>=t.range[0]&&ch<=t.range[1]));
  const mapped=new Set(rows.length&&rows.every(row=>row.mappingVerified===true)&&Array.isArray(next.vocabulary?.ids)?next.vocabulary.ids:[]);
  const pool=C.unique([...raw.checks,...raw.learn]).filter(id=>knownWord(id)&&effectiveDailyScope46(byId[id],t.range));
  // Use reviewed exact IDs first, scheduled chapters second, then the installed
  // default ICPT chapter scope. No lesson-date or page mappings are inferred.
  const tier=id=>mapped.has(id)?0:members(id).some(row=>row.bank==='core'&&chapters.has(row.chapter))?1:2;
  const ordered=pool.sort((a,b)=>tier(a)-tier(b));
  const target=C.unique(activeItems().filter(x=>effectiveDailyScope46(x,t.range)).map(x=>typeof canonicalId==='function'?canonicalId(x.id):x.id));
  const remainingIds=target.filter(knownWord).filter(id=>!learningRec(id).learned&&!rec(id).seen&&!window.GH_REVIEW_WORKFLOW_R2?.isKnown(id));
  const quota=C.deadlineQuota({date:d,examDate:addDays(t.cutoff,8),startDate:START,remainingIds});
  return C.allocateDeadline(d,{...reviews,checks:raw.checks.filter(id=>ordered.includes(id)),learn:raw.learn.filter(id=>ordered.includes(id))},state.settings.studyBudget454,{...quota,dailyQuota:quota.dailyQuota??0},ordered);
 }
 function proposalFor(d){const preset=newPresetStage2(d);if(preset)return preset;
  const q=deadlineQuota(d),raw=queues(d),targets=new Set(q.remainingIds),exposure=[...raw.checks,...raw.learn].filter(id=>targets.has(id));
  const ordered=S.sortLearning?S.sortLearning(exposure.map(id=>byId[id]),d).map(x=>x.id):exposure;
  const eligible=q.configured&&d>=START&&d<q.reviewStart&&d<=cutoff();
  const filtered={...raw,checks:eligible?raw.checks.filter(id=>targets.has(id)):[],learn:eligible?raw.learn.filter(id=>targets.has(id)):[]};
  // Invalid date configuration cannot create a new first-exposure assignment.
  return {...C.allocateDeadline(d,filtered,state.settings.studyBudget454,{...q,dailyQuota:q.dailyQuota??0},ordered),...(q.pendingConfig?{preview:true,pendingConfig:true}:{})};
 }
 function eligibleDay(d){return C.dateParts(d)!==null&&d>=START&&d<EXAM;}
 // Runtime-only: never mark a proposed assignment durable before readback.
 const snapshotJobs=new Map();
 function scheduleSnapshot(d,proposal){
  const owner=identity(),key=owner+'|'+d;
  let job=snapshotJobs.get(key);
  if(job)return {...proposal,preview:true,unsaved:job.phase==='failed',pendingSave:job.phase==='pending'};
  job={phase:'pending'};snapshotJobs.set(key,job);
  job.promise=(async()=>{
   const P=window.GH_PROGRESS45;
   try{
    if(P.getStatus?.()?.pending===true){if(typeof P.whenSettled!=='function')throw Error('Save settlement unavailable');await P.whenSettled();await Promise.resolve();}
    const status=P.getStatus?.();
    if(status?.ok!==true||status.ready!==true||status.pending||status.readError||status.reloadRequired)throw Error('Verified save state unavailable');
    if(identity()!==owner||localDay()!==d||day()!==d)throw Error('Assignment owner or date changed');
    if(Object.hasOwn(vault().days,d))throw Error('Assignment changed while waiting');
    const nextProposal=proposalFor(d);
    if(nextProposal.preview||nextProposal.pendingConfig||!assignmentFormat(nextProposal,d))throw Error('Assignment configuration unavailable');
    if(P.supportsExpectedRevision!==true)throw Error('Guarded durable save unavailable');
    const token=JSON.stringify(state),receipt=await P.readDurableAsync();
    if(identity()!==owner||JSON.stringify(state)!==token||localDay()!==d||day()!==d||receipt.profile?._save45?.revision!==state._save45?.revision)throw Error('Assignment preparation changed');
    const next=JSON.parse(token);
    next.v4.stage2.days[d]=nextProposal;
    const result=await P.commitAsync(next,{source:'stage2-assignment',expectedProfile:receipt.profile,expectedRevision:receipt.revision});
    if(!result?.ok)throw Error('Assignment save not verified');
    if(identity()!==owner)throw Error('Assignment owner changed after save');
    if(JSON.stringify(state)!==token){P.markUncommitted?.('Assignment snapshot saved; newer open changes remain unsaved. Keep this page open and reconcile before continuing.');throw Error('Newer open state preserved');}
    if(!result.state||JSON.stringify([result.state._save45?.profileId||'',result.state._save45?.epoch||''])!==owner||JSON.stringify(result.state.v4?.stage2?.days?.[d])!==JSON.stringify(nextProposal)){
     P.markUncommitted?.('Assignment save readback did not match. Keep this page open and reconcile before continuing.');throw Error('Assignment readback changed');
    }
    state=result.state;job.phase='saved';
   }catch(_){job.phase='failed';}
   // Failed or ambiguous writes are latched here, not retried by rendering.
   if(identity()===owner&&localDay()===d&&day()===d)render();
  })();
  return {...proposal,preview:true,pendingSave:true};
 }
 function snapshot(d=day()){
  const preset=effectiveDailyCalendar46();
  if(preset.preset){
   const existing=state.v4?.stage2?.days?.[d];
   if(assignmentFormat(existing,d)&&KEYS.every(k=>existing[k].every(knownWord)))return existing;
  }
  if(!(preset.preset?C.dateParts(d)!==null&&d>=START:eligibleDay(d)))return C.allocate(d,{checks:[],learn:[],first:[],due:[]},state.settings.studyBudget454);
  const v=vault(),prior=v.days[d];
  const valid=assignmentFormat(prior,d)&&KEYS.every(k=>prior[k].every(knownWord));
  if(valid)return prior;
  const proposal=proposalFor(d);
  if(proposal.pendingConfig)return proposal;
  // Keep unfamiliar/corrupt imported assignments intact until an explicit replan.
  if(Object.hasOwn(v.days,d))return {...proposal,preview:true,unusable:true};
  // The schedule adapter is loaded after this module. A fresh assignment must
  // wait for that adapter before freezing next-class priority into saved IDs.
  if(document.readyState==='loading'||window.GH457_STARTUP?.getState?.()?.ready===false){assignmentPending=true;return {...proposal,preview:true,pendingSchedule:true};}
  // View of another day is illustrative, not a historical claim or a backdated assignment.
  if(d!==localDay())return {...proposal,preview:true};
  if(typeof window.GH_PROGRESS45?.commitAsync==='function')return scheduleSnapshot(d,proposal);
  v.days[d]=proposal;if(save()===false){delete vault().days[d];return {...proposal,preview:true,unsaved:true};}return vault().days[d]||proposal;
 }
 // A replan is one explicit, transactional assignment replacement. The older
 // workflow first SAVED deletion of today's plan, then tried to build a new
 // plan. A second failed save could strand an empty required assignment and
 // erase the user's previously frozen card IDs. Never persist that gap.
 let stageActionPending=false;const stageActionBlocked=new Set();
 async function stageTransaction(change,guard=()=>true,verify=()=>true){
  const P=window.GH_PROGRESS45,who=identity(),date=localDay(),studyDate=day(),view=tab,token=JSON.stringify(state);
  if(stageActionPending||stageActionBlocked.has(who))return false;
  stageActionPending=true;let attempted=false;
  const still=()=>identity()===who&&localDay()===date&&day()===studyDate&&tab===view&&guard()&&JSON.stringify(state)===token;
  try{
   if(P.getStatus?.()?.pending){if(typeof P.whenSettled!=='function')throw Error('Save settlement unavailable');await P.whenSettled();await Promise.resolve();}
   const status=P.getStatus?.();if(status?.ok!==true||status.ready!==true||status.pending||status.readError||status.reloadRequired)throw Error('Verified save state unavailable');
   if(P.supportsExpectedRevision!==true)throw Error('Guarded durable save unavailable');
   const receipt=await P.readDurableAsync(),durable=receipt.profile;
   if(!still()||!durable||JSON.stringify([durable._save45?.profileId||'',durable._save45?.epoch||''])!==who||durable._save45.revision!==state._save45.revision)throw Error('The profile, date or reviewed selection changed');
   const next=JSON.parse(token);change(next);
   attempted=true;const result=await P.commitAsync(next,{source:'stage2-reviewed-action',expectedProfile:durable,expectedRevision:receipt.revision});
   if(!result?.ok)throw Error('Save not verified');
   if(!still())throw Error('The open work or selection changed during saving');
   if(!result.state||JSON.stringify([result.state._save45?.profileId||'',result.state._save45?.epoch||''])!==who||!verify(result.state,next))throw Error('Readback did not match the reviewed change');
   state=result.state;return true;
  }catch(error){
   if(attempted)stageActionBlocked.add(who);
   if(identity()===who){if(attempted)P.markUncommitted?.('Stage 2 save outcome is uncertain. Keep this page open and reconcile before continuing.');toast('The change could not be verified as saved. Current work was kept; retain a recovery backup.');}
   return false;
  }finally{stageActionPending=false;}
 }
 function recalculateToday(){
  const d=localDay(),owner=identity();
  if(day()!==d){toast('Return to today before recalculating the daily assignment.');return false;}
  if(document.readyState==='loading'||window.GH457_STARTUP?.getState?.()?.ready===false){
   toast('Wait for the current curriculum and class schedule to finish loading. The saved assignment was kept.');return false;
  }
  const proposed=proposalFor(d);
  if(proposed.pendingConfig||proposed.preview||!assignmentFormat(proposed,d)){
   toast('A valid reviewed vocabulary target is not ready. Your previous daily assignment was kept; check the source/calendar configuration.');return false;
  }
  if(typeof window.GH_PROGRESS45?.commitAsync==='function'){
   S.meter();const expected=JSON.stringify(proposed),fingerprint=x=>JSON.stringify(x,(k,v)=>k==='createdAt'?undefined:v);
   return stageTransaction(next=>{
    next.v4.stage2.days[d]=JSON.parse(expected);
    const meter=next.v4.rewardMeter[d],recorded=Object.entries(next.rpg?.awards||{}).filter(([k])=>k.startsWith(d+':')).reduce((n,[,v])=>n+Math.max(0,+v||0),0);
    const target=C.rewardLimit(proposed,{earned:Math.max(+meter.earned||0,recorded)});Object.assign(meter,target,{stage2Bounded:true});
   },()=>fingerprint(proposalFor(d))===fingerprint(proposed),(saved,next)=>JSON.stringify(saved.v4?.stage2?.days?.[d])===JSON.stringify(next.v4.stage2.days[d])&&JSON.stringify(saved.v4?.rewardMeter?.[d])===JSON.stringify(next.v4.rewardMeter[d])).then(ok=>{if(ok)render();return ok;});
  }
  const previous=vault(),had=Object.hasOwn(previous.days,d),original=previous.days[d];
  previous.days[d]=proposed;
  let persisted=false;
  try{persisted=save()===true&&identity()===owner;}catch(_){}
  if(!persisted){
   // Preserve any newer state installed by a concurrent save or profile
   // transition. Never roll an old hunter's assignment into a new profile.
   if(identity()===owner){const current=vault();if(current.days[d]===proposed){
    if(had)current.days[d]=original;else delete current.days[d];
   }}
   toast('The revised assignment could not be saved. Your previous plan and learning history were kept.');return false;
  }
  const confirmed=vault().days[d];
  if(!assignmentFormat(confirmed,d)){
   toast('The saved assignment changed while recalculating. Reopen today before using its card list.');return false;
  }
  boundedMeter(confirmed,true);render();return true;
 }
 function progressFor(k,id,d){const r=rec(id),l=learningRec(id),check=state.checks?.[id];
  // A recovery-day preview must never inherit proof created on a later day.
  // Undated legacy flags are insufficient evidence for historical completion.
  if(d<localDay())return !!H?.progress(k,r,l,check,d);
  if(k==='checks')return !!check||!!l.learned||!!r.seen;
  if(k==='learn')return !!l.learned||!!r.seen;
  if(k==='first')return !!r.firstRetrieved;
  if(k==='due')return !!r.lastDay&&r.lastDay>=d&&!!r.due&&r.due>d;
  return false;
 }
 function model(d=day()){
  const ss=snapshot(d),q=queues(d),extra=C.queueRemainder(ss,q),archive=S.init().dailyArchive?.[d]||{},an=state.animeBonus?.acknowledgments?.[d]||{},ack={...an,...archive};
  // Failed familiarity checks stay in this day's finite assignment and move to
  // guided learning. A checked-but-unknown word cannot satisfy the daily quota.
  const promoted=ss.schema===2?(ss.checks||[]).filter(id=>{
    const check=state.checks?.[id];
    const existedOnDay=d>=localDay()||!!(H?.validDay(check?.date)&&check.date<=d&&check.result==='needs-learning');
    return existedOnDay&&!!check&&!progressFor('learn',id,d);
  }):[];
  const rows=KEYS.map(k=>{const original=C.unique([...(ss[k]||[]),...(k==='learn'?promoted:[])]),excludedSelfKnown=['checks','learn'].includes(k)?original.filter(id=>window.GH_REVIEW_WORKFLOW_R2?.isKnown(id)):[],list=original.filter(id=>!excludedSelfKnown.includes(id)),remaining=list.filter(id=>!progressFor(k,id,d));const done=list.length-remaining.length;return {key:k,name:names[k],action:{checks:'start-check',learn:'start-learn',first:'start-first',due:'start-due'}[k],ids:list,total:list.length,done,remaining,excludedSelfKnown,complete:list.length>0&&remaining.length===0,ratio:list.length?done/list.length:null,overflow:extra[k].length};});
  for(const [key,name]of [['comprehension','Reading / listening task'],['speaking','Speaking practice']])rows.push({key,name,total:1,done:ack[key]?1:0,complete:!!ack[key],ratio:ack[key]?1:0,selfReported:true});
  const active=rows.filter(x=>x.total>0),completed=active.filter(x=>x.complete).length;
  const percent=active.length?Math.floor(100*active.reduce((a,x)=>a+(x.ratio||0),0)/active.length):0;
  return {date:d,snapshot:ss,rows,ack,percent,complete:completed,total:active.length,finished:active.length>0&&completed===active.length,preview:d!==localDay(),overflow:extra,quota:deadlineQuota(d)};
 }
 function workload(d=day()){
  const m=model(d),assigned=Object.fromEntries(KEYS.map(k=>[k,m.rows.find(r=>r.key===k).ids])),remaining=Object.fromEntries(KEYS.map(k=>[k,m.rows.find(r=>r.key===k).remaining]));
  return {...C.workload({assigned,remaining,backlog:queues(d),budget:state.settings.studyBudget454,comprehension:state.settings.studyComprehensionMinutes46,speaking:state.settings.studySpeakingMinutes46,ack:m.ack}),assignmentBudgetMinutes:m.snapshot.budgetMinutes,quota:m.quota,frozenQuota:m.snapshot.quota||null};
 }
 const prevDailyReady=S.dailyReady;
 S.dailyReady=function(){const d=localDay();if(!eligibleDay(d)||day()!==d)return {...prevDailyReady(),ready:false};const m=model(d);const counts=Object.fromEntries(m.rows.filter(x=>KEYS.includes(x.key)).map(x=>[x.key,x.remaining.length]));return {ready:m.finished&&!m.snapshot.preview&&!m.snapshot.unsaved&&!m.snapshot.unusable,counts,ack:m.ack,date:d,stage2:true,overflow:Object.fromEntries(KEYS.map(k=>[k,m.overflow[k].length]))};};
 const oldStart=startSession;
 // Accounting edits remain in the open profile for recovery even if storage fails.
 const accountingJobs=new Map(),accountingBlocked=new Set();
 function persistStageAccounting(){
  const P=window.GH_PROGRESS45;
  if(typeof P?.commitAsync!=='function')return save();
  const who=identity();
  if(accountingBlocked.has(who))return false;
  if(accountingJobs.has(who))return accountingJobs.get(who);
  const job=(async()=>{
   // Coalesce synchronous duration/meter edits made by the same render/action.
   await Promise.resolve();let attempted=false;
   try{
    if(P.getStatus?.()?.pending){if(typeof P.whenSettled!=='function')throw Error('Save settlement unavailable');await P.whenSettled();await Promise.resolve();}
    const status=P.getStatus?.();
    if(identity()!==who)return false;
    if(status?.ok!==true||status.ready!==true||status.pending||status.readError||status.reloadRequired)throw Error('Verified save state unavailable');
    if(P.supportsExpectedRevision!==true)throw Error('Guarded durable save unavailable');
    const token=JSON.stringify(state),receipt=await P.readDurableAsync();
    if(identity()!==who||JSON.stringify(state)!==token||receipt.profile?._save45?.revision!==state._save45?.revision)throw Error('Accounting preparation changed');
    const frozen=JSON.parse(token);
    attempted=true;const result=await P.commitAsync(frozen,{source:'stage2-accounting',expectedProfile:receipt.profile,expectedRevision:receipt.revision});
    if(identity()!==who){accountingBlocked.add(who);return false;}
    if(!result?.ok)throw Error('Accounting save not verified');
    if(JSON.stringify(state)!==token)throw Error('Newer open accounting or study edits remain unsaved');
    if(!result.state||JSON.stringify([result.state._save45?.profileId||'',result.state._save45?.epoch||''])!==who)throw Error('Accounting save owner changed');
    // Reconciliation may add other records, but must not drop captured durations.
    const recorded=result.state.v4?.stage2?.durations||[];
    const counts=new Map();for(const row of recorded){const k=JSON.stringify(row);counts.set(k,(counts.get(k)||0)+1);}
    for(const duration of frozen.v4?.stage2?.durations||[]){const k=JSON.stringify(duration),n=counts.get(k)||0;if(!n)throw Error('Duration readback incomplete');counts.set(k,n-1);}
    for(const [d,meter] of Object.entries(frozen.v4?.rewardMeter||{})){
     if(!meter?.stage2Bounded)continue;
     const savedMeter=result.state.v4?.rewardMeter?.[d];
     if(!savedMeter?.stage2Bounded||savedMeter.target!==meter.target||!Number.isFinite(savedMeter.cap)||!Number.isFinite(savedMeter.earned)||savedMeter.cap<Number(meter.cap)||savedMeter.earned<Number(meter.earned))throw Error('Reward meter readback incomplete');
    }
    state=result.state;return true;
   }catch(error){
    if(attempted)accountingBlocked.add(who);
    if(identity()===who){accountingBlocked.add(who);P.markUncommitted?.('Study accounting could not be verified. Current work remains open; export a recovery backup before leaving.');toast('Study accounting could not be verified. Current work was kept. Open Save & recovery before leaving.');}
    return false;
   }finally{accountingJobs.delete(who);}
  })();accountingJobs.set(who,job);return job;
 }
 function finishSession(){if(!running)return;const ended=running;running=null;if(!owned(ended))return;
  const seconds=Math.max(0,(Date.now()-ended.started)/1000),total=Math.round(seconds/60*10)/10;
  if(total>=0.1&&total<=180){const v=vault();v.durations.push({date:localDay(),minutes:total,kind:ended.kind,selected:ended.selected});persistStageAccounting();}
 }
 // A dashboard action always opens its stage, including a durable explanation
 // when no required cards can start. Never replace the frozen plan implicitly.
 function showStageStatus(kind,message){
  finishSession();stopSpeech();session=null;trainer=null;
  const key=kind==='check'?'checks':kind==='new'?'learn':kind;
  stageNotice={key,message,owner:identity(),date:day()};tab='recall';render();
  document.getElementById('stage2StartStatus')?.focus();return false;
 }
 const beforeStageStatus=renderRecall;
 renderRecall=function(...args){
  if(!stageNotice||trainer)return beforeStageStatus.apply(this,args);
  if(stageNotice.owner!==identity()||stageNotice.date!==day()){stageNotice=null;return beforeStageStatus.apply(this,args);}
  const n=stageNotice,m=model(day()),row=m.rows.find(r=>r.key===n.key);
  const ready=day()===localDay()&&!m.snapshot.preview&&!m.snapshot.unsaved&&!m.snapshot.unusable;
  const extra=ready?(m.overflow[n.key]||[]).length:0;
  const other=ready?m.rows.filter(r=>KEYS.includes(r.key)&&r.key!==n.key&&r.remaining.length):[];
  return heading(names[n.key]||'Daily practice','Your saved daily assignment and learning history are preserved.')+
   `<section class="card" id="stage2StartStatus" tabindex="-1" aria-label="Daily stage status"><h2>${e(n.message)}</h2>
   ${row?`<p>${row.done}/${row.total} assigned cards complete; ${row.remaining.length} remain in this stage.</p>`:''}
   ${n.key==='learn'&&!row?.remaining.length&&other.some(r=>r.key==='checks')?(m.snapshot.schema===2?'<p>Familiarity checks are still assigned. Words marked Needs learning will join today’s learning stage.</p>':'<p>Familiarity checks are still assigned. You can continue those below, or choose additional practice.</p>'):''}
   ${extra?`<p>${extra} eligible groups are outside today’s frozen assignment. You can choose an additional practice block without replacing it.</p><button type="button" data-stage2="extra" data-kind="${e(n.key)}">Start additional ${e(names[n.key].toLowerCase())} (${Math.min(15,extra)})</button>`:''}
   <div class="actions spacer">${other.map(r=>`<button type="button" data-stage2="stage" data-kind="${r.key}">${e(r.name)} (${r.remaining.length} remaining)</button>`).join('')}
   <button type="button" data-action="tab" data-tab="vocab">Choose a chapter to study</button>
   <button type="button" data-stage2="stage" data-kind="${e(n.key)}">Retry this stage</button>
   <button type="button" data-action="tab" data-tab="today">Return to dashboard</button>
   <button type="button" data-stage2="calendar">Review date and assignment settings</button></div>
   <p class="mini">Chapter study and additional practice are optional. Opening this screen does not mark any word learned, award XP, or recalculate the saved daily assignment. Date-preview and review-buffer restrictions still apply.</p></section>`;
 };
 startSession=function(kind,ids=null){
  stageNotice=null;
  if(day()!==localDay()){const message='This is a date preview. Return to today before starting practice; learning is never backdated.';if(!ids&&['check','learn','new','first','due'].includes(kind))return showStageStatus(kind,message);toast(message);return false;}
  if(ids||!['check','learn','new','first','due'].includes(kind))return oldStart(kind,ids);
  const key=kind==='check'?'checks':kind==='learn'||kind==='new'?'learn':kind;
  const m=model(day()),row=m.rows.find(r=>r.key===key),selected=row?.remaining||[];
  if(!selected.length&&!m.snapshot.preview&&!m.snapshot.unsaved&&!m.snapshot.unusable)return showStageStatus(kind,row?.total?'Today’s required '+names[key].toLowerCase()+' are complete.':row?.excludedSelfKnown?.length?'No required cards remain after your self-reported known-word choices.':'No '+names[key].toLowerCase()+' were included in today’s saved assignment.');
  if(m.snapshot.preview||m.snapshot.unsaved||m.snapshot.unusable){return showStageStatus(kind,m.snapshot.unusable?'The saved plan is unfamiliar or incomplete. Export a full backup, then explicitly recalculate this day before starting required sessions.':m.snapshot.pendingSave?'Saving assignment; not yet verified. Wait before starting required sessions.':m.snapshot.pendingConfig||m.snapshot.pendingSchedule?'The source target and class schedule are still loading. Wait for today’s plan to finish loading.':'The required plan could not be verified. Keep this page open and export a recovery backup; resolve the save state before starting.');}finishSession();running={started:Date.now(),startedDate:localDay(),owner:identity(),kind:key,selected:Math.min(15,selected.length)};const result=oldStart(kinds[key],selected);if(result===false)return showStageStatus(kind,'The saved cards are not currently eligible. Review the class date and protected review cutoff.');return result;
 };
 function optionalIds(k,d=day()){return C.queueRemainder(snapshot(d),queues(d))[k]||[];}
 function startOptional(k,subset=null){stageNotice=null;if(day()!==localDay()){toast('This is a date preview. Return to today before starting practice; learning is never backdated.');return;}if(!KEYS.includes(k))return;const ids=(subset||optionalIds(k)).filter(knownWord).filter(id=>hasIntroduced(id)||allowedDate(byId[id],localDay()));if(!ids.length){toast('No eligible optional items in this stage.');return;}finishSession();running={started:Date.now(),startedDate:localDay(),owner:identity(),kind:'optional-'+k,selected:Math.min(15,ids.length)};oldStart('selection',ids.slice(0,15));}
 function timeline(){const dates=C.reviewSteps(cutoff(),EXAM);return `<div class="sys-chips">${dates.map(x=>`<span class="badge ${'blue'}">+${x.daysAfter}: ${e(x.date)}${x.beforeExam?'':' · after test'}</span>`).join('')}</div>`;}
 function diagnosticHTML(){if(!owned(diagnostic)){diagnostic=null;return '';}if(state.active)return '<p class="mini">Diagnostic details are hidden while a mock is in progress. Finish or discard it to continue.</p>';
  const x=byId[diagnostic.id];if(!x){diagnostic=null;return '';}
  if(diagnostic.phase==='saving'||diagnostic.phase==='save-error')return `<section class="card" id="stage2Diagnostic" role="status"><h2>${diagnostic.phase==='saving'?'Saving diagnostic; not yet verified':'Diagnostic save could not be verified'}</h2><p>${diagnostic.phase==='saving'?'Wait for confirmation before continuing.':'Keep this page open and export a recovery backup before leaving. Do not resubmit the answer.'}</p></section>`;
  if(diagnostic.phase==='meaning')return `<section class="card" id="stage2Diagnostic" aria-label="Diagnostic test-out"><div class="eyebrow">Unassisted two-part familiarity diagnostic · 1/2</div><h2>What does this Arabic mean?</h2><div class="ar big" lang="ar" dir="rtl">${e(x.speech)}</div><div class="actions">${diagnostic.options.map((v,i)=>`<button type="button" data-stage2="meaning" data-index="${i}">${e(v)}</button>`).join('')}</div><p class="mini">No hints. This is a recognition check, not a reading proficiency score.</p><button data-stage2="cancel-testout">Cancel diagnostic</button></section>`;
  if(diagnostic.phase==='spelling')return `<section class="card" id="stage2Diagnostic" aria-label="Diagnostic test-out"><div class="eyebrow">Unassisted two-part familiarity diagnostic · 2/2</div><h2>Write the Arabic term</h2><p>${e(x.meaningDisplay)}</p><label>Arabic spelling<textarea id="stage2-testout-ar" lang="ar" dir="rtl" rows="2" placeholder="اكتب بالعربية"></textarea></label><div class="actions"><button type="button" data-stage2="finish-testout">Check my spelling</button><button type="button" data-stage2="cancel-testout">Cancel</button></div><p class="mini">Accepted spelling is matched to the original glossary form, ignoring optional vowel marks. Variants may require instructor review. This does not count as delayed recall.</p></section>`;
  return `<section class="card" id="stage2Diagnostic"><h2>${diagnostic.passed?'Diagnostic matched':'Return to guided learning'}</h2><p>${diagnostic.passed?'Both unassisted answers matched the supplied study entry. Tomorrow’s independent retrieval is still due.':'At least one answer did not match the supplied form. The item stays available for learning. This is not an exam score.'}</p><div class="ar" lang="ar">${e(x.speech)}</div><p>${e(x.meaningDisplay)}</p><button data-stage2="close-testout">Continue</button></section>`;
 }
 function diagnosticStart(){if(state.active){toast('Finish or discard the active mock before starting the diagnostic.');return;}if(day()!==localDay()||day()>cutoff()){toast('New vocabulary and test-out are unavailable during the review buffer or in date-preview mode.');return;}
  const pool=[...checkQueue(),...learnQueue()].filter(x=>!hasIntroduced(x.id)&&allowedDate(x));
  if(!pool.length){toast('There is no eligible unchecked vocabulary. Review the already introduced items instead.');return;}
  const x=pool[0];const incorrect=activeItems().filter(y=>y.id!==x.id&&y.meaningDisplay&&y.meaningDisplay!==x.meaningDisplay).slice(0,40);
  const mix=[x.meaningDisplay];for(const y of incorrect){if(mix.length>=4)break;if(!mix.includes(y.meaningDisplay))mix.push(y.meaningDisplay);}
  if(mix.length<2){toast('Not enough verified alternatives for a diagnostic. Use the guided word check.');return;}
  const index=x.id.split('').reduce((a,c)=>a+c.charCodeAt(0),0)%mix.length;
  diagnostic={id:x.id,owner:identity(),startedDate:localDay(),phase:'meaning',options:[...mix.slice(index),...mix.slice(0,index)],meaningCorrect:false,passed:false};render();}
 async function completedDiagnosticAsync(raw){
  const P=window.GH_PROGRESS45,who=identity(),selected=diagnostic,source=selected&&byId[selected.id],key=source&&canonicalId(source.id),date=localDay(),view=tab,token=JSON.stringify(state);
  if(stageActionPending||stageActionBlocked.has(who)||!owned(selected)||selected.phase!=='spelling'||!source)return false;
  stageActionPending=true;let attempted=false;
  const still=()=>identity()===who&&diagnostic===selected&&localDay()===date&&day()===date&&tab===view&&byId[selected.id]===source&&canonicalId(source.id)===key;
  try{
   if(P.getStatus?.()?.pending){if(typeof P.whenSettled!=='function')throw Error('Save settlement unavailable');await P.whenSettled();await Promise.resolve();}
   const status=P.getStatus?.();if(status?.ok!==true||status.ready!==true||status.pending||status.readError||status.reloadRequired)throw Error('Verified save state unavailable');
   const durable=(await P.readDurableAsync()).profile;
   if(!still()||JSON.stringify(state)!==token||!durable||JSON.stringify([durable._save45?.profileId||'',durable._save45?.epoch||''])!==who||durable._save45.revision!==state._save45.revision||state.active)throw Error('Diagnostic profile or source changed');
   if(window.GH_EXACT_ACTIVITY_GUARD?.check?.(typeof trainer==='undefined'?null:trainer)===false)throw Error('Learning activity guard refused this diagnostic');
   const spelled=spellingNorm(raw)===spellingNorm(source.speech),passed=selected.meaningCorrect&&spelled;
   const evidence={date,meaningCorrect:selected.meaningCorrect,spellingCorrect:spelled,passed,independent:true};
   selected.phase='saving';selected.passed=false;vault().testouts[key]=evidence;attempted=true;
   let ok=false;
   if(passed){if(markIntro(source)===false)throw Error('Introduction was refused');ok=await learnComplete(source);}
   else{state.checks ||= {};state.checks[key]={date,result:'needs-learning',source:'stage2-two-part-diagnostic'};ok=await window.GH_VOCAB_SAVE47?.flush?.();}
   if(ok!==true||!still())throw Error('Diagnostic save not verified');
   const stored=(await P.readDurableAsync()).profile;
   if(!still()||P.getStatus?.()?.ok!==true||JSON.stringify([stored?._save45?.profileId||'',stored?._save45?.epoch||''])!==who||JSON.stringify(stored?.v4?.stage2?.testouts?.[key])!==JSON.stringify(evidence)||JSON.stringify(state.v4?.stage2?.testouts?.[key])!==JSON.stringify(evidence))throw Error('Diagnostic evidence readback changed');
   if(passed&&(!stored.learning?.[key]?.learned||!stored.cards?.[key]?.seen))throw Error('Learning completion readback missing');
   selected.phase='result';selected.passed=passed;render();return true;
  }catch(error){
   if(attempted)stageActionBlocked.add(who);
   if(identity()===who){if(attempted)P.markUncommitted?.('Diagnostic save could not be verified. Keep current work open and export a recovery backup.');if(diagnostic===selected){selected.phase='save-error';selected.passed=false;render();}toast('Diagnostic save could not be verified. Current work was kept; do not resubmit this answer.');}
   return false;
  }finally{stageActionPending=false;}
 }
 function completedDiagnostic(raw){if(typeof window.GH_PROGRESS45?.commitAsync==='function')return completedDiagnosticAsync(raw);if(!owned(diagnostic)){diagnostic=null;toast('The open hunter or study date changed. Start a new diagnostic.');return;}if(diagnostic.phase!=='spelling')return;
  const x=byId[diagnostic.id];if(!x){diagnostic=null;toast('That source entry is no longer available.');return;}const spelled=spellingNorm(raw)===spellingNorm(x.speech),passed=diagnostic.meaningCorrect&&spelled;
  const v=vault();v.testouts[canonicalId(x.id)]={date:localDay(),meaningCorrect:diagnostic.meaningCorrect,spellingCorrect:spelled,passed,independent:true};
  if(passed){markIntro(x);learnComplete(x);}else{state.checks[canonicalId(x.id)]={date:localDay(),result:'needs-learning',source:'stage2-two-part-diagnostic'};save();}
  diagnostic.phase='result';diagnostic.passed=passed;render();}
 function boundedMeter(ss,recalculate=false){
  const meter=S.meter();
  if(eligibleDay(localDay())&&ss?.date===localDay()&&!ss.preview&&!ss.unsaved&&!ss.unusable&&(!meter.stage2Bounded||recalculate)){
   const recorded=Object.entries(state.rpg?.awards||{}).filter(([key])=>key.startsWith(localDay()+':')).reduce((sum,[,value])=>sum+Math.max(0,+value||0),0);
   const target=C.rewardLimit(ss,{earned:Math.max(+meter.earned||0,recorded)});meter.target=target.target;meter.cap=target.cap;meter.earned=target.earned;meter.stage2Bounded=true;persistStageAccounting();
  }
  // The durable commit can reconcile remote awards and replace state. Render its fresh meter.
  return S.meter();
 }
 function studyPanel(){const d=day(),m=model(d),w=workload(d),q=m.quota,dur=C.durationSummary(vault().durations),awardMeter=boundedMeter(m.snapshot),frozen=m.snapshot.quota;
  const required=m.rows.filter(x=>KEYS.includes(x.key)),assignedVocabulary=(m.snapshot.checks?.length||0)+(m.snapshot.learn?.length||0);
  return `<section class="card" id="stage2DailyPath"><div class="eyebrow">Stage 2 · deadline quota and finite daily assignment</div><h2>${e(w.budgetMinutes)}-minute total study budget · ${m.percent}% checkpoint progress</h2><p>${m.snapshot.unusable?'The saved plan is unfamiliar or incomplete and has been kept intact. Export a full backup, then explicitly recalculate this day; no vocabulary progress or XP has been reset.':m.snapshot.pendingSave?'Saving assignment; not yet verified. Required sessions will wait for confirmation.':m.snapshot.unsaved?'This assignment could not be verified. Keep this page open and export a recovery backup; resolve the save state before starting required sessions.':m.snapshot.pendingConfig||m.snapshot.pendingSchedule?'Loading the target and class schedule; the assignment is not yet frozen.':m.snapshot.preview?'This is an illustrative plan, not a saved assignment.':"Required cards were frozen when you first opened today's plan; previous saves, scores and word states were not reset."}</p>
  <div id="stage2DeadlineQuota" class="banner"><b>${q.configured?`${q.remainingCount} remaining target groups ÷ ${q.remainingDays} remaining study days = ${q.dailyQuota} groups/day`:'Deadline quota unavailable'}</b><p>${q.configured?`Exam planning date ${e(q.examDate)} · ${e(q.dateStatus)}. Finish new vocabulary <b>before ${e(q.reviewStart)}</b> (exam date minus 7 calendar days); the final seven days ${e(q.reviewStart)}–${e(C.addDays(q.examDate,-1))} are for review and practice. Today counts as one study day; weekends are self-study dates.`:e(q.error||'No valid target exam date is configured. Review the date in Settings; no exam date has been guessed.')}</p><p>Target: ${e(q.targetStatus)}. Canonical duplicates count once; next-class textbook groups take priority within this quota.</p>${q.deadlineMissed?`<p><b>New-learning deadline reached: ${q.remainingCount} groups remain unfinished.</b> No new vocabulary is assigned during the final review week or after the deadline.</p>`:''}${frozen?.unavailableVocabulary?`<p><b>Eligibility conflict: ${frozen.unavailableVocabulary} of the frozen ${frozen.dailyQuota}-group quota could not be assigned.</b> Future-release locks or the configured review buffer prevent full coverage; revise the source schedule or target. This gap is not complete or waived.</p>`:''}${m.snapshot.schema===1?`<p>Your existing daily assignment (${assignedVocabulary} first-exposure groups) has been preserved. The current deadline quota is ${q.dailyQuota??'unavailable'}; explicitly recalculate to replace the older fixed-card plan.</p>`:frozen?`<p>Frozen first-exposure quota: ${frozen.dailyQuota} · ${assignedVocabulary} assigned. The live remaining/day calculation above adapts as vocabulary is completed.</p>`:''}<button type="button" data-stage2="calendar">Review exam date / target in Settings</button></div>
  <div id="stage2WorkloadEstimate" class="banner"><b>Today’s finite assignment: ~${w.totalMinutes} minutes total</b> · ~${w.remainingTotalMinutes} minutes remaining. Cards ~${w.assignedMinutes} + comprehension ${w.comprehensionMinutes} + speaking ${w.speakingMinutes} minutes.${w.overBudgetMinutes?` <b>Estimated ${w.overBudgetMinutes} minutes above your ${w.budgetMinutes}-minute budget.</b> More time or a revised target/schedule is needed; the vocabulary quota has not been shortened.`:' This provisional estimate fits the configured total budget.'}<p class="mini">Per-card times and the editable comprehension/speaking reserves are planning assumptions, not verified syllabus requirements or calibrated student timing. Failed familiarity checks add guided learning. About 60 total minutes is provisional guidance; your saved budget remains ${w.budgetMinutes} minutes.</p></div>
  <div class="stats">${stat('Remaining target vocabulary',q.remainingCount+' / '+q.targetCount,'Unlearned canonical groups, including future releases')}${stat('Assigned first exposure',assignedVocabulary,'Finite set; failed checks continue into guided learning')}${stat('All eligible card queues','~'+w.backlogMinutes+' min','Total current backlog estimate, separate from today’s assignment')}${stat('Unassigned review due',m.overflow.first.length+m.overflow.due.length,'Still due; additional blocks remain available')}</div>
  <div class="pacing-grid453">${required.map(r=>`<div class="pacing-row453"><b>${e(r.name)}</b><span>${r.done}/${r.total} assigned · ${m.overflow[r.key].length} ${['first','due'].includes(r.key)?'additional due':'outside today’s finite set'}</span>${r.remaining.length?`<button type="button" data-stage2="stage" data-kind="${r.key}">Continue required block</button>`:''}${m.overflow[r.key].length?`<button type="button" data-stage2="extra" data-kind="${r.key}">Additional practice block</button>`:''}</div>`).join('')}</div>
  <p class="mini">XP earned today: ${awardMeter.earned} / ${awardMeter.cap} under the existing once-per-award-key and 2× bounded-day reward limit. Individual award keys are granted once per day; additional practice remains available without repeat XP.</p>
  <p class="mini">Legacy block records: ${dur.count}${dur.median===null?'':` · median ${dur.median} minutes`}. These include pauses and are not thirty complete workload measurements. Use Actual workload timing study for engaged-time evidence.</p>
  <p class="mini">A completed finite assignment does not mean the full vocabulary target, all due reviews, or exam readiness is complete. Unassigned review work stays due. Changing the budget keeps today’s saved IDs until you explicitly recalculate. Existing source release dates and stricter configured review buffers remain in force and any quota gap is displayed.</p>
  ${d===localDay()?'<button type="button" data-stage2="replan">Recalculate today’s required card set</button>':''}
  <div class="banner">Planned returns for a word first learned on ${e(cutoff())}: ${timeline()}<small>These are study target dates, not guaranteed completed retrievals or a modification of each word’s existing due-date algorithm.</small></div>
  <div class="actions"><button type="button" data-stage2="testout" ${reviewOnly()?'disabled':''}>Start two-part familiarity diagnostic</button><button type="button" data-stage2="schedule">Import next-class page schedule</button><button type="button" data-stage2="recovery">Missed-day recovery</button></div>
  ${diagnosticHTML()}</section>`;
 }
 // NEW-08: importing an instructor-reviewed CSV must be one owner-bound
 // schedule/history transaction. An exception or refused save must not leave
 // partially replaced dates or a false successful import in memory.
 function commitReviewedPageSchedule(preview){
  if(!owned(preview)||preview.valid!==true||!Array.isArray(preview.parsed)||!preview.parsed.length||preview.errors?.length){
   toast('The reviewed schedule is stale or incomplete. Preview the source file again.');return false;
  }
  const rows=preview.parsed,seen=new Set();
  for(const r of rows){
   const key=r?.date+':'+r?.chapter;
   if(!r||C.dateParts(r.date)===null||!Number.isInteger(r.chapter)||r.chapter<11||r.chapter>15||
      !Number.isInteger(r.from)||!Number.isInteger(r.to)||r.from<1||r.to<r.from||r.to>100||
      seen.has(key)||typeof r.source!=='string'){
    toast('The reviewed schedule changed after preview. Re-import the exact source before applying.');return false;
   }
   seen.add(key);
  }
  const v=S.init(),stage=vault();
  if(!Array.isArray(v.pageSchedule)||!Array.isArray(stage.imports)){
   toast('Saved class schedule history is unfamiliar. Export a recovery backup; no rows were replaced.');return false;
  }
  const owner=identity(),previousSchedule=v.pageSchedule,previousImports=stage.imports;
  const nextSchedule=previousSchedule.filter(r=>!seen.has(r.date+':'+r.chapter))
   .concat(rows.map(r=>({...r,confirmed:true})))
   .sort((a,b)=>a.date.localeCompare(b.date)||a.chapter-b.chapter);
  const nextImports=previousImports.concat([{appliedAt:new Date().toISOString(),rows:rows.length,source:'manually-verified CSV import'}]);
  if(typeof window.GH_PROGRESS45?.commitAsync==='function'){
   const selected=importing,previewToken=JSON.stringify(importing);
   return stageTransaction(next=>{next.v4.pageSchedule=nextSchedule;next.v4.stage2.imports=nextImports;},()=>importing===selected&&JSON.stringify(importing)===previewToken,(saved,next)=>JSON.stringify(saved.v4?.pageSchedule)===JSON.stringify(next.v4.pageSchedule)&&JSON.stringify(saved.v4?.stage2?.imports)===JSON.stringify(next.v4.stage2.imports)).then(ok=>{if(ok){importing=null;render();}return ok;});
  }
  v.pageSchedule=nextSchedule;stage.imports=nextImports;
  let persisted=false;
  try{persisted=save()===true&&identity()===owner&&day()===localDay();}catch(_){}
  if(!persisted){
   if(identity()===owner){
    const current=S.init(),history=vault();
    if(current.pageSchedule===nextSchedule)current.pageSchedule=previousSchedule;
    if(history.imports===nextImports)history.imports=previousImports;
   }
   toast('Reviewed schedule was not saved. Prior dates and import history were kept; retry after a backup.');return false;
  }
  importing=null;render();return true;
 }
 // NEW-08: a moved/withdrawn class assignment must be removable without
 // silently deleting another date, changing frozen vocabulary or creating
 // a successful-looking import history when storage refuses the save.
 function removeReviewedPageSchedule(review){
  if(!owned(review)||C.dateParts(review.date)===null||
     !Number.isInteger(review.chapter)||review.chapter<11||review.chapter>15){
   toast('The schedule selection is stale. Reopen class schedule for the current hunter.');return false;
  }
  const v=S.init(),stage=vault();
  if(!Array.isArray(v.pageSchedule)||!Array.isArray(stage.imports)){
   toast('Saved schedule or import history is unfamiliar. Export a recovery backup before editing.');return false;
  }
  const matches=v.pageSchedule.filter(r=>r?.date===review.date&&r?.chapter===review.chapter);
  if(matches.length!==1||matches[0]!==review.expectedRecord||matches[0].confirmed!==true){
   toast('That reviewed class row changed. Reopen the schedule; no rows were removed.');return false;
  }
  const owner=identity(),previousSchedule=v.pageSchedule,previousImports=stage.imports;
  const nextSchedule=previousSchedule.filter(r=>r!==matches[0]);
  const nextImports=previousImports.concat([{appliedAt:new Date().toISOString(),rows:0,
    removedDate:review.date,removedChapter:review.chapter,source:'owner-confirmed schedule row removal'}]);
  if(typeof window.GH_PROGRESS45?.commitAsync==='function'){
   return stageTransaction(next=>{next.v4.pageSchedule=nextSchedule;next.v4.stage2.imports=nextImports;},()=>owned(review)&&S.init().pageSchedule.some(r=>r===review.expectedRecord),(saved,next)=>JSON.stringify(saved.v4?.pageSchedule)===JSON.stringify(next.v4.pageSchedule)&&JSON.stringify(saved.v4?.stage2?.imports)===JSON.stringify(next.v4.stage2.imports)).then(ok=>{if(ok){importing=null;render();}return ok;});
  }
  v.pageSchedule=nextSchedule;stage.imports=nextImports;
  let persisted=false;
  try{persisted=save()===true&&identity()===owner&&day()===localDay();}catch(_){}
  if(!persisted){
   if(identity()===owner){
    const current=S.init(),history=vault();
    if(current.pageSchedule===nextSchedule)current.pageSchedule=previousSchedule;
    if(history.imports===nextImports)history.imports=previousImports;
   }
   toast('Row removal was not saved. The reviewed assignment and history were kept.');return false;
  }
  importing=null;render();return true;
 }
 function schedulePanel(){if(!owned(importing))importing=null;const raw=S.init().pageSchedule,timetable=Array.isArray(raw)?raw:[];return `<section class="sys-panel" id="stage2Schedule"><h2>Class schedule · reviewed CSV import</h2><p>Upload a CSV containing <code>date,chapter,first_page,last_page</code> for Chapters 11–15. A preview appears before anything changes. Instructor files in PDF/Word format must first be transcribed/verified; they are <b>not</b> automatically trusted or imported here.</p>${raw!==undefined&&!Array.isArray(raw)?'<p class="banner warn">Saved timetable is unfamiliar; export a recovery backup before editing. Original data was retained.</p>':''}<div class="actions"><input type="file" accept=".csv,text/csv" id="stage2ScheduleFile" aria-label="Class schedule CSV"><button type="button" data-stage2="template">Download CSV template</button></div>
 ${importing?`<div class="banner ${importing.valid?'':'warn'}"><b>${importing.parsed.length} candidate class-page assignments</b> · ${importing.errors.length} errors${importing.errors.length?`<ul>${importing.errors.slice(0,8).map(x=>'<li>'+e(x)+'</li>').join('')}</ul>`:''}</div>${importing.valid?`<div class="tablewrap"><table><thead><tr><th>Date</th><th>Chapter</th><th>Printed pages</th><th>Source supplied in CSV</th></tr></thead><tbody>${importing.parsed.map(r=>`<tr><td>${e(r.date)}</td><td>${r.chapter}</td><td>${r.chapter}.${r.from}–${r.chapter}.${r.to}</td><td>${e(r.source)}</td></tr>`).join('')}</tbody></table></div><label class="checkline"><input type="checkbox" id="stage2VerifySchedule"> I compared these dates and page numbers with the posted class timetable.</label><button data-stage2="apply-schedule">Apply reviewed page assignments</button>`:''}`:''}
 ${timetable.length?`<div class="tablewrap"><table><thead><tr><th>Saved date</th><th>Chapter</th><th>Printed pages</th><th>Reviewed removal</th></tr></thead><tbody>${timetable.map(r=>`<tr><td>${e(r?.date||'Unknown')}</td><td>${e(String(r?.chapter||'?'))}</td><td>${e(String(r?.from||'?'))}–${e(String(r?.to||'?'))}</td><td><button type="button" data-stage2="remove-schedule" data-date="${e(r?.date||'')}" data-chapter="${e(String(r?.chapter||''))}" ${r?.confirmed===true?'':'disabled'}>Remove this reviewed row</button></td></tr>`).join('')}</tbody></table></div>`:'<p>No reviewed class rows saved for this hunter yet.</p>'}
 <p class="mini">Current assignments: ${timetable.length}. Matching page numbers prioritize tomorrow’s textbook vocabulary; the ${Object.keys(window.ICPT_PAGE_MAP||{}).length} mapped word-page candidates are not all independently teacher verified. Existing dates are never removed silently; a matching date/chapter is replaced only after review. A previously frozen today-plan stays intact until you explicitly use Recalculate today's required card set.</p></section>`;}
 function readingPanel(){const xs=Pace?.summary(state.attempts||[])||[];
  return `<section class="sys-panel" id="stage2ReadingPace"><h2>Timed reading pacing · diagnostic trend</h2>${xs.length?`<div class="tablewrap"><table><thead><tr><th>Date</th><th>Elapsed minutes</th><th>Saved answers</th><th>Unanswered</th><th>Elapsed seconds / saved answer</th></tr></thead><tbody>${xs.map(a=>a.available?`<tr><td>${e(a.date)}</td><td>${a.elapsedMinutes}</td><td>${a.answered} / ${a.total}</td><td>${a.unanswered} / ${a.total}</td><td>${a.elapsedPerAnswer===null?'—':a.elapsedPerAnswer}<br><small>${e(a.note)}</small></td></tr>`:`<tr><td>${e(a.date)}</td><td colspan="4">${e(a.reason)}</td></tr>`).join('')}</tbody></table></div>`:'<p>No timed reading mocks with verifiable saved question IDs and elapsed time yet.</p>'}<p class="mini">The elapsed/answered figure includes all time spent in the mock, including time spent on skipped questions; it is not a per-question stopwatch. Unanswered counts use the saved question identities, not unrelated imported answer keys or a guessed 32-question denominator. Practice timings are not official exam limits. Use Reading &amp; transcription for source-bound digit, letter, tagged-name and omission comparisons; these spelling diagnostics do not certify Arabic audio or proficiency.</p></section>`;}
 function historicalAssignment(d,record){
  if(!assignmentFormat(record,d))return {valid:false,ids:[],missing:[],pending:[],available:[]};
  const ids=[...new Set(KEYS.flatMap(k=>record[k]))],known=ids.filter(knownWord),missing=ids.filter(id=>!knownWord(id));
  const pending=known.filter(id=>!hasIntroduced(id)||rec(id).due<=localDay());
  const available=pending.filter(id=>hasIntroduced(id)||allowedDate(byId[id],localDay()));
  // Counts are stage checkpoints, not unique words: one word can have an
  // assigned learning stage and later separate retrieval. Never backdate XP.
  const dated=H?.summary(record,Object.fromEntries(known.map(id=>[id,{
    card:rec(id),learning:learningRec(id),check:state.checks?.[id]
  }])),d);
  return {valid:true,ids,missing,pending,available,dated};
 }
 function recoveryPanel(){
  const original=state.v4?.stage2?.days||{},history=Object.keys(original).filter(d=>d<localDay()).sort().reverse().slice(0,12);
  return `<section class="sys-panel" id="stage2Recovery"><h2>Historical assignments · safe make-up</h2><p>Past days remain marked as missed when applicable. Completing their material today creates current-day evidence and is not credited to the old calendar date. Extra practice does not bypass the configured ${e(cutoff())} new-learning cutoff.</p>${history.length?`<div class="tablewrap"><table><thead><tr><th>Original date</th><th>Original-date evidence</th><th>Work today</th></tr></thead><tbody>${history.map(d=>{const info=historicalAssignment(d,original[d]);if(!info.valid)return `<tr><td>${e(d)}</td><td>Saved assignment unavailable: unfamiliar or incomplete record. Original data retained.</td><td><button type="button" disabled>Unavailable saved assignment</button></td></tr>`;return `<tr><td>${e(d)}</td><td>${info.dated?`${info.dated.completed}/${info.dated.total} dated stage checkpoints · ${info.dated.outstanding} without original-date evidence`:'Original-date evidence checker unavailable'}<br>${info.ids.length} unique groups · ${info.pending.length} may need work now${info.missing.length?` · ${info.missing.length} unavailable entries preserved`:''}</td><td><button data-stage2="makeup" data-date="${e(d)}" ${info.available.length?'':'disabled'}>Practice eligible known cards (${info.available.length})</button></td></tr>`;}).join('')}</tbody></table></div>`:'<p>No Stage 2 daily snapshots have reached a past date yet. The original recovery board remains available.</p>'}<p class="mini">Dated stage evidence is distinct from new work done afterward. Unknown or undated legacy flags are not treated as completed old days; original records remain untouched. These counts never grant XP, mastery, or retrospective completion. Past acknowledgments already in your save are preserved.</p></section>`;
 }
 const oldRecovery=S.renderers?.recovery;
 if(oldRecovery)S.renderers.recovery=function(){return oldRecovery()+recoveryPanel();};
 const previousToday=renderToday;renderToday=function(){return previousToday()+studyPanel();};
 const previousSettings=renderSettings;renderSettings=function(){return previousSettings()+schedulePanel();};
 const previousProgress=renderProgress;renderProgress=function(){return previousProgress()+readingPanel();};
 const priorRender=render;render=function(){priorRender();if(running&&(!trainer||tab!=='recall'))finishSession();};
 document.addEventListener('click',async ev=>{const z=ev.target.closest('[data-stage2]');if(!z||z.disabled)return;ev.preventDefault();const act=z.dataset.stage2,k=z.dataset.kind;
  if(act==='stage'){if(window.GH_DASHBOARD_WORDS_R4?.openRequired){ev.stopImmediatePropagation();window.GH_DASHBOARD_WORDS_R4.openRequired(k);return;}startSession(kinds[k]);return;}
  if(act==='extra'){startOptional(k);return;}
  if(act==='replan'){if(day()!==localDay())return;if(!confirm('Replace only today’s bounded assignment list? Completed learning, earned XP and saved scores will stay unchanged. The visible required cards can change.'))return;recalculateToday();return;}
  if(act==='testout'){diagnosticStart();return;}
  if(act==='meaning'){if(!owned(diagnostic)){diagnostic=null;toast('The open hunter or study date changed. Start a new diagnostic.');return;}if(diagnostic.phase!=='meaning')return;const x=byId[diagnostic.id];diagnostic.meaningCorrect=diagnostic.options[Number(z.dataset.index)]===x.meaningDisplay;diagnostic.phase='spelling';render();return;}
  if(act==='finish-testout'){completedDiagnostic(document.getElementById('stage2-testout-ar')?.value||'');return;}
  if(act==='close-testout'||act==='cancel-testout'){diagnostic=null;render();return;}
  if(act==='schedule'){go('settings');document.getElementById('stage2Schedule')?.scrollIntoView({block:'center'});return;}
  if(act==='calendar'){go('settings');document.getElementById('stage2AssessmentEvidence')?.scrollIntoView({block:'center'});return;}
  if(act==='recovery'){go('recovery');return;}
  if(act==='makeup'){
   const from=z.dataset.date;if(C.dateParts(from)===null||from>=localDay()){toast('Make-up practice is available only for an earlier saved day.');return;}
   const info=historicalAssignment(from,vault().days[from]);if(!info.valid){toast('That saved assignment is unavailable and was kept intact. Export a full backup before changing content packs.');return;}
   if(!info.available.length){toast('No known eligible items remain for make-up practice today. Unavailable entries were preserved.');return;}
   const oldHistory=vault().recovery[from];if(oldHistory!==undefined&&!Array.isArray(oldHistory)){toast('The saved make-up history is unfamiliar and was kept intact. Export a full backup before continuing.');return;}
   if(typeof window.GH_PROGRESS45?.commitAsync==='function'){
    const record=vault().days[from],recordToken=JSON.stringify(record),eligible=JSON.stringify(info.available);
    const ok=await stageTransaction(next=>{next.settings.studyDate='';next.v4.stage2.recovery[from] ||= [];next.v4.stage2.recovery[from].push({openedOn:localDay(),count:Math.min(15,info.available.length)});},()=>JSON.stringify(vault().days[from])===recordToken&&JSON.stringify(historicalAssignment(from,vault().days[from]).available)===eligible,(saved,next)=>saved.settings?.studyDate===''&&JSON.stringify(saved.v4?.stage2?.recovery?.[from])===JSON.stringify(next.v4.stage2.recovery[from]));
    if(ok)startOptional('due',info.available);return;
   }
   const previousDate=state.settings.studyDate;state.settings.studyDate='';if(save()===false){state.settings.studyDate=previousDate;toast('The current study date could not be saved. Keep a progress backup and retry.');return;}
   const previousHistory=oldHistory===undefined?undefined:JSON.parse(JSON.stringify(oldHistory));vault().recovery[from] ||= [];vault().recovery[from].push({openedOn:localDay(),count:Math.min(15,info.available.length)});
   if(save()===false){if(previousHistory===undefined)delete vault().recovery[from];else vault().recovery[from]=previousHistory;toast('Make-up practice could not be saved. Keep a progress backup and retry.');return;}
   startOptional('due',info.available);return;
  }
  if(act==='template'){const csv='date,chapter,first_page,last_page,source\n2026-10-27,12,15,28,Example only - replace with actual verified class assignment\n';const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='gatehouse_class_schedule_template.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);return;}
  if(act==='apply-schedule'){if(!owned(importing)){importing=null;toast('The open hunter or study date changed. Preview the schedule again.');return;}if(!importing.valid)return;if(!document.getElementById('stage2VerifySchedule')?.checked){toast('Verify the proposed class pages against your posted schedule before applying.');return;}if(!confirm('Apply '+importing.parsed.length+' reviewed timetable rows? Existing words, progress and scores are preserved.'))return;
   commitReviewedPageSchedule(importing);return;}
  if(act==='remove-schedule'){
   if(day()!==localDay()){toast('Return to today to edit saved class assignments.');return;}
   const date=z.dataset.date,chapter=Number(z.dataset.chapter),v=S.init();
   const matches=Array.isArray(v.pageSchedule)?v.pageSchedule.filter(r=>r?.date===date&&r?.chapter===chapter):[];
   if(C.dateParts(date)===null||!Number.isInteger(chapter)||matches.length!==1||matches[0].confirmed!==true){
    toast('The reviewed row is unavailable or changed. Nothing was deleted.');return;
   }
   const review={date,chapter,owner:identity(),startedDate:localDay(),expectedRecord:matches[0]};
   if(!confirm('Remove only Chapter '+chapter+' on '+date+' from this hunter’s class timetable? The row will remain unchanged if saving fails. Frozen daily cards, XP and Army are untouched.'))return;
   removeReviewedPageSchedule(review);return;
  }
 },true);
 document.addEventListener('change',async ev=>{if(ev.target.id!=='stage2ScheduleFile')return;const file=ev.target.files?.[0];if(!file)return;
  const request=++importJob,owner=identity(),startedDate=localDay();importing=null;render();let timer;
  try{if(file.size>150000)throw Error('CSV exceeds the 150 KB limit.');
   const text=await Promise.race([file.text(),new Promise((resolve,reject)=>{timer=setTimeout(()=>reject(Error('Schedule reading timed out. Select the file again.')),15000);})]);
   if(request!==importJob||owner!==identity()||startedDate!==localDay())return;
   importing={...C.parseScheduleCSV(text,{start:START,end:addDays(EXAM,-1),chapterMin:11,chapterMax:15}),owner,startedDate};
  }catch(error){if(request!==importJob||owner!==identity()||startedDate!==localDay())return;importing={valid:false,parsed:[],errors:[String(error.message||error)],owner,startedDate};}
  finally{clearTimeout(timer);}render();
 });
 document.addEventListener('click',ev=>{if(ev.target.closest('[data-v3="end-trainer"]'))finishSession();},true);
 // Do not award late work as though it had been completed on the original calendar day.
 document.addEventListener('change',ev=>{const z=ev.target;if(!z.matches('[data-archive]')||z.dataset.date===localDay())return;ev.stopImmediatePropagation();const old=S.init().dailyArchive[z.dataset.date];z.checked=!!old?.[z.dataset.archive];toast('Historical completion cannot be backdated. Practice the assigned material today using Missed-day recovery.');},true);
 window.ICPT_STAGE2={snapshot,model,deadlineQuota,workload,eligibleDay,queues,optionalIds,progressFor,diagnosticStart,startOptional,parseScheduleCSV:C.parseScheduleCSV};
 document.addEventListener('DOMContentLoaded',()=>{if((assignmentPending||targetPending&&window.GH_STAGE2_COMPLETION?.currentTarget)&&tab==='today'){targetPending=false;assignmentPending=false;render();}},{once:true});
 render();
})();
