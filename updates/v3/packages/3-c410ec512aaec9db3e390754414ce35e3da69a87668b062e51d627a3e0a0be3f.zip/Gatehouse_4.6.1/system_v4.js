/* Pure entry balance; never writes rank, vocabulary, reward or save state. */
(()=>{'use strict';const order='EDCBAS',floors=[1,20,40,60,80,95];
function evaluate(rank,hunter,army,requirement){const i=order.indexOf(rank),hi=order.indexOf(hunter?.rank);if(i<0||!requirement)return {allowed:false,reason:'Unknown gate rank.'};
const skill=Number(army?.skill)||0,supported=Number(army?.total)>=requirement.min&&Number(army?.effective)>=requirement.power&&skill>=requirement.skill;
if(supported)return {allowed:true,route:'supported',objectives:requirement.questions,damage:15,timeMultiplier:1,reason:'Shadows support the standard route.'};
const level=Number(hunter?.level),qualified=Number.isInteger(level)&&level>=floors[hi]&&level<=100&&hi>i&&skill>=requirement.skill;
if(!qualified)return {allowed:false,reason:'Bring the required Shadow support, or earn a higher hunter rank and the required measured skill for an unsupported lower-rank gate.'};
return {allowed:true,route:'unsupported',objectives:Math.ceil(requirement.questions*1.4),damage:20,timeMultiplier:1.4,reason:'Higher-rank solo entry: no minimum Shadows. More objectives and higher damage without full support.'};}
window.GH_SOLO_ENTRY_POLICY=Object.freeze({evaluate,version:1});})();

/* Gatehouse v4: evidence-based status, local settings and curriculum-safe expansion. */
(() => {
'use strict';
if (!window.ICPT_V3) return;
const A=window.ICPT_ARCADE_DATA, M=window.ICPT_PAGE_MAP||{}, LIB=window.ICPT_SUPPLEMENTARY||[];
const e=esc, clamp=(x,a,b)=>Math.max(a,Math.min(b,x)), modes=['R','L','S','TE','TA','T'];
const rankBands=[['E',1],['D',20],['C',40],['B',60],['A',80],['S',95]];
let libraryFilter={unit:'all',kind:'all',search:'',page:0}, activeSeconds=0, lastInput=Date.now(), hiddenSince=0, focusWarning=false;
let musicContext=null,musicGain=null,musicNodes=[],musicTimer=null,musicStep=0,duckUntil=0,masterVolume=.12, toastTimer,musicTrack=null;
function init(profile=state){
 profile.v4 ||= {};const v=profile.v4;
 v.version='4.1';v.settings ||= {motion:true,music:false,sfx:false,strictFocus:false};v.avatar ||= {skin:'warm',hair:'short',armor:'scout',weapon:'blade',accent:'cyan'};
 v.rewardMeter ||= {};v.dailyArchive ||= {};v.requiredSnapshots ||= {};v.milestones ||= {};v.topicReady ||= {};
 v.pageSchedule ||= [{date:'2026-10-21',chapter:11,from:2,to:10,confirmed:true},{date:'2026-10-22',chapter:11,from:11,to:28,confirmed:true},{date:'2026-10-23',chapter:12,from:2,to:14,confirmed:true}];
 v.pageOverrides ||= {};v.selectedCatchup ||= localDay();v.campaignClaimed ||= false;
 v.arcade ||= {history:[],itemStats:{},awards:{},repairs:[],unlocked:{},best:{},topicReady:{}};
 v.solo ||= {history:[],best:{}};
 v.recognition ||= {events:[]};
 profile.animeBonus ||= {version:1,seenEpisode:9,nextEpisode:10,history:[],firstAttempts:{},custom:[],acknowledgments:{}};
 if(!v.episodeMigrated){if(!profile.animeBonus.seenEpisode&&!profile.animeBonus.history?.length){profile.animeBonus.seenEpisode=9;profile.animeBonus.nextEpisode=10;}v.episodeMigrated=true;}
 return v;
}
const V=init();V.settings.music=false; // Browsers require a fresh user gesture for sound after loading.

function b(act,label,extra='',cls=''){return `<button type="button" data-system="${act}" ${extra} class="${cls}">${label}</button>`;}
function notify(title,text,modal=false){
 if(window.GH_NOTICES45&&(/Gate cleared|Chamber cleared|Recovery recommended/.test(title))){GH_NOTICES45.record('system:'+title+':'+Date.now(),title,text,/cleared/i.test(title)?'gate':'system');return;}
 if(!modal){let n=document.getElementById('systemToast');if(!n){n=document.createElement('div');n.id='systemToast';n.className='sys-toast';n.setAttribute('role','status');document.body.append(n);}n.innerHTML=`<b>${e(title)}</b><div>${e(text)}</div>`;clearTimeout(toastTimer);toastTimer=setTimeout(()=>n.innerHTML='',5000);return;}
 let d=document.getElementById('systemDialog');if(!d){d=document.createElement('dialog');d.id='systemDialog';d.className='system-dialog';document.body.append(d);}
 d.innerHTML=`<div class="system-dialog-inner"><div class="sys-title"><span class="icon-notice">!</span>NOTIFICATION</div><h2>${e(title)}</h2><p>${e(text)}</p><div class="sys-actions">${b('close-notice','Continue')}</div></div>`;
 if(!d.open)d.showModal();
}
function requiredSnapshot(d=localDay()){
 const v=init();if(v.requiredSnapshots[d])return v.requiredSnapshots[d];
 const groups=[...new Set([...checkQueue(d),...learnQueue(d),...firstQueue(d),...dueItems(d)].map(x=>x.id))];
 const ss={date:d,ids:groups,checks:checkQueue(d).length,learning:learnQueue(d).length,first:firstQueue(d).length,due:dueItems(d).length,createdAt:Date.now()};
 v.requiredSnapshots[d]=ss;return ss;
}
function meter(){const v=init(),d=localDay();if(!v.rewardMeter[d]){
 const r=requiredSnapshot(d),existing=Object.entries(state.rpg.awards||{}).filter(([k])=>k.startsWith(d+':'));
 const budget=Math.max(40,4*(r.checks+r.learning)+5*(r.first+r.due)+40);
 v.rewardMeter[d]={target:budget,cap:2*budget,earned:existing.reduce((n,[,a])=>n+(+a||0),0),count:existing.length};
 }return v.rewardMeter[d];}
// Hint support belongs to one response and hunter, not every later reward.
const hintOwner5=()=>JSON.stringify([state._save45?.profileId||'',state._save45?.epoch||'']);
let hintSequence5=0;
// Responses are transient. Never adopt an older hunter's in-flight work on import.
function staleResponse5(target){return !!target&&target.responseOwner5!==hintOwner5();}
function hintWord5(target,trialKind=false){return canonicalId(trialKind?target?.id:target?.queue?.[target.i]);}
function currentHint5(target,trialKind=false){const mark=target?.pictureHintContext5;return !!(target?.pictureHint&&!staleResponse5(target)&&mark&&mark.owner===hintOwner5()&&mark.word===hintWord5(target,trialKind)&&(trialKind?mark.trialToken===target.token:mark.index===target.i));}
function previewTrainer5(target){return !!target&&day()!==localDay();}
function staleTrainer5(target){return previewTrainer5(target)||staleResponse5(target)||!!target?.pictureHint&&!currentHint5(target);}
function staleTrial5(target){return staleResponse5(target)||!!target?.pictureHint&&!currentHint5(target,true);}
const hintScopes5=window.GH_HINT_REWARDS5_CORE?.create({owner:hintOwner5,isCurrent:c=>{const target=c.action==='trial'?trial:trainer;return target===c.target&&currentHint5(target,c.action==='trial')&&target.pictureHintContext5.token===c.attempt&&hintWord5(target,c.action==='trial')===c.word&&(c.action!=='trial'||target.mode===c.mode);}});
function hintContext5(target,action){if(!currentHint5(target,action==='trial'))return null;const mark=target.pictureHintContext5;return{owner:mark.owner,word:mark.word,attempt:mark.token,action,mode:target?.mode,assisted:true,target};}
function bindHint5(target,trialKind=false){if(staleResponse5(target)){notify('Start a fresh response','This response belongs to an older hunter or restored profile. Existing progress was kept.');return false;}if(!hintScopes5||!target){notify('Hint unavailable','The local hint reward safeguards did not load. Keep the answer unassisted or reopen the complete game.');return false;}target.pictureHint=true;target.pictureHintContext5={owner:hintOwner5(),word:hintWord5(target,trialKind),index:target.i,trialToken:target.token,token:'hint-response-'+(++hintSequence5)};return true;}
function rejectStaleTrainer5(target,x){if(previewTrainer5(target)){notify('Date preview paused','Return the Study date control to today before continuing this block. Saved learning steps and retrieval dates were kept.');return true;}if(target&&!staleTrainer5(target)&&canonicalId(x?.id)===hintWord5(target))return false;notify('Start a fresh block','This response belongs to an older hunter, restored profile or word. Existing progress was kept.');return true;}
function trainerOrigin5(x){return{source:'trainer',attempt:trainer,word:canonicalId(x?.id),index:trainer?.i};}
const priorLearnHint5=learnComplete;
learnComplete=function(x,origin=null){const isTrainer=origin?.source==='trainer';if(isTrainer&&(origin.attempt!==trainer||origin.index!==trainer?.i||origin.word!==canonicalId(x?.id)||rejectStaleTrainer5(trainer,x)))return false;const c=isTrainer?hintContext5(trainer,'learning'):null;return hintScopes5?hintScopes5.withContext(c,()=>priorLearnHint5(x)):priorLearnHint5(x);};
const priorTrialHint5=certifyTrial;
certifyTrial=function(...args){if(staleTrial5(trial)){notify('Start a fresh trial','This response belongs to an older hunter or restored profile. No skill or Army credit was recorded.');return false;}return hintScopes5?hintScopes5.withContext(hintContext5(trial,'trial'),()=>priorTrialHint5.apply(this,args)):priorTrialHint5.apply(this,args);};
window.GH_HINT_REWARDS5=Object.freeze({trainerOrigin:trainerOrigin5,rejectStaleTrainer:rejectStaleTrainer5,isStaleTrainer:staleTrainer5,isStaleTrial:staleTrial5,factor:key=>hintScopes5?.factor(key)??1});
// GAME-07: An explicit, saved Stage 2 assignment earns at most 2x its
// new-learning and delayed-retrieval activity credit. This is computed from
// existing award keys; no save migration, XP removal, or progression changes.
function assignmentRewardCaps07(d=localDay()){
 const plan=init().stage2?.days?.[d];
 if(!plan||plan.date!==d||![1,2].includes(plan.schema)||
    !['checks','learn','first','due'].every(k=>Array.isArray(plan[k])&&plan[k].length<=10000&&plan[k].every(id=>typeof id==='string'&&id.length>0&&id.length<=200)))return null;
 const spent=(prefix)=>Object.entries(state.rpg.awards||{}).reduce((sum,[key,value])=>
   key.startsWith(d+':'+prefix)&&Number.isFinite(+value)?sum+Math.max(0,+value):sum,0);
 const bucket=(tasks,points,prefix)=>({
   cap:2*points*new Set(tasks.flatMap(k=>plan[k])).size,
   earned:spent(prefix)
 });
 return {learn:bucket(['checks','learn'],4,'learn:'),retrieve:bucket(['first','due'],5,'retrieve:')};
}
function assignmentRewardRemaining07(key,d){
 if(!key.startsWith('learn:')&&!key.startsWith('retrieve:'))return Infinity;
 const caps=assignmentRewardCaps07(d);
 if(!caps)return Infinity; // No valid frozen assignment: preserve legacy rules.
 const group=key.startsWith('learn:')?caps.learn:caps.retrieve;
 return Math.max(0,group.cap-group.earned);
}
function assignmentRewardCounter07(){
 const caps=assignmentRewardCaps07();
 if(!caps)return '';
 const format=x=>`${x.earned} / ${x.cap} XP${x.earned>x.cap?' (previous XP retained)':''}`;
 return `<p class="mini" id="assignmentRewardCapsGame07" aria-label="Assignment-specific reward limits">Required-task bonus caps · New-word learning: ${format(caps.learn)} · Delayed retrieval: ${format(caps.retrieve)}. Separate practice rewards remain eligible after these caps: 1 XP per first correct unaided vocabulary target per day, up to 30 practice XP. No additional mastery or listening credit.</p>`;
}
// Central award limiter: protects real scores and never removes already-earned XP.
award=function(key,amount){
 if(day()!==localDay())return 0;const id=localDay()+':'+key;
 if(Object.hasOwn(state.rpg.awards,id))return 0;
 const m=meter(),factor=window.GH_HINT_REWARDS5?.factor?.(key)??1;
 const proposed=Math.max(0,Math.floor(Number(amount||0)*factor)),n=Math.min(proposed,Math.max(0,m.cap-m.earned),assignmentRewardRemaining07(key,localDay()));
 state.rpg.awards[id]=n;state.rpg.xp=(+state.rpg.xp||0)+n;m.earned+=n;m.count++;return n;
};
function threshold(level){return Math.round(10000*Math.pow((clamp(level,1,100)-1)/99,1.6));}
function ackFor(d,profile=state){return {...(profile.animeBonus?.acknowledgments?.[d]||{}),...(init(profile).dailyArchive[d]||{})};}
function campaign(profile=state){
 const all=activeItems(),N=all.length||1,learned=all.filter(x=>profile.learning?.[canonicalId(x.id)]?.learned||profile.cards?.[canonicalId(x.id)]?.seen).length,first=all.filter(x=>!!profile.cards?.[canonicalId(x.id)]?.firstRetrieved).length,v=init(profile);
 const countThrough=end=>{const days=dates(START,end);let checked=0;for(const d of days){const a=ackFor(d,profile);checked+=+!!a.comprehension + +!!a.speaking;}return {days:days.length,checked,total:days.length*2};};
 const earnedFor=x=>{const complete=learned===N&&first===N&&x.checked===x.total;return Math.min(complete?10000:9999,Math.floor(10000*(.6*learned/N+.2*first/N+.2*x.checked/Math.max(1,x.total))));};
 // Preserve the previously earned legacy level before correcting its short activity window.
 const prior=v.campaignFloor012,valid=prior?.schema===1&&Number.isFinite(prior.earned)&&prior.earned>=0&&prior.earned<=10000;
 const legacy=countThrough('2026-11-03'),floor=valid?prior.earned:earnedFor(legacy);
 if(prior===undefined)v.campaignFloor012={schema:1,earned:floor,legacyEnd:'2026-11-03',start:START,exam:EXAM};
 const end=addDays(EXAM,-1),activity=countThrough(end),core=window.GH_STAGE2_COMPLETION_CORE;let target=null,targetError='',projection=null;
 const raw=v.stage2Completion?.campaignTargetJSON;
 if(raw!==undefined&&core)try{if(typeof raw!=='string'||raw.length>80000)throw Error('Saved target is unfamiliar; export a recovery backup.');const catalog=typeof byId==='object'?Object.values(byId).filter(x=>x&&typeof x.id==='string'&&(typeof canonicalId!=='function'||canonicalId(x.id)===x.id)):all;target=core.campaignTarget(JSON.parse(raw),catalog,undefined,{start:START,cutoff:cutoff(),exam:EXAM});projection=core.campaignProjection(profile,catalog,target);}catch(error){targetError=error.message;}
 const computedEarned=projection?projection.computedEarned:earnedFor(activity),earned=Math.max(floor,computedEarned),complete=projection?projection.complete:learned===N&&first===N&&activity.checked===activity.total;
 if(valid||prior===undefined)v.campaignFloor012.earned=Math.max(v.campaignFloor012.earned,earned);
 let level=1;for(let n=2;n<=100;n++)if(earned>=threshold(n))level=n;
 let rank='E';for(const [r,l]of rankBands)if(level>=l)rank=r;
 return {N:projection?.N??N,learned:projection?.learned??learned,first:projection?.first??first,checkedTasks:projection?.checkedTasks??activity.checked,tasksTotal:projection?.tasksTotal??activity.total,earned,computedEarned,preservedEarnedFloor:floor,level,rank,complete,next:level===100?10000:threshold(level+1),floor:threshold(level),percent:Math.floor(earned/100),activityStart:START,activityEnd:end,activityDays:activity.days,planningSourceConfirmed:profile.v4?.stage2Completion?.calendarReview?.confirmed===true&&profile.v4.stage2Completion.calendarReview.examDate===EXAM&&profile.v4.stage2Completion.calendarReview.cutoff===cutoff(),legacyWindowMigrated:valid||prior===undefined,targetStatus:target?'reviewed-finite':'unconfirmed-legacy',targetVersion:target?.id||null,targetSource:target?.source||'',targetError,receipts:projection?.receipts||[],retrievalLabel:projection?.retrievalLabel||'Self-rated first delayed retrieval attempt',instructorAccepted:false};
}
function score(mode){return skillStats(mode);}
function playerPower(){const ss=modes.map(score).filter(s=>s.n>=5);return ss.length?Math.round(ss.reduce((n,s)=>n+s.p,0)/ss.length):0;}
function army(){
 const out=[];for(const [old,a] of Object.entries(state.rpg.army||{})){const id=canonicalId(old),x=byId[id];if(!x||!a.recruited)continue;
 const unique=[...new Set((a.passes||[]).map(p=>p.date))].length,level=clamp(1+unique-2,1,10),resting=!!rec(id).due&&rec(id).due<localDay();
 const freshness=resting?.5:1,power=Number((Math.min(3,.6+.27*(level-1))*freshness).toFixed(2));
 const grade=level<=2?'Normal':level<=4?'Elite':level<=6?'Knight':level<=8?'Elite Knight':level===9?'Commander':'Marshal';
 out.push({id,ar:x.ling.head,meaning:x.meaningDisplay,level,grade,resting,power,dates:unique});
 }const s=playerPower();return {rows:out,total:out.length,ready:out.filter(x=>!x.resting).length,resting:out.filter(x=>x.resting).length,raw:out.reduce((n,x)=>n+x.power,0),effective:out.reduce((n,x)=>n+x.power,0)*(.5+.5*s/100),skill:s};
}
function gateRequirement(rank){const i='EDCBAS'.indexOf(rank);return {min:[20,30,50,75,100,140][i],power:[24,34,88,108,192,296][i],skill:[25,35,45,55,65,75][i],questions:[5,7,10,12,15,20][i]};}
function relativeThreat(difficulty,skill,n=0){if(n<5)return {class:'grey',label:'Uncalibrated',text:'At least five comparable attempts are needed.'};const diff=difficulty-skill;return diff<=-20?{class:'white',label:'Comfortable',text:'Below your recent performance band.'}:diff<=10?{class:'orange',label:'Matched',text:'Near your recent performance band.'}:diff<=25?{class:'red',label:'Stretch',text:'Above your recent performance band.'}:{class:'crimson',label:'Boss challenge',text:'A large practice gap; use rehearsal before a timed attempt.'};}
function avatarSVG(a=init().avatar){if(window.ICPT_ART)return window.ICPT_ART.avatarSVG(a);const skins={warm:'#bc805b',light:'#e3b18c',deep:'#754836',cool:'#a78779'},accents={cyan:'#70dfff',violet:'#b899ff',gold:'#f7cf86',red:'#ef8b98'},skin=skins[a.skin]||skins.warm,c=accents[a.accent]||accents.cyan;
 let hair=a.hair==='long'?'<path d="M63 48 Q62 15 82 18 Q108 17 109 51 L112 80 99 65 92 31 69 41 65 76Z" fill="#17273b"/>':a.hair==='shaved'?'<path d="M68 34 Q82 13 103 35 L97 28 77 26Z" fill="#182637"/>':'<path d="M65 40 L59 23 76 27 81 14 87 24 105 19 112 36 96 30 90 40 77 33Z" fill="#17273b"/>';
 let gear=a.armor==='sentinel'?`<path d="M49 62 L65 57 83 71 102 57 119 65 109 90 60 90Z" fill="#354b67" stroke="${c}"/><path d="M51 80 L35 88 38 117 54 126 65 107 64 86Z" fill="#1d344b" stroke="${c}"/>`:a.armor==='scholar'?`<path d="M62 58 L43 126 126 126 105 58 84 70Z" fill="#283052" stroke="${c}"/>`:`<path d="M60 61 L47 116 71 108 84 74 96 109 122 117 108 61 84 70Z" fill="#273c52" stroke="${c}"/>`;
 const weapon=a.weapon==='staff'?`<path d="M121 49 L113 137" stroke="#bf9c72" stroke-width="4"/><path d="M115 46 L123 30 131 46 123 57Z" fill="${c}"/>`:a.weapon==='bow'?`<path d="M133 57 Q153 91 129 126" fill="none" stroke="${c}" stroke-width="3"/><path d="M133 57 L129 126" stroke="#d1dfed"/>`:a.weapon==='book'?`<path d="M104 91 L123 85 134 107 113 116Z" fill="#38627b" stroke="${c}"/><path d="M110 95 L124 91 M113 100 L126 96" stroke="#b7d9ed"/>`:`<path d="M122 75 L139 33 145 27 145 37 127 80Z" fill="#bddfee"/><path d="M114 76 L134 84 M123 80 L115 100" stroke="${c}" stroke-width="4"/>`;
 return `<svg class="sys-avatar" viewBox="0 0 170 160" role="img" aria-label="Custom training avatar"><ellipse cx="85" cy="149" rx="43" ry="7" fill="${c}" opacity=".2"/><path d="M70 99 L65 146 78 146 85 115 92 146 105 146 99 99" fill="#152537" stroke="#426078"/>${gear}<path d="M76 51 L75 63 85 72 95 63 94 50" fill="${skin}"/><ellipse cx="85" cy="41" rx="18" ry="22" fill="${skin}"/>${hair}<path d="M73 43 L80 42 M91 42 L98 43" stroke="#253345" stroke-width="2"/><path d="M80 54 L91 54" stroke="#654631"/>${weapon}<path d="M72 80 L84 89 97 80" stroke="${c}" fill="none"/></svg>`;
}
function glyph(x){return window.ICPT_HINTS43 ? window.ICPT_HINTS43.render(x) : '<p class="note">The hint library did not load. Confirm that hint_data43.js and hints_v43.js are beside index.html.</p>';}
// Called only by the ordered loader before its final awaited startup save.
window.GH_SYSTEM_INIT_PROGRESS46=async function(){
 if(typeof window.GH_PROGRESS45?.commitAsync!=='function')return true;
 if(!window.GH_PROGRESS_WRITER46?.canWrite())return false;
 if(state.v4?.unifiedProgress46!==undefined){window.GH_UNIFIED_PROGRESS46.validateProfile(state);return true;}
 return persistCoreChange46(next=>{window.GH_UNIFIED_PROGRESS46.view(next,campaign(next));});
};
function playerProgress(){if(window.GH_PROGRESS_APP_READY46!==true)throw Error('Progress is waiting for the complete app to finish loading.');if(!window.GH_PROGRESS_WRITER46?.canWrite())throw Error(window.GH_PROGRESS_WRITER46?.status().message||'Safe saving is starting. Wait for the updated app.');if(playerProgress.failed)throw Error('Reload after exporting recovery before progression can resume.');if(!state._save45?.profileId){if(typeof window.GH_PROGRESS45?.commitAsync==='function'||!save())throw Error('Progression is waiting for a verified profile save.');}if(typeof window.GH_PROGRESS45?.commitAsync==='function'&&state.v4?.unifiedProgress46===undefined)throw Error('Progression initialization has not been verified. Keep this page open and export a recovery backup.');const first=state.v4?.unifiedProgress46===undefined;const readiness=campaign();window.GH_UNIFIED_PROGRESS46.view(state,readiness);if(first&&!save()){playerProgress.failed=true;window.GH_PROGRESS45?.requireMockReload?.();throw Error('Unified progression could not be saved. Export recovery before continuing.');}return window.GH_UNIFIED_PROGRESS46.view(state,readiness);}
function hud(){let c;try{c=playerProgress();}catch(error){return '<section class=card role=alert><h2>Progress unavailable</h2><p>'+e(error.message)+'</p><p>Use Save & recovery to export your progress and restore a valid checkpoint.</p></section>';}const a=army(),m=meter(),ratio=c.level===100?100:percent(c.earned-c.floor,c.next-c.floor);
 return `<section class="sys-hud ${c.rank==='S'?'sys-purple':''}"><div class="sys-top"><span class="sys-kicker">Arabic training / field journal</span><span class="sys-title">STATUS</span><span class="sys-rank">${c.rank}</span></div><div class="sys-overview"><div><div class="sys-level">${c.level}<small>/100</small></div><small>PLAYER LEVEL</small></div><div><h2>${e(state.rpg.nickname||'Your hunter profile')}</h2><div class="sys-chips"><span class="sys-chip">${a.total} shadows · ${a.ready} ready</span><span class="sys-chip">${Math.round(a.effective)} army power</span><span class="sys-chip">${state.rpg.xp||0} activity XP</span></div><div class="sys-meter"><i style="width:${ratio}%"></i></div><p class="mini">${c.level===100?'Player level 100 reached. XP still earns focus points.':`${c.next-c.earned} XP to level ${c.level+1}`} · Every 100 earned XP grants one focus point. Gate readiness stays separate; level is not ILR proficiency.</p></div><div class="sys-avatar-wrap">${avatarSVG()}</div></div><div class="sys-attributes">${modes.map(k=>{const s=score(k);return `<div class="sys-attribute"><span>${e(MODES[k])}</span><b>${s.n?s.p+'%':'—'}</b><span>${s.n} recent independent attempts${s.partner?' · partner-rated':''}</span></div>`;}).join('')}</div><div class="sys-actions">${b('go','System & appearance','data-tab="system"')}${b('go','Arcade','data-tab="arcade"')}${b('go','Recovery board','data-tab="recovery"')}${b('music',init().settings.music?'Music: on':'Music: off')}${b('pause-focus',init().focusPaused?'Resume study':'Pause study')}</div><p class="mini" style="margin:12px 0 0">Today’s activity allowance: ${Math.round(m.earned)} / ${m.cap} XP (2 × ${m.target} planned XP). Practice remains available after the reward cap.</p>${assignmentRewardCounter07()}</section>`;
}
// Curriculum-linked progression replaces constant-width level bars. Legacy activity XP is preserved.
xpPanel=hud;
rankInfo=function(){try{const c=playerProgress();return {rank:c.rank,xp:state.rpg.xp||0,level:c.level};}catch{return {rank:'Unavailable',xp:state.rpg.xp||0,level:null};}};
function dailyReady(){const d=localDay(),counts={checks:checkQueue(d).length,learn:learnQueue(d).length,first:firstQueue(d).length,due:dueItems(d).length},ack=ackFor(d);return {ready:day()===d&&d>=START&&d<EXAM&&!constraints().length&&Object.values(counts).every(n=>n===0)&&!!ack.comprehension&&!!ack.speaking,counts,ack,date:d};}
function dailyPanel(){if(window.ICPT_DAILY44)return window.ICPT_DAILY44.panel();const t=dailyReady();return `<section class="sys-panel"><h2>${t.ready?'Daily work complete · bonus areas open':'Finish the mandatory route to unlock bonuses'}</h2><div class="sys-chips">${Object.entries(t.counts).map(([k,n])=>`<span class="badge ${n?'amber':''}">${k}: ${n} remaining</span>`).join('')}</div><label class="checkline"><input type="checkbox" data-system-ack="comprehension" ${t.ack.comprehension?'checked':''}> I completed today’s assigned reading/listening task and reviewed corrections.</label><label class="checkline"><input type="checkbox" data-system-ack="speaking" ${t.ack.speaking?'checked':''}> I attempted today’s speaking task and reviewed it.</label><p class="mini">These two confirmations are self-reported. Vocabulary completion is read from your records. They do not create accuracy scores or an official language rating.</p>${b('go','Return to today','data-tab="today"')}</section>`;}
// Tomorrow's textbook is a hard new-learning priority, never a general-frequency tie-breaker.
const oldMap=planMap;
function classDays(){
 if(window.GH_WEEKLY_SCHEDULE){const c=window.GH_WEEKLY_SCHEDULE.current();return (c?.rows||[]).filter(r=>!r.noClass).flatMap(r=>(r.pageRanges.length?r.pageRanges:r.chapters.map(chapter=>({chapter,from:null,to:null}))).map(p=>({...p,date:r.date,confirmed:r.mappingVerified,exactPages:r.mappingVerified&&p.from!==null,weeklyRow:r}))).sort((a,b)=>a.date.localeCompare(b.date)||a.chapter-b.chapter);}
 const out=init().pageSchedule.map(r=>({...r,exactPages:true}));
 for(let ch=11;ch<=15;ch++){
  const w=state.settings.release[ch]||DATA.plan.release[ch];
  for(const d of dates(w[0],w[1])){
   if([0,6].includes(new Date(d+'T12:00:00').getDay()))continue;
   if(!out.some(r=>r.date===d&&+r.chapter===ch))out.push({date:d,chapter:ch,from:null,to:null,confirmed:false,exactPages:false});
  }
 }
 return out.sort((a,b)=>a.date.localeCompare(b.date)||a.chapter-b.chapter);
}
function nextClass(d=day()){
 if(window.GH_WEEKLY_SCHEDULE){const c=window.GH_WEEKLY_SCHEDULE.nextClass(d);return {...c,rows:c.rows.flatMap(r=>(r.pageRanges.length?r.pageRanges:r.chapters.length?r.chapters.map(chapter=>({chapter,from:null,to:null})):[{chapter:null,from:null,to:null}]).map(p=>({...p,date:r.date,confirmed:r.mappingVerified,exactPages:r.mappingVerified&&p.from!==null,weeklyRow:r}))),weekly:true};}
 const all=classDays(),first=all.find(r=>r.date>d);
 if(!first)return {date:null,rows:[],exactPages:false,provisional:true};
 const rows=all.filter(r=>r.date===first.date);
 return {date:first.date,rows,exactPages:rows.every(r=>r.exactPages),provisional:rows.some(r=>!r.confirmed)};
}
function teachingHits(x){return members(x.id).filter(y=>y.bank==='core').map(y=>{
 const ov=init().pageOverrides[y.id],hit=ov?{chapter:y.chapter,page:+ov,basis:'Teacher/user page override'}:M[y.id];
 return hit?{...hit,rowId:y.id}:null;
}).filter(Boolean);}
function matchingCore(x,ctx){
 if(ctx.weekly){const ids=new Set(ctx.vocabulary?.ids||[]);return ids.has(canonicalId(x.id))?[{chapter:earliestChapter(x),page:null,date:ctx.date,exactPages:true,confirmed:true,basis:'Reviewed weekly source mapping'}]:[];}
 const core=members(x.id).filter(y=>y.bank==='core');
 const hits=teachingHits(x),matches=[];
 for(const r of ctx.rows){
  if(r.exactPages){for(const h of hits)if(h.chapter===+r.chapter&&h.page>=r.from&&h.page<=r.to)matches.push({...h,date:r.date,exactPages:true,confirmed:r.confirmed});}
  else if(core.some(y=>y.chapter===+r.chapter))matches.push({chapter:+r.chapter,page:null,date:r.date,exactPages:false,confirmed:false,basis:'Provisional chapter window; exact pages not supplied.'});
 }
 return matches;
}
planMap=function(){
 const source=oldMap(),map={...source},schedule=classDays(),weeklyDates={};if(window.GH_WEEKLY_SCHEDULE){for(const row of window.GH_WEEKLY_SCHEDULE.current()?.rows||[]){if(row.noClass||!row.mappingVerified)continue;for(const id of window.GH_WEEKLY_SCHEDULE.mapping([row]).ids)if(!weeklyDates[id]||row.date<weeklyDates[id])weeklyDates[id]=row.date;}}
 for(const x of activeItems()){
  const ch=earliestChapter(x),hits=teachingHits(x);
  const exact=schedule.filter(r=>r.exactPages&&hits.some(h=>h.chapter===+r.chapter&&h.page>=r.from&&h.page<=r.to));
  let d=null;
  if(weeklyDates[canonicalId(x.id)]||(!window.GH_WEEKLY_SCHEDULE&&exact.length)){
   const preview=addDays(weeklyDates[canonicalId(x.id)]||exact[0].date,-1);
   // Previously taught duplicates keep the earlier deadline and move to the front when encountered again.
   d=ch<=10&&source[x.id]&&source[x.id]<preview?source[x.id]:preview;
  }else if(ch>=11&&ch<=15&&source[x.id])d=addDays(source[x.id],-1);
  if(d)for(const r of members(x.id))map[r.id]=d<START?START:d;
 }
 return map;
};
const mapComputeV4=planMap;let mapCacheV4={key:'',value:null};
function scheduleKey(){return JSON.stringify([EXAM,effectiveDailyCalendar46(),!!window.GH_WEEKLY_SCHEDULE,state.settings.buffer,state.settings.release,state.settings.keyBoost,init().pageSchedule,init().pageOverrides,init().weeklySchedule?.current?.id]);}
planMap=function(){const k=scheduleKey();if(mapCacheV4.key!==k)mapCacheV4={key:k,value:mapComputeV4()};return mapCacheV4.value;};
function chapterCeiling(d=localDay()){
 const ctx=nextClass(d),previous=classDays().filter(r=>r.date<=d);
 const upcoming=[...ctx.rows.map(r=>+r.chapter),...(ctx.vocabulary?.ids||[]).map(id=>byId[id]?earliestChapter(byId[id]):null)].filter(n=>Number.isFinite(n)&&n>0),earlier=previous.map(r=>+r.chapter).filter(n=>Number.isFinite(n)&&n>0);return upcoming.length?Math.max(...upcoming):earlier.length?Math.max(...earlier):10;
}
allowedDate=function(x,d=day(),map=null){
 const p=(map||planMap())[x.id],ch=earliestChapter(x);
 const ahead=init().aheadPermit;const inPreview=ahead?.date===d&&members(x.id).some(y=>y.chapter===ahead.chapter)&&ahead.chapter===chapterCeiling(d);
 const last=effectiveDailyCalendar46().cutoff;return allowedDailyAdmission46(x,d,!!last&&!!p&&(p<=d||inPreview)&&p<=last&&d<=last&&d>=START&&(ch>15||ch<=chapterCeiling(d)));
};
const priorityNames=['Next class · textbook first','Textbook catch-up / current chapter','Next-class supplements','Other scheduled supplements'];
let learningPriorityCache={key:'',records:{}};
function learningPriority(x,d=day()){
 const cacheKey=d+'|'+scheduleKey();
 if(learningPriorityCache.key!==cacheKey){
  const ctx=nextClass(d),pm=planMap(),records={};
  for(const item of activeItems()){
   const core=members(item.id).some(r=>r.bank==='core'),matched=matchingCore(item,ctx),chapters=ctx.rows.map(r=>+r.chapter);
   const relevant=members(item.id).some(r=>r.chapter&&chapters.includes(r.chapter));
   const tier=matched.length?0:core?1:relevant?2:3;
   records[item.id]={tier,label:priorityNames[tier],matches:matched,date:pm[item.id]||'9999',page:matched.find(h=>h.page)?.page??999,chapter:matched[0]?.chapter||earliestChapter(item),nextDate:ctx.date};
  }
  learningPriorityCache={key:cacheKey,records};
 }
 return learningPriorityCache.records[canonicalId(x.id)]||{tier:3,label:priorityNames[3],date:'9999',page:999,chapter:99};
}
function sortLearning(xs,d=day()){
 return [...xs].sort((a,b)=>{const x=learningPriority(a,d),y=learningPriority(b,d);return x.tier-y.tier||(x.tier===0?(x.chapter-y.chapter||x.page-y.page):x.date.localeCompare(y.date))||pscore(b)-pscore(a)||a.id.localeCompare(b.id);});
}
const rawLearnQueue=learnQueue,rawCheckQueue=checkQueue,rawNewItems=newItems;
learnQueue=function(d=day()){return sortLearning(rawLearnQueue(d),d);};
checkQueue=function(d=day()){return sortLearning(rawCheckQueue(d),d);};
newItems=function(d=day()){return sortLearning(rawNewItems(d),d);};
function tomorrowTextbook(d=day()){
 const ctx=nextClass(d);return sortLearning(activeItems().filter(x=>matchingCore(x,ctx).length&&(!learningRec(x.id).learned&&!rec(x.id).seen)),d);
}
function aheadRows(){const ch=chapterCeiling();return sortLearning(activeItems().filter(x=>members(x.id).some(y=>y.bank==='core'&&y.chapter===ch)&&!hasIntroduced(x.id)));}
function nextClassPanel(){
 if(window.GH_WEEKLY_SCHEDULE)return window.GH_WEEKLY_SCHEDULE.nextClassPanel(day());
 const d=day(),ctx=nextClass(d),xs=tomorrowTextbook(d),eligible=xs.filter(x=>allowedDate(x,d));
 const when=ctx.date?fmt(ctx.date,true):'no later class supplied';
 const pages=ctx.rows.map(r=>chLabel(r.chapter)+(r.exactPages?' · pp. '+r.chapter+'.'+r.from+'–'+r.chapter+'.'+r.to:' · pages unconfirmed')).join(' / ');
 return `<section class="sys-panel priority-preview"><div class="eyebrow">New-learning priority 1 · textbook before supplements</div><h2>${ctx.date===addDays(d,1)?'Tomorrow’s textbook first':'Next class: textbook first'} — ${when}</h2><p>${e(pages||'Add the next teaching assignment in Sources & settings.')}</p><div class="sys-chips"><span class="sys-chip">${xs.length} textbook entries need learning/checks</span><span class="sys-chip">${eligible.length} available now</span><span class="sys-chip">${ctx.provisional?'Provisional class window':'Supplied class timetable'}</span></div><p>The learning queue puts these textbook targets ahead of Memrise, Quizlet-only entries, and general word-frequency rankings. Previously taught duplicates receive a familiarity check instead of a second assignment. Due spaced reviews remain separate.</p>${ctx.provisional?'<p class="mini">Later teaching pages have not been supplied. Chapter-level preview is marked provisional; update the page schedule instead of treating it as exact.</p>':'<p class="mini">Teaching dates come from the timetable. Word-to-page mappings are tutor/automated matches with editable source notes—not an official teacher index.</p>'}${b('next-textbook',eligible.length?'Start next-class textbook block':'No available next-class new words',eligible.length?'':'disabled','primary')}<details><summary>See exact target order and page evidence</summary><div class="scroller">${state.active?'<p class="mini">Word details are hidden while a mock is in progress.</p>':xs.map(x=>{const pr=learningPriority(x,d);return `<div class="dailyWord"><span class="ar" lang="ar">${e(x.ling.head)}</span><span>${e(x.meaningDisplay)}<br><small>${e(pr.matches.map(h=>h.page?'p. '+h.chapter+'.'+h.page:'Ch '+h.chapter+' (provisional)').join(' / '))}</small></span><details><summary class="mini">Source</summary><p class="mini">${e(pr.matches.map(h=>h.basis).join(' '))}</p></details></div>`;}).join('')||'<p>No unlearned textbook targets for this class remain.</p>'}</div></details></section>`;
}
const constraintsBeforeV4=constraints;constraints=function(){const warnings=constraintsBeforeV4(),pm=planMap(),late=activeItems().filter(x=>pm[x.id]>cutoff()&&!hasIntroduced(x.id));if(late.length)warnings.push(late.length+' unseen entries are scheduled after the new-learning cutoff. Confirm the teaching dates; the review-only lock is not bypassed.');return [...new Set(warnings)];};
// Clean card surface: optional picture cue; expanded morphology remains behind details.
const formOld=formPanel;formPanel=function(x){let h=formOld(x),l=x.ling,root=l.root||'',letters=root.replace(/[^\u0621-\u064a]/g,''),theme=A.rootThemes[root];
 const family=root?activeItems().filter(y=>y.ling.root===root&&y.ling.measure&&(hasIntroduced(y.id)||allowedDate(y))).filter((y,i,a)=>a.findIndex(z=>z.ling.measure===y.ling.measure&&z.ling.head===y.ling.head)===i):[];
 const hollow=l.measure==='I'&&letters.length===3&&/[وي]/.test(letters[1]);const sourceParts=String(l.sourceForm||x.ar).split('/').map(s=>s.trim()); const verbalNoun=l.pos==='verb'&&sourceParts.length===3?sourceParts[2]:l.pos==='verb'&&sourceParts.length===2&&!/^[يتأن]/.test(spellingNorm(sourceParts[1]))?sourceParts[1]:null;
 const knownBroken=['رجال','نساء','أطفال','بيوت','كتب','مدن','جبال','أنهار','جزر','ضيوف','أبواب','شوارع','أساتذة','طلاب','أولاد','أصدقاء','أقلام','مكاتب','أيام','أشهر','مناطق','معالم','ميادين','جيران','أعمال','أخبار','موانئ'];
 const broken=knownBroken.filter(t=>spellingNorm(x.ar+' '+l.forms.map(f=>f.ar).join(' ')).split(/[\s/]+/).includes(t));
 const extra=`<div class="sys-source-strip"><div><b>${letters.length===4?'Quadriliteral root (four root letters)':letters.length===3?'Triliteral root (three root letters)':'Root classification not verified for this entry'}</b><p>${root?`<span class="ar">${e(root)}</span>`:''}</p><p class="mini">${theme?'Root-family theme: '+e(theme)+'. This is not a substitute for each word’s meaning.':'No separate root meaning has been verified here; do not infer one mechanically.'}</p>${hollow?'<p class="badge amber">Hollow Measure I verb · middle root و / ي</p>':''}${broken.length?`<p class="badge blue">Known broken plural(s): ${broken.map(e).join(' / ')}</p>`:''}${l.pos==='verb'?`<p class="mini"><b>Verbal noun:</b> ${verbalNoun?e(verbalNoun)+' (as supplied; consult the source annotation)':'Not unambiguously separated from the other supplied forms. See the original source; no automatic verbal noun is invented.'}</p>`:''}</div></div>${family.length>1?`<details><summary>Attested study words across this root family</summary><p class="mini">Only actual supplied vocabulary in available chapters is shown. Empty measures are not filled with invented words.</p><table><thead><tr><th>Measure</th><th>Word</th><th>Meaning in this entry</th></tr></thead><tbody>${family.map(y=>`<tr><td>${e(y.ling.measure)}</td><td class="ar" lang="ar">${e(y.ling.head)}</td><td>${e(y.meaningDisplay)}</td></tr>`).join('')}</tbody></table></details>`:''}`;
 return h.replace('<div class="formGrid">',extra+'<div class="formGrid">');};
const oldRecall=renderRecall;renderRecall=function(){if(previewTrainer5(trainer))return heading('Study date preview','Return the Study date control to today to continue this saved block. Learning steps and retrieval dates are not changed in a preview.')+'<section class="card"><button type="button" data-v3="end-trainer">Return to dashboard</button></section>';if(window.GH_HINT_REWARDS5.isStaleTrainer(trainer))return heading('Start a fresh block','This response belongs to an older hunter, restored profile or word. No new progress is recorded.')+'<section class="card"><button type="button" data-v3="end-trainer">Return to today</button></section>';let h=oldRecall();if(!trainer||trainer.i>=trainer.queue.length)return h;const x=byId[trainer.queue[trainer.i]],kind=modeForItem(x),shown=trainer.revealed||(['learn','rehearsal'].includes(kind)&&trainer.phase==='prompt');
 const f=shown||trainer.pictureHint?glyph(x):b('picture-hint',window.ICPT_HINTS43?.label(x)||'Reveal sentence hint · reduced XP','','small');return h.replace('<div class="actions spacer">',`<div class="spacer">${f}</div><div class="actions spacer">`);};
const oldNext=nextTrainer;nextTrainer=function(){if(staleTrainer5(trainer))return false;if(trainer)trainer.pictureHint=false;return oldNext();};
const oldRetrieval=updateRetrieval;updateRetrieval=function(x,rating,origin=null){origin||=trainerOrigin5(x);if(origin.attempt!==trainer||origin.index!==trainer?.i||origin.word!==canonicalId(x?.id)||rejectStaleTrainer5(trainer,x))return false;if(trainer?.pictureHint&&rating==='good'){notify('Supported recall','This answer used a hint. It will return for an independent retrieval.');rating='hard';}return hintScopes5?hintScopes5.withContext(hintContext5(trainer,'retrieval'),()=>oldRetrieval(x,rating)):oldRetrieval(x,rating);};
document.addEventListener('click',ev=>{const b=ev.target.closest('[data-v3="audit-known"]');if(b&&trainer?.pictureHint){ev.preventDefault();ev.stopImmediatePropagation();notify('Hint used','Choose Needs learning; this was supported practice, not an independent familiarity check.');}},true);
const trialRenderOld=renderTrial;renderTrial=function(){if(window.GH_HINT_REWARDS5.isStaleTrial(trial))return '<section class="sys-panel"><h2>Start a fresh trial</h2><p>This response belongs to an older hunter or restored profile. No new skill or Army credit is recorded.</p><button type="button" data-v3="trial-close">Close old trial</button></section>';let h=trialRenderOld();if(!trial||!byId[trial.id])return h;const x=byId[trial.id];return h+`<section class="sys-panel">${trial.checked||trial.pictureHint?glyph(x):b('trial-picture',window.ICPT_HINTS43?.label(x)||'Reveal sentence hint · practice only')}<p class="mini">Any pre-answer hint makes extraction supported practice: no shadow recruitment or independent skill credit.</p></section>`;};
function renderSystem(){const c=campaign(),a=army(),v=init();return heading('The System','Earn XP toward player levels and focus points; gate readiness remains evidence-based.')+hud()+
 `<div class="grid"><section class="sys-panel"><h2>Gate readiness checklist · ${c.targetStatus==='reviewed-finite'?'reviewed finite target':'unconfirmed legacy planning'}</h2><p>The configured campaign uses new learning through ${e(cutoff())}, then review through ${e(c.activityEnd)} before the ${e(EXAM)} planning date. Daily activity now spans ${e(c.activityStart)}–${e(c.activityEnd)}; earned legacy levels are protected by a persistent floor. The 60% introduced + 20% first-retrieval + 20% daily-task formula is visible below. ${c.targetStatus==='reviewed-finite'?'The reviewed finite canonical-ID and dated R/L/S task set below supplies these denominators. Separate saved modality receipts are required; generic daily acknowledgments do not satisfy the target.':'No confirmed finite target is configured. The all-active-word legacy formula is preserved for progress continuity, not accepted as a feasible non-grind requirement. Configure and review the finite source target below.'} Calendar/cap priorities require instructor acceptance; inspect the source review in Settings.</p><table><tbody><tr><td>Introduced target vocabulary</td><td>${c.learned} / ${c.N}</td></tr><tr><td>${e(c.retrievalLabel)}</td><td>${c.first} / ${c.N}</td></tr><tr><td>Required daily task confirmations</td><td>${c.checkedTasks} / ${c.tasksTotal}</td></tr><tr><td>Preserved campaign progress</td><td>${c.earned} / 10,000</td></tr><tr><td>Current configured formula</td><td>${c.computedEarned} / 10,000</td></tr><tr><td>Previously earned floor</td><td>${c.preservedEarnedFloor} / 10,000</td></tr></tbody></table><p class="mini">Campaign XP weights: 60% introduced vocabulary + 20% first delayed-retrieval attempts + 20% configured dated practice evidence, with previously earned levels protected. ${c.targetStatus==='reviewed-finite'?'The finite target is learner-reviewed, not authenticated teacher acceptance. The chosen evidence criterion is shown below. Independent verification reuses existing delayed Army passes; self-rated attempts can include Again/Hard and do not prove correct mastery.':'Unconfirmed legacy planning still uses all active words and daily acknowledgments; a finite source-reviewed target is required before policy acceptance.'} Arcade grinding cannot substitute for demonstrated recall; acknowledgments are not proficiency scores.</p><details><summary>Why later levels take more work</summary><p class="mini">Total campaign XP required for level L = round(10,000 × ((L−1)/99)<sup>1.6</sup>). The player bar uses this same existing curve, starting from preserved progress and adding subsequently earned XP. This checklist remains separate gate-readiness evidence.</p><table><thead><tr><th>Level transition</th><th>Campaign XP needed</th></tr></thead><tbody>${[1,10,25,50,75,99].map(l=>`<tr><td>${l} → ${l+1}</td><td>${threshold(l+1)-threshold(l)}</td></tr>`).join('')}</tbody></table></details>${b('go','Open missed-day tasks','data-tab="recovery"')}</section>
 <section class="sys-panel creator"><h2>Customize your hunter</h2><div class="creator-layout"><div class="creator-preview">${avatarSVG()}</div><div class="creator-fields">${[['skin','Skin tone',['warm','light','deep','cool','olive','ebony']],['build','Build',['lean','broad']],['face','Face',['angular','soft']],['hair','Hair',['short','long','shaved','tied']],['hairColor','Hair color',['black','silver','blue','brown','violet','white']],['eyes','Eye color',['cyan','violet','gold','green','brown','red']],['armor','Equipment',['scout','sentinel','scholar','monarch']],['weapon','Weapon / tool',['blade','staff','bow','book','spear']],['accent','Aura',['cyan','violet','gold','red']]].map(([k,label,values])=>`<label>${label}<select data-system-avatar="${k}">${values.map(x=>`<option ${v.avatar[k]===x?'selected':''}>${x}</option>`).join('')}</select></label>`).join('')}</div></div><p class="mini">Original cel-shaded hunter artwork. Appearance is cosmetic: it cannot change accuracy, recruit words, or unlock unseen vocabulary.</p></section></div>
 <section class="sys-panel"><h2>Effects and focus</h2><div class="sys-settings"><label class="checkline"><input type="checkbox" data-system-setting="motion" ${v.settings.motion?'checked':''}> Gentle interface animation</label><label class="checkline"><input type="checkbox" data-system-setting="sfx" ${v.settings.sfx?'checked':''}> Short notification tones</label><label class="checkline"><input type="checkbox" data-system-setting="strictFocus" ${v.settings.strictFocus?'checked':''}> Focus challenge: one temporary game-health hit after an unpaused absence over 2 minutes</label><label>Music volume<input type="range" id="sysVolume" min="0" max=".25" step=".01" value="${masterVolume}"></label></div>${b('music',v.settings.music?'Stop original ambience':'Start original ambience')} ${b('test-notice','Preview notification')}<p class="mini">Bundled original instrumental soundtrack; no anime soundtrack samples. Audio is opt-in and ducks during Arabic playback. Fifty active study minutes triggers a rest prompt, not lost learning. Pausing and ordinary breaks have no penalty. Reduced-motion preferences are respected.</p></section>
 <section class="sys-panel"><h2>Shadow power · more than a headcount</h2><div class="sys-smallstats"><div><b>${a.total}</b><span>recruited</span></div><div><b>${a.ready}</b><span>ready</span></div><div><b>${a.resting}</b><span>resting</span></div><div><b>${Math.round(a.effective)}</b><span>effective power</span></div></div><p class="mini">A shadow starts at level 1 after recruitment, and gains one level per additional successful verification date, capped at 10. Base power = min(3, 0.6 + 0.27 × (level−1)); an overdue shadow contributes half. Effective army power = total × (0.5 + 0.5 × measured player skill / 100). With fewer than five attempts in a skill, that skill does not raise the player factor.</p><p>One vocabulary item can never replace a whole player. Solo gates also impose a minimum army size and an independent skill threshold.</p>${b('go','Inspect army and solo gates','data-tab="solo"')}</section>`;}
function renderRecovery(){const v=init(),ds=dates(START,localDay()<EXAM?localDay():addDays(EXAM,-1)),p=planMap();return heading('Recovery board','Make up a missed day without pretending you completed it in the past.')+`<div class="sys-help">Learning and review records are timestamped today. Reopening an old challenge does not backdate a spaced-repetition success. Once the review-only buffer begins, still-unseen vocabulary is flagged instead of silently unlocked.</div><section class="sys-panel"><div class="tablewrap"><table><thead><tr><th>Assigned day</th><th>Unfinished vocabulary</th><th>Comprehension / speaking</th><th>Resume</th></tr></thead><tbody>${ds.map(d=>{const xs=activeItems().filter(x=>p[x.id]===d&&!learningRec(x.id).learned&&!rec(x.id).seen),ack=ackFor(d),t=taskOn(d);return `<tr><td>${fmt(d,true)}</td><td>${xs.length}</td><td>${e(t[1])}<br><label class="checkline"><input type="checkbox" data-archive="comprehension" data-date="${d}" ${ack.comprehension?'checked':''}> Comprehension attempted and corrected</label><label class="checkline"><input type="checkbox" data-archive="speaking" data-date="${d}" ${ack.speaking?'checked':''}> Speaking attempted and reviewed</label></td><td>${b('catchup','Resume available words',`data-date="${d}"`,'small')}${b('go','Mock tests','data-tab="mocks"','small')}</td></tr>`;}).join('')}</tbody></table></div></section>`;}
function renderSchedule(){return `<section class="sys-panel"><h2>Preview tomorrow’s lesson pages</h2><p>The Week 13 page assignments below are supplied. Later chapter dates remain provisional. Candidate page matches were found for ${Object.keys(M).length} Unit 3 textbook entries; they are automated text matches, not a teacher-verified vocabulary index. Unmatched words retain a visibly provisional chapter preview.</p><div class="tablewrap"><table><thead><tr><th>Class date</th><th>Chapter</th><th>Pages</th><th>Source</th></tr></thead><tbody>${init().pageSchedule.map(r=>`<tr><td>${r.date}</td><td>${r.chapter}</td><td>${r.chapter}.${r.from}–${r.chapter}.${r.to}</td><td>${r.confirmed?'Supplied Week 13 timetable':'Teacher/user entry'}</td></tr>`).join('')}</tbody></table></div><div class="sys-formrow"><label>Date<input type="date" id="pageDate"></label><label>Chapter<input type="number" id="pageChapter" min="11" max="15" value="11"></label><label>First page<input type="number" id="pageFrom" min="1" value="2"></label><label>Last page<input type="number" id="pageTo" min="1" value="10"></label>${b('page-save','Add / replace chapter-day pages')}</div><p class="mini">The learning block is scheduled the day before class; page-to-word matches can be overridden by source entry ID. Preview never extends beyond the currently released chapter (${chapterCeiling()}).</p><details><summary>Override a word’s first teaching page</summary><div class="sys-formrow"><label>Source row ID<input id="pageWord" placeholder="ch11-001"></label><label>Printed page number (after the chapter dot)<input id="pageWordNumber" type="number" min="1"></label>${b('page-word','Save word-page mapping')}</div></details>${b('ahead','Study ahead within this chapter')}</section>`;}
const settingsOld=renderSettings;renderSettings=function(){return renderSchedule()+settingsOld();};
const todayOld=renderToday;renderToday=function(){return todayOld().replace('<div class="stats">',nextClassPanel()+'<div class="stats">')+dailyPanel()+`<section class="sys-panel"><h2>Optional after-work chambers</h2><p>Short recognition games are in the Arcade. Missed days remain available on the Recovery board.</p>${b('go','Arcade','data-tab="arcade"')} ${b('go','Recovery board','data-tab="recovery"')} ${b('ahead','Preview the rest of the current chapter')}</section>`;};
function renderLibrary(){let xs=LIB.filter(x=>(libraryFilter.unit==='all'||x.unit===+libraryFilter.unit)&&(libraryFilter.kind==='all'||x.type===libraryFilter.kind)&&(!libraryFilter.search||(x.name+' '+x.file).toLowerCase().includes(libraryFilter.search.toLowerCase())));const pages=Math.max(1,Math.ceil(xs.length/10));libraryFilter.page=clamp(libraryFilter.page,0,pages-1);return heading('DLI supplementary sources','Original Units 1–3 listening and reading packages. Open the supplied worksheet rather than using a guessed transcript.')+`<div class="stats">${stat('Original MP3s',206,'Supplementary listening collection')}${stat('PDF documents',19,'16 listening worksheets + 3 reading books')}${stat('Source files',225,'Original filenames preserved')}${stat('New transcripts claimed',0,'Audio inclusion is not a transcription audit')}</div><div class="toolbar"><label>Unit<select id="libraryUnit">${[['all','All Units 1–3'],['1','Unit 1'],['2','Unit 2'],['3','Unit 3']].map(([v,t])=>`<option value="${v}" ${libraryFilter.unit===v?'selected':''}>${t}</option>`).join('')}</select></label><label>Type<select id="libraryKind">${['all','audio','pdf'].map(v=>`<option value="${v}" ${libraryFilter.kind===v?'selected':''}>${v}</option>`).join('')}</select></label><label class="grow">Search<input type="search" id="librarySearch" value="${e(libraryFilter.search)}" placeholder="Ch11, Passage(3), or filename"></label></div><div class="sys-flex">${b('library-prev','Previous','',libraryFilter.page===0?'disabled':'')}${b('library-next','Next')}<span>${xs.length} results · page ${libraryFilter.page+1}/${pages}</span></div><div class="sys-audio-list spacer">${xs.slice(libraryFilter.page*10,libraryFilter.page*10+10).map(x=>`<article><div class="eyebrow">${x.collection} · Unit ${x.unit||'?'}${x.chapter?' · Ch '+x.chapter:''}</div><h3>${e(x.name)}</h3>${x.type==='audio'?`<audio controls preload="none" src="${e(x.file)}"></audio>`:`<a target="_blank" rel="noopener" href="${e(x.file)}">Open original PDF</a>`}<p class="mini">${e(x.status)}</p><details><summary class="mini">Original path</summary><span class="sourcecode">${e(x.file)}</span></details></article>`).join('')}</div>`;}
function renderSolo(){const a=army(),scope=init().solo.scope||'all';return heading('Shadow deployment','Shadows support faster, safer gates. A higher-rank hunter with sufficient measured skill can enter a lower-rank gate without minimum Shadows.')+hud()+`<section class="sys-panel"><div class="tablewrap"><table><thead><tr><th>Gate</th><th>Minimum shadows</th><th>Effective power</th><th>Measured skill</th><th>Entry</th></tr></thead><tbody>${'EDCBAS'.split('').map(r=>{const q=gateRequirement(r),entry=window.GH_SOLO_ENTRY_POLICY.evaluate(r,playerProgress(),a,q),ready=entry.allowed;return `<tr><td>${r}</td><td>${a.total}/${q.min}</td><td>${Math.round(a.effective)}/${q.power}</td><td>${a.skill}% / ${q.skill}%</td><td>${b('solo-enter',ready?(entry.route==='unsupported'?'Enter without Shadows':'Enter supported gate'):'Requirements not met',`data-rank="${r}" ${ready?'':'disabled'}`)}</td></tr>`;}).join('')}</tbody></table></div><p class="mini">Unsupported higher-rank entry requires 40% more independent objectives and takes 20 damage per mistake instead of 15; the overall timer scales with the added objectives. Shadows restore the standard route. These are transparent game-balance thresholds, not official ILR cutoffs. No words are deleted for mistakes. Recruited words do not count as permanent mastery.</p><a href="gates.html">Play with classmates instead</a></section><section class="sys-panel"><h2>Army roster · ${a.total}</h2><div class="sys-roster-grid">${a.rows.slice(0,150).map(x=>`<article class="sys-roster-word"><div class="ar" lang="ar">${e(x.ar)}</div><p>${e(x.meaning)}</p><b>${x.grade} · level ${x.level}</b><small>${x.power.toFixed(2)} base power · ${x.resting?'resting (review overdue)':'ready'}</small>${b('verify-word','Verify / strengthen',`data-id="${x.id}"`,'small')}</article>`).join('')||'<p>No recruited words yet. Complete the blind listen–spell–meaning trials on two separated dates in Shadow Army.</p>'}</div></section>`;}
function musicStop(){if(musicTrack)musicTrack.pause();clearInterval(musicTimer);musicTimer=null;for(const n of musicNodes)try{n.stop();}catch{}musicNodes=[];}
async function musicStart(){musicTrack ||= new Audio('assets/music/gatehouse-ambient.mp3');musicTrack.loop=true;musicTrack.volume=masterVolume;await musicTrack.play();}
let systemMusicPending46=false,systemMusicIntent46=0;
async function setSystemMusic46(wanted){
 // Stop is immediate even while a setting write is pending. Never restart audio
 // as rollback: callers may be starting speech or an opening score.
 if(!wanted){systemMusicIntent46++;musicStop();}
 if(systemMusicPending46){notify('Music setting pending','Playback can be stopped now; wait for the current save before changing the saved music preference.');return false;}
 const intent=++systemMusicIntent46,identity=JSON.stringify([state._save45?.profileId,state._save45?.epoch]);
 const current=()=>intent===systemMusicIntent46&&identity===JSON.stringify([state._save45?.profileId,state._save45?.epoch]);
 systemMusicPending46=true;
 try{
  if(wanted)await musicStart();
  if(!current()){musicStop();return false;}
  const ok=await persistCoreChange46(next=>{next.v4||={};next.v4.settings||={};next.v4.settings.music=wanted;},true);
  if(!ok||!current()){musicStop();return false;}
  return true;
 }catch(error){musicStop();notify('Audio could not start','Try again after interacting with the page.');return false;}
 finally{systemMusicPending46=false;}
}


function duck(ms=3500){duckUntil=Math.max(duckUntil,Date.now()+ms);}
function chime(){if(!init().settings.sfx||!musicContext)return;const t=musicContext.currentTime;[523.25,783.99].forEach((f,i)=>{const o=musicContext.createOscillator(),g=musicContext.createGain();o.frequency.value=f;g.gain.setValueAtTime(.025,t+i*.08);g.gain.exponentialRampToValueAtTime(.0001,t+.3+i*.08);o.connect(g);g.connect(musicContext.destination);o.start(t+i*.08);o.stop(t+.35+i*.08);});}
const oldSpeak=speakText;speakText=function(text,onend,onerror){duck(Math.max(4000,String(text).length*160));try{return oldSpeak(text,()=>{duckUntil=Date.now()+200;onend?.();},error=>{duckUntil=Date.now()+200;onerror?.(error);});}catch(error){duckUntil=Date.now()+200;throw error;}};
document.addEventListener('play',ev=>{if(ev.target.tagName==='AUDIO')duck(3600000);},true);document.addEventListener('pause',ev=>{if(ev.target.tagName==='AUDIO')duckUntil=Date.now()+200;},true);document.addEventListener('ended',ev=>{if(ev.target.tagName==='AUDIO')duckUntil=Date.now()+200;},true);
setInterval(()=>{const now=Date.now();if(musicTrack){const blocked=document.hidden||window.speechSynthesis?.speaking||[...document.querySelectorAll('audio,video')].some(a=>!a.paused)||now<duckUntil||tab==='speaking'||tab==='arena'||(tab==='mocks'&&state.active?.modality==='L')||recorder?.state==='recording';musicTrack.volume=blocked?0:masterVolume;}if(musicGain&&musicContext){const speaking=window.speechSynthesis?.speaking||[...document.querySelectorAll('audio')].some(a=>!a.paused);musicGain.gain.setTargetAtTime(init().settings.music&&!document.hidden&&!speaking&&now>duckUntil?masterVolume:0,musicContext.currentTime,.15);}if(!document.hidden&&now-lastInput<60000&&!window.ICPT_ARCADE?.paused()&&!init().focusPaused){activeSeconds++;if(activeSeconds>=3000&&!focusWarning){focusWarning=true;window.ICPT_ARCADE?.pause('Fatigue checkpoint');notify('Recovery recommended','You have accumulated 50 active study minutes. Pause and return refreshed. Learning records and XP remain intact.',true);}}},1000);
for(const ev of ['pointerdown','keydown','scroll'])document.addEventListener(ev,()=>lastInput=Date.now(),{passive:true});
document.addEventListener('visibilitychange',()=>{if(document.hidden){hiddenSince=Date.now();window.ICPT_ARCADE?.pause('Tab hidden',true);}else{const away=Date.now()-hiddenSince;if(init().settings.strictFocus&&away>120000)window.ICPT_ARCADE?.absencePenalty();lastInput=Date.now();}});
function bindNew(){const id=(s,ev,fn)=>document.getElementById(s)?.addEventListener(ev,fn);id('libraryUnit','change',ev=>{libraryFilter.unit=ev.target.value;libraryFilter.page=0;render();});id('libraryKind','change',ev=>{libraryFilter.kind=ev.target.value;libraryFilter.page=0;render();});id('librarySearch','change',ev=>{libraryFilter.search=ev.target.value;libraryFilter.page=0;render();});id('sysVolume','input',ev=>masterVolume=+ev.target.value);}
const priorRender=render;const renders={system:renderSystem,recovery:renderRecovery,library:renderLibrary,solo:renderSolo};
for(const [k,t]of [['system','Status & appearance'],['arcade','Gate Arcade'],['solo','Solo deployment'],['arena','Sparring & leaderboard'],['recovery','Missed-day recovery'],['library','DLI supplementary']])if(!sections.some(x=>x[0]===k))sections.push([k,t]);
render=function(){init();if(state.active&&['solo','library','gloss1','chapterPractice','precision','packs','arcade','arena','taxi-ch12','notifications45'].includes(tab)&&!markMockAssistedForExposure()){nav();document.getElementById('content').innerHTML=heading('Study content unavailable','Your active mock is preserved. Restore browser saving before opening study content.');return;}if(renders[tab]){nav();document.getElementById('content').innerHTML=renders[tab]();bindSpecial();}else priorRender();document.body.dataset.motion=init().settings.motion&&!matchMedia('(prefers-reduced-motion: reduce)').matches?'on':'off';bindNew();const c=(()=>{try{return playerProgress();}catch{return null;}})(),v=init();if(c&&!window.GH_NOTICES45&&v.lastCampaignLevel!==undefined&&c.level>v.lastCampaignLevel){notify('Level advanced · '+c.level,c.level===100?'Player level 100 reached. XP still earns focus points.':'Earned XP advanced your player level. Gate readiness remains separate.');}if(c)v.lastCampaignLevel=c.level;};
document.addEventListener('change',ev=>{
 const t=ev.target;
 if(!t.dataset.systemAck&&!t.dataset.archive&&!t.dataset.systemAvatar&&!t.dataset.systemSetting)return;
 const d=t.dataset.archive?t.dataset.date:localDay();
 if(t.dataset.archive&&d!==localDay()){notify('No retroactive completion','Make up the selected work today; original dates stay unchanged.');return;}
 const ack=t.dataset.systemAck||t.dataset.archive,avatar=t.dataset.systemAvatar,setting=t.dataset.systemSetting,checked=t.checked,value=t.value,at=Date.now();
 const change=next=>{
  next.v4||={};
  if(ack){next.v4.dailyArchive||={};next.v4.dailyArchive[d]||={};next.v4.dailyArchive[d][ack]=checked;next.v4.dailyArchive[d].completedAt=at;}
  if(t.dataset.systemAck){next.animeBonus||={};next.animeBonus.acknowledgments||={};next.animeBonus.acknowledgments[d]||={};next.animeBonus.acknowledgments[d][ack]=checked;}
  if(avatar){next.v4.avatar||={};next.v4.avatar[avatar]=value;}
  if(setting){next.v4.settings||={};next.v4.settings[setting]=checked;}
 };
 if(typeof window.GH_PROGRESS45?.commitAsync==='function'){
  if(typeof persistCoreChange46!=='function'){toast('The awaited settings save interface is unavailable. Your previous settings are unchanged.');render();return;}
  void persistCoreChange46(change,true).then(ok=>{if(!ok)render();});return;
 }
 change(state);save();render();
});
document.addEventListener('click',async ev=>{const z=ev.target.closest('[data-system]');if(!z||z.disabled)return;const act=z.dataset.system;
 if(act==='go'){window.ICPT_ARCADE?.pause('Navigation');go(z.dataset.tab);}
 if(act==='music'){await setSystemMusic46(!init().settings.music);}
 if(act==='close-notice')document.getElementById('systemDialog')?.close();
 if(act==='test-notice'){chime();notify('Training title acquired','A reminder of earned progress—not a threat or a countdown.',true);}
 if(act==='pause-focus'){const paused=!init().focusPaused;if(!await persistCoreChange46(next=>{next.v4||={};next.v4.focusPaused=paused;}))return;if(init().focusPaused){window.ICPT_ARCADE?.pause('Study paused');notify('Study paused','Use Resume study in Status when you return. No missed-day or rest penalty applies.');}else{activeSeconds=0;focusWarning=false;lastInput=Date.now();notify('Study resumed','Your active-study counter starts fresh.');}}
 if(act==='picture-hint'&&trainer){if(bindHint5(trainer))render();}
 if(act==='trial-picture'&&trial&&!trial.checked){if(bindHint5(trial,true)){trial.assisted=true;render();}}
 if(act==='next-textbook'){const xs=tomorrowTextbook().filter(x=>allowedDate(x));if(xs.length)startSession('selection',xs.map(x=>x.id));else notify('No eligible textbook targets','Review known words or confirm the next teaching pages.');}
 if(act==='ahead'){const xs=aheadRows().filter(x=>day()<=cutoff());if(!xs.length){notify('No chapter preview available','Known vocabulary remains available for review.');return;}state.v4.aheadPermit={date:day(),chapter:chapterCeiling()};startSession('selection',xs.slice(0,15).map(x=>x.id));}
 if(act==='catchup'){const launchTab=tab;const p=planMap(),xs=activeItems().filter(x=>p[x.id]===z.dataset.date&&(!learningRec(x.id).learned&&!rec(x.id).seen));if(!await persistCoreChange46(next=>{next.settings.studyDate='';}))return;if(tab!==launchTab||!document.body.contains(z))return;startSession('selection',xs.length?xs.map(x=>x.id):activeItems().filter(x=>p[x.id]===z.dataset.date&&hasIntroduced(x.id)).map(x=>x.id));}
 if(act==='page-save'){if(window.GH_WEEKLY_SCHEDULE){window.GH_WEEKLY_SCHEDULE.open();notify('Review the source assignment','Use Class Schedule to add, check and confirm exact daily assignments. Legacy page data is preserved.');return;}const date=document.getElementById('pageDate').value,ch=+document.getElementById('pageChapter').value,from=+document.getElementById('pageFrom').value,to=+document.getElementById('pageTo').value;if(!/^2026-\d\d-\d\d$/.test(date)||ch<11||ch>15||from<1||to<from||to>100){notify('Check the assignment','Enter a valid 2026 date, chapter 11–15 and a valid page range.');return;}await persistCoreChange46(next=>{next.v4.pageSchedule=next.v4.pageSchedule.filter(r=>!(r.date===date&&r.chapter===ch));next.v4.pageSchedule.push({date,chapter:ch,from,to,confirmed:false});},true);}
 if(act==='page-word'){const id=document.getElementById('pageWord').value.trim(),page=+document.getElementById('pageWordNumber').value;if(!byId[id]||page<1||page>100){notify('Check the source row','Use an existing row ID and a valid printed page number.');return;}if(!await persistCoreChange46(next=>{next.v4.pageOverrides[id]=page;}))return;notify('Word-page override saved','Tomorrow’s allocation will use this teaching-page mapping.');}
 if(act==='library-prev'){libraryFilter.page=Math.max(0,libraryFilter.page-1);render();}if(act==='library-next'){libraryFilter.page++;render();}
 if(act==='verify-word'){trialFilter='all';trial={id:z.dataset.id,mode:'army',played:false,checked:false,spell:'',meaning:'',assisted:false,responseOwner5:hintOwner5(),token:crypto.randomUUID?.()||String(Date.now())};go('army');}
 if(act==='solo-enter'){const req=gateRequirement(z.dataset.rank),a=army();const entry=window.GH_SOLO_ENTRY_POLICY.evaluate(z.dataset.rank,playerProgress(),a,req);if(!entry.allowed){notify('Gate remains closed',entry.reason);return;}window.ICPT_ARCADE?.startSolo(z.dataset.rank);}
});
window.ICPT_SYSTEM={playerProgress,init,renderers:renders,hud,notify,threshold,campaign,dailyReady,dailyPanel,army,gateRequirement,relativeThreat,glyph,avatarSVG,meter,b,startMusic:()=>setSystemMusic46(true),stopMusic:()=>setSystemMusic46(false),setVolume:v=>{masterVolume=clamp(+v,0,.25);if(musicTrack)musicTrack.volume=masterVolume;},musicPlaying:()=>!!musicTrack&&!musicTrack.paused,playerPower,score,duck,chime,chapterCeiling,library:LIB,resetFocus:()=>{activeSeconds=0;focusWarning=false;lastInput=Date.now();init().focusPaused=false;},getFocus:()=>({activeSeconds,paused:init().focusPaused}),nextClass,sortLearning,learningPriority,tomorrowTextbook,nextClassPanel};
render();
// The ordered async graph owns the final awaited addon migration save.
// Calling synchronous save() here always refuses on an async profile.
if(typeof window.GH_PROGRESS45?.commitAsync!=='function')save();
})();
