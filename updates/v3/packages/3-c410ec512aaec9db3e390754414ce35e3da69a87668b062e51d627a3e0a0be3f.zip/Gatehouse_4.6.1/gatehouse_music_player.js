/* Persistent, opt-in player. No profile/save reads or writes. */
(function(W,D){'use strict';
if(W.GH_MUSIC_PLAYER)return;
const tracks=(W.MUSIC_TRACKS||[]).slice();
if(!tracks.length)return;
tracks.sort((a,b)=>{const ac=Number(a.chapter)||999,bc=Number(b.chapter)||999;const p=t=>Number((t.id.match(/(?:^|-)part(\d+)/)||[])[1]||0);return ac-bc||(ac<999?p(a)-p(b):Number(a.number)-Number(b.number));});
const dock=D.createElement('section');dock.id='gh-music-player';dock.setAttribute('aria-label','Gatehouse music player');
dock.innerHTML='<details open><summary>Music · play while studying</summary><div class="gh-music-controls"><label>Song <select aria-label="Music track"></select></label><button type="button" data-action="prev"></button><button type="button" data-action="play"></button><button type="button" data-action="next"></button><label>Volume <input aria-label="Music volume" type="range" min="0" max="1" step="0.05" value="0.5"></label><a href="Study_Music/index.html" target="_blank" rel="noopener">Lyrics library ↗</a></div><div role="status" aria-live="polite"></div></details>';
const style=D.createElement('style');style.textContent='#gh-music-player{position:relative;z-index:auto;margin-bottom:12px;max-width:100%;background:#101d2d;color:#f3f5fa;padding:8px 16px;border-bottom:1px solid #64748b;font:14px system-ui}#gh-music-player summary{cursor:pointer}#gh-music-player .gh-music-controls{display:flex;align-items:center;flex-wrap:wrap;gap:8px;padding:8px 0}#gh-music-player select{max-width:min(480px,80vw)}#gh-music-player a{color:#bce4ff}#gh-music-player input{width:90px}#gh-music-player button[data-action]{display:inline-grid;place-items:center;min-width:32px;min-height:32px;padding:4px}#gh-music-player button:focus-visible{outline:2px solid #bce4ff;outline-offset:2px}';D.head.append(style);(D.querySelector('.main')||D.body).prepend(dock);
const select=dock.querySelector('select'),play=dock.querySelector('[data-action=play]'),status=dock.querySelector('[role=status]');
tracks.forEach(t=>{const o=D.createElement('option');o.value=t.id;o.textContent=(t.chapter?'Ch '+t.chapter:'ICPT '+t.exam+' · '+t.number)+' · '+t.title;select.append(o);});
const previous=dock.querySelector('[data-action=prev]'),next=dock.querySelector('[data-action=next]');
const glyph={prev:'<path d="M18 5v14l-9-7zM6 5v14"/>',play:'<path d="m8 5 11 7-11 7z"/>',pause:'<path d="M9 5v14m6-14v14"/>',next:'<path d="M6 5v14l9-7zM18 5v14"/>'};
function icon(button,name,label){
 if(button.getAttribute('aria-label')===label)return;
 button.setAttribute('aria-label',label);button.title=label;
 button.innerHTML='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+glyph[name]+'</svg>';
}
icon(previous,'prev','Previous track');icon(next,'next','Next track');
const a=D.createElement('audio');a.preload='none';a.volume=.5;dock.append(a);
let index=0,token=null,attempt=0,pending=false,started=false;
function active(){return started&&!a.paused&&!a.ended;}
function paint(){const playing=active();icon(play,playing?'pause':'play',playing?'Pause music':'Play music');}
function release(){const old=token;token=null;if(old!==null)W.GH_SOURCE_PLAYBACK_BROKER?.release(old);}
function pause(message){attempt++;pending=false;started=false;a.pause();release();paint();if(message)status.textContent=message;}
function load(i){pause();index=(i+tracks.length)%tracks.length;select.value=tracks[index].id;a.src=new URL('Study_Music/'+tracks[index].src,D.baseURI).href;status.textContent=tracks[index].title+' · Ready';}
function otherMediaIsActive(){return Array.from(D.querySelectorAll('audio,video')).some(e=>e!==a&&!e.paused&&!e.ended);}
function start(){
 if(pending||active())return;
 const broker=W.GH_SOURCE_PLAYBACK_BROKER;
 if(typeof broker?.claimIfIdle!=='function'){status.textContent='Music cannot start until the shared audio controls have loaded.';return;}
 const busy='Study audio is playing. Press Play when it finishes.';
 // Shipped GH457_AUDIO.isBusy covers detached router and queued recordings.
 // Keep this query read-only: stopping the router here would interrupt a lesson.
 if(W.GH457_AUDIO?.isBusy?.()||otherMediaIsActive()||W.speechSynthesis?.speaking){status.textContent=busy;return;}
 token=broker.claimIfIdle('gatehouse-music',()=>pause('Music paused for study audio. Press Play to resume.'));
 if(token===null){status.textContent=busy;return;}
 const n=++attempt;pending=true;status.textContent=tracks[index].title+' · Starting…';
 // Start directly in the explicit button gesture; no policy overrides or retries.
 try{Promise.resolve(a.play()).catch(()=>{if(n===attempt)pause('Playback could not start. Press Play to retry.');});}
 catch{if(n===attempt)pause('Playback could not start. Press Play to retry.');}
}
function choose(i,playing=active()||pending){load(i);if(playing)start();}
play.onclick=()=>active()?pause('Paused'):start();
select.onchange=()=>{const i=tracks.findIndex(t=>t.id===select.value);if(i>=0)choose(i);};
previous.onclick=()=>choose(index-1);next.onclick=()=>choose(index+1);dock.querySelector('input').oninput=e=>a.volume=Number(e.target.value);
a.addEventListener('playing',()=>{if(token===null||a.paused||a.ended)return;pending=false;started=true;paint();status.textContent=tracks[index].title+' · Playing';});
a.addEventListener('ended',()=>{if(token!==null&&a.ended)choose(index+1,true);});
a.addEventListener('error',()=>{if(a.error)pause('This recording could not load. Check the Study_Music/audio folder.');});
// pause() releases its own token synchronously; a queued old pause must not
// release the new load's claim. Only handle an actual paused/started state.
a.addEventListener('pause',()=>{if(started&&a.paused&&!a.ended&&!pending)pause('Paused');});
D.addEventListener('play',e=>{const media=e.target;if(media!==a&&typeof media?.pause==='function'&&!media.paused&&!media.ended&&(pending||active()))pause('Music paused for other audio.');},true);
dock.querySelector('a').addEventListener('click',()=>pause('Music paused while opening the lyrics library.'));
W.addEventListener('pagehide',()=>pause());load(0);
W.GH_MUSIC_PLAYER=Object.freeze({pause,tracks:tracks.map(t=>t.id)});
})(window,document);
