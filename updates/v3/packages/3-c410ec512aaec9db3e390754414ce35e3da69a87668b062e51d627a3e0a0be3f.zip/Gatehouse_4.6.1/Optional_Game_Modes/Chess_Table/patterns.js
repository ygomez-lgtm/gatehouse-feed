/* Observable tactical motifs, not a winning-move evaluator. Uses legal chess.js moves. */
(function(root){'use strict';
const value={p:1,n:3,b:3,r:5,q:9,k:100},name={p:'pawn',n:'knight',b:'bishop',r:'rook',q:'queen',k:'king'};
const coord=s=>[s.charCodeAt(0)-97,Number(s[1])-1],square=(x,y)=>String.fromCharCode(97+x)+(y+1);
function pieces(c,color){return c.board().flat().filter(p=>p&&p.color===color)}
function attacks(c,from,target,color){return c.attackers(target,color).includes(from)}
function rays(c,p){const dirs=p.type==='b'?[[1,1],[1,-1],[-1,1],[-1,-1]]:p.type==='r'?[[1,0],[-1,0],[0,1],[0,-1]]:[[1,1],[1,-1],[-1,1],[-1,-1],[1,0],[-1,0],[0,1],[0,-1]],out=[];for(const [dx,dy] of dirs){let [x,y]=coord(p.square),hits=[];while(true){x+=dx;y+=dy;if(x<0||x>7||y<0||y>7)break;const sq=square(x,y),q=c.get(sq);if(q){hits.push({...q,square:sq});if(hits.length===2)break}}if(hits.length===2)out.push(hits)}return out}
function material(c,side){return c.board().flat().reduce((n,p)=>p?n+(p.color===side?1:-1)*value[p.type]:n,0)}
// Conservative tactical admission, not full search. Suppress an offered move when
// one legal reply captures our queen and no immediate reply compensates materially.
function hangsQueen(c,m,side,before){
 for(const reply of c.moves({verbose:true})){
  if(reply.captured!=='q')continue;
  c.move(reply);
  try{
   if(c.isCheckmate())return true;
   if(material(c,side)>=before-1||c.isDraw())continue;
   let compensated=false;
   for(const counter of c.moves({verbose:true})){
    if(!counter.captured&&!counter.promotion&&!counter.san.endsWith('#'))continue;
    c.move(counter);
    try{if(c.isCheckmate()||material(c,side)>=before-1)compensated=true;}finally{c.undo()}
    if(compensated)break;
   }
   if(!compensated)return true;
  }finally{c.undo()}
 }
 return false;
}
function scan(c){const fen=c.fen(),side=c.turn(),enemy=side==='w'?'b':'w',out=[];const baseline=material(c,side),before=pieces(c,side),targets=pieces(c,enemy);const known=new Set(),oldLines=new Set();for(const p of before.filter(p=>'brq'.includes(p.type)))for(const [a,b] of rays(c,p))oldLines.add(p.square+':'+a.square+':'+b.square);
for(const p of before.filter(p=>'brq'.includes(p.type)))for(const t of targets)if(attacks(c,p.square,t.square,side))known.add(p.square+':'+t.square);
for(const m of c.moves({verbose:true})){const start=out.length;c.move(m);try{
 if(c.isCheckmate()){out.push({kind:'Mate in one',move:m.san,text:'Verified mate in one: '+m.san+'.'});continue}
 if(c.isDraw())continue;
 const theirs=pieces(c,enemy),ours=pieces(c,side),king=theirs.find(p=>p.type==='k');
 if(king&&c.attackers(king.square,side).length>=2)out.push({kind:'Double check',move:m.san,text:m.san+' creates double check: two pieces attack the king.'});
 const moved=c.get(m.to);
 if(moved&&'np'.includes(moved.type)){const hit=theirs.filter(t=>t.type!=='p'&&attacks(c,m.to,t.square,side));if(hit.length>=2)out.push({kind:'Fork',move:m.san,text:m.san+' creates a '+name[moved.type]+' fork, attacking '+hit.map(t=>name[t.type]+' on '+t.square).join(' and ')+'.'})}
 for(const p of ours.filter(p=>'brq'.includes(p.type))){
  for(const [front,back] of rays(c,p)){if(front.color!==enemy||back.color!==enemy||oldLines.has(p.square+':'+front.square+':'+back.square))continue;
   if(back.type==='k'&&front.type!=='k')out.push({kind:'Absolute pin',move:m.san,text:m.san+' leaves '+name[p.type]+' on '+p.square+' pinning '+name[front.type]+' on '+front.square+' to its king. The pinned piece cannot move off that line while exposing its king.'});
   if(front.type==='k'&&back.type!=='p')out.push({kind:'King skewer',move:m.san,text:m.san+' checks along a line toward '+name[back.type]+' on '+back.square+': a king-skewer pattern. The reply may still save or defend the rear piece.'});
  }
  if(p.square!==m.to&&before.some(b=>b.square===p.square&&b.type===p.type))for(const t of theirs.filter(t=>'kqr'.includes(t.type))){if(attacks(c,p.square,t.square,side)&&!known.has(p.square+':'+t.square))out.push({kind:t.type==='k'?'Discovered check':'Discovered attack',move:m.san,text:m.san+' uncovers '+name[p.type]+' on '+p.square+' attacking '+name[t.type]+' on '+t.square+'.'})}
 }
 if(out.length>start&&hangsQueen(c,m,side,baseline))out.length=start;
 }finally{c.undo()}}
if(c.fen()!==fen)throw Error('Pattern scan altered board');
// At most one example per motif; mate has priority. Never claim the move wins material.
const unique=[];for(const h of out){if(!unique.some(x=>x.kind===h.kind))unique.push(h)}for(const h of unique){const m=c.moves({verbose:true}).find(m=>m.san===h.move);h.instruction='Move the '+name[m.piece]+' from '+m.from+' to '+m.to+(m.promotion?' and promote to '+name[m.promotion]:'')+' ('+m.san+').'}unique.sort((a,b)=>(a.kind==='Mate in one'?-1:b.kind==='Mate in one'?1:0));return unique;
}
root.GH_CHESS_PATTERNS={scan};if(typeof module!=='undefined')module.exports=root.GH_CHESS_PATTERNS;
})(globalThis);
