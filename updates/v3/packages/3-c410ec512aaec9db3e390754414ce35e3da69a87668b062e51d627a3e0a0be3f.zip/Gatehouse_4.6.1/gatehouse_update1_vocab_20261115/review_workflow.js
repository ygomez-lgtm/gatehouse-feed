/* Gatehouse recovery R2: exact study scopes, self-reported knowledge and safe
 * in-review reports. These records never certify listening or mastery. */
(function (W) {
  'use strict';
  const clone = x => JSON.parse(JSON.stringify(x));
  const unique = xs => [...new Set((xs || []).filter(x => typeof x === 'string' && x))];
  const clean = (s, max = 16000) => String(s == null ? '' : s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').slice(0, max);
  const esc = s => clean(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const normalizeText = s => clean(s).replace(/\s+/g, ' ').trim();
  const knownKey = id => W.GH_EXACT_KNOWN_LINKS?.key?.(id) || id;
  function latestKnown(events, id) {
    return Object.values(events || {}).filter(e => e && knownKey(e.wordId) === knownKey(id) && typeof e.known === 'boolean' && Number.isFinite(e.at))
      .sort((a, b) => b.at - a.at || String(b.id).localeCompare(String(a.id)))[0] || null;
  }
  function validateScope(requested, actual) {
    const want = unique(requested), got = unique(actual);
    return {ok:got.length > 0 && got.every(id => want.includes(id)), requestedIds:want, actualIds:got,
      outsideIds:got.filter(id => !want.includes(id)), skippedIds:want.filter(id => !got.includes(id))};
  }
  // Copy a strict allow-list, never hidden answer/model properties from a router.
  function audioSnapshot(raw) {
    if (!raw || typeof raw !== 'object') return {kind:'unknown', reason:'Audio router snapshot unavailable'};
    const out = {};
    for (const k of ['kind','purpose','requestedPurpose','sourceWordId','wordId','selectedSource','originalSource','sourceSha256','associationStatus','associationReason','recordingWithheldReason','quarantineReason','reason','reviewStatus','trimReviewStatus']) {
      if (typeof raw[k] === 'string') out[k] = clean(raw[k], 1500);
    }
    for (const k of ['pronunciationReviewed','listeningCredit','deviceAudibleVerified','answerRevealing']) if (typeof raw[k] === 'boolean') out[k] = raw[k];
    return out;
  }
  function makeReport({id, build, wordId, canonicalWordId, stage, visible, audio, comment, at}) {
    return {schema:1, format:'GATEHOUSE_VISIBLE_WORD_REPORT_R2', id:clean(id,160), build:clean(build,180),
      wordId:clean(wordId,160), canonicalWordId:clean(canonicalWordId,160), stage:clean(stage,200), at,
      displayed:{definition:visible?.definition ? clean(visible.definition,4000) : null,
        context:visible?.context ? clean(visible.context,9000) : null, screenText:clean(visible?.screenText,16000),
        hiddenAnswerPolicy:'Only visibly rendered text at report creation is captured; hidden answers and closed details are omitted.'},
      audio:audioSnapshot(audio), comment:clean(comment,4000),
      delivery:'Saved locally or manually exported only; not sent automatically.'};
  }
  const Core = Object.freeze({latestKnown, validateScope, audioSnapshot, makeReport, unique, clean});
  if (typeof module === 'object' && module.exports) module.exports = Core;
  if (!W || !W.document || typeof state === 'undefined' || typeof byId === 'undefined') return;
  if (W.GH_REVIEW_WORKFLOW_R2) return;
  const D = W.document;
  const key = id => typeof canonicalId === 'function' ? canonicalId(id) : id;
  const owner = () => JSON.stringify([state._save45?.profileId || '', state._save45?.epoch || '']);
  const uuid = () => W.crypto?.randomUUID?.() || 'r2-' + Date.now() + '-' + Math.random().toString(36).slice(2);
  const build = () => W.GH457_RECOVERY_BUILD || W.GH_RELEASE46_META?.buildId || 'Build identifier unavailable';
  const notify = s => { if (typeof toast === 'function') toast(s); };
  let permit = null, lastScope = null, dialog = null, draftReport = null, lastRenderOwner = owner(), undoKnown = null, audioSelection = null, audioTrainer = null, audioEncounter = null, audioOwner = null;
  const attempts = new WeakMap();
  function vault(create = true) {
    if (!state.v4 && create) state.v4 = {};
    let v = state.v4?.reviewWorkflowR2;
    if (v == null && create) v = state.v4.reviewWorkflowR2 = {schema:1, knowledgeEvents:{}, reports:{}};
    if (v && v.schema !== 1) throw Error('The review-workflow save format is newer or unfamiliar. Export a backup before changing it.');
    if (v && create) { v.knowledgeEvents ??= {}; v.reports ??= {}; }
    return v;
  }
  const asyncProfile = () => typeof W.GH_PROGRESS45?.commitAsync === 'function';
  function profileCurrent(expected) {
    if (expected !== owner()) return false;
    if(asyncProfile()){
      try{const P=W.GH_PROGRESS45, snap=P.snapshot?.();return !!snap&&!P.getStatus?.().reloadRequired&&JSON.stringify([snap._save45?.profileId||'',snap._save45?.epoch||''])===expected;}catch{return false;}
    }
    try {
      const storageKey = W.GH_PROGRESS45?.KEY;
      if (storageKey) {
        const raw = W.localStorage.getItem(storageKey); if(!raw)return false; const stored=JSON.parse(raw);
        if (stored && JSON.stringify([stored._save45?.profileId || '', stored._save45?.epoch || '']) !== expected) return false;
      }
      return true;
    } catch (_) { return false; }
  }
  function isKnown(id) {
    try { return latestKnown(vault(false)?.knowledgeEvents, key(id))?.known === true; } catch (_) { return false; }
  }
  let uncertainWorkflow=null;
  const uncertaintyMessage='This change could not be verified and may already be saved. Stop making changes. Export a recovery backup from Save & recovery, then reload this page to check the saved status.';
  function workflowBlocked(){return uncertainWorkflow?.owner===owner()||W.GH_PROGRESS45?.getStatus?.()?.reloadRequired===true;}
  function uncertaintyHTML(){return workflowBlocked()?`<p role="alert" class="banner">${esc(uncertaintyMessage)} Known status shown on this page is unverified. Before leaving, export this pending change as well as your normal profile backup. <button type="button" data-r2-action="export-pending-workflow">Export pending vocabulary change</button></p>`:'';}
  let workflowWritePending=false;
  const workflowContent=p=>{const x=clone(p);delete x.studyTime;delete x._save45;return JSON.stringify(x);};
  const asyncRequired={ok:false,reason:'This operation requires awaited saving. Use the current vocabulary controls.'};
  async function persistMutationAsync(mutate) {
    if(!asyncProfile())return persistMutation(mutate);
    const P=W.GH_PROGRESS45,expected=owner();
    if(workflowWritePending)return {ok:false,reason:'A vocabulary change is still saving. Wait before changing it again.'};
    if(workflowBlocked())return {ok:false,uncertain:true,reason:uncertaintyMessage};
    if(!profileCurrent(expected)||typeof P.readDurableAsync!=='function')return {ok:false,reason:'The active profile could not be verified. Keep this page open and export a backup.'};
    workflowWritePending=true;
    let attempted=false,candidate=null;
    const before=JSON.stringify(state),fingerprint=workflowContent(state),ledger=JSON.stringify(state.v4?.reviewWorkflowR2||null);
    try{
      const durable=(await P.readDurableAsync())?.profile;
      if(owner()!==expected||workflowContent(state)!==fingerprint||!durable||JSON.stringify([durable._save45?.profileId||'',durable._save45?.epoch||''])!==expected||JSON.stringify(durable.v4?.reviewWorkflowR2||null)!==ledger)
        return {ok:false,reason:'Known history or the active profile changed. No change was applied.'};
      candidate=JSON.parse(before);candidate.v4??={};
      const v=candidate.v4.reviewWorkflowR2??={schema:1,knowledgeEvents:{},reports:{}};
      if(v.schema!==1)throw Error('Unfamiliar vocabulary history format.');
      v.knowledgeEvents??={};v.reports??={};mutate(v);
      attempted=true;
      const result=await P.commitAsync(candidate,{source:'vocabulary-review-workflow'});
      if(!result?.ok)throw Error('Vocabulary save did not complete.');
      const verified=(await P.readDurableAsync())?.profile;
      if(owner()!==expected||workflowContent(state)!==fingerprint||JSON.stringify(result.state?.v4?.reviewWorkflowR2||null)!==JSON.stringify(candidate.v4.reviewWorkflowR2)||!result.state||JSON.stringify([result.state._save45?.profileId||'',result.state._save45?.epoch||''])!==expected||!verified||JSON.stringify([verified._save45?.profileId||'',verified._save45?.epoch||''])!==expected||JSON.stringify(verified.v4?.reviewWorkflowR2||null)!==JSON.stringify(candidate.v4.reviewWorkflowR2))throw Error('Vocabulary save could not be verified.');
      const accepted=clone(result.state);
      if(JSON.stringify(state.studyTime)!==JSON.stringify(JSON.parse(before).studyTime)){
        const merge=W.GH_ACTIVE_TIME_CORE?.merge;
        if(typeof merge!=='function')throw Error('Newer study time could not be merged safely.');
        accepted.studyTime=merge(accepted.studyTime,state.studyTime);
      }
      state=accepted;return {ok:true};
    }catch(error){
      if(attempted){
        // Never overwrite newer open work. Preserve the pending ledger separately
        // for explicit recovery export when a write/readback outcome is uncertain.
        uncertainWorkflow={owner:expected,candidateLedger:clone(candidate?.v4?.reviewWorkflowR2||null)};
        P.markUncommitted?.(uncertaintyMessage);
        return {ok:false,uncertain:true,reason:uncertaintyMessage};
      }
      return {ok:false,reason:clean(error.message,500)};
    }finally{workflowWritePending=false;}
  }
  function persistMutation(mutate) {
    if(asyncProfile())return asyncRequired;
    const expected=owner();
    if(workflowBlocked())return {ok:false,uncertain:true,reason:uncertaintyMessage};
    if(!profileCurrent(expected))return {ok:false,reason:'This page is stale or browser storage is unavailable. Reopen the active hunter before making changes.'};
    try { const raw=W.localStorage.getItem(W.GH_PROGRESS45.KEY),stored=raw&&JSON.parse(raw); if(JSON.stringify(stored?.v4?.reviewWorkflowR2||null)!==JSON.stringify(state.v4?.reviewWorkflowR2||null))return {ok:false,reason:'Known history changed in another tab. Reload before changing it.'}; } catch (_) {return {ok:false,reason:'Known history could not be checked.'};}
    let previous,attempted=false;
    try {
      previous=state.v4?.reviewWorkflowR2?clone(state.v4.reviewWorkflowR2):null;
      mutate(vault());
      if(typeof save!=='function')throw Error('Saving is unavailable. No save was attempted.');
      attempted=true;
      if(save()!==true||!profileCurrent(expected))throw Error(uncertaintyMessage);
      return {ok:true};
    }catch(error){
      if(attempted){
        // A false return or readback error does not prove setItem failed. Retain
        // the candidate ledger for recovery export; never retry or undo here.
        uncertainWorkflow={owner:expected};
        return {ok:false,uncertain:true,reason:uncertaintyMessage};
      }
      if(owner()===expected){if(previous==null){if(state.v4)delete state.v4.reviewWorkflowR2;}else state.v4.reviewWorkflowR2=previous;}
      return {ok:false,uncertain:false,reason:clean(error.message,500)};
    }
  }
  let undoRecoveryBlockedOwner=null;
  function knownLedgerSignature(v){
    if(!v||v.schema!==1||!v.knowledgeEvents||typeof v.knowledgeEvents!=='object'||Array.isArray(v.knowledgeEvents))return null;
    return JSON.stringify(Object.keys(v.knowledgeEvents).sort().map(id=>{const event=v.knowledgeEvents[id];return [id,event&&typeof event==='object'?Object.keys(event).sort().map(k=>[k,event[k]]):event];}));
  }
  function captureKnownUndo(changes,events,expected){
    try{
    const v=vault(false),signature=knownLedgerSignature(v),batch=events[0]?.knownBatch;
    if(!signature||!batch||events.some(e=>latestKnown(v.knowledgeEvents,e.wordId)?.id!==e.id||knownLedgerSignature({schema:1,knowledgeEvents:{[e.id]:e}})!==knownLedgerSignature({schema:1,knowledgeEvents:{[e.id]:v.knowledgeEvents[e.id]}}))||Object.values(v.knowledgeEvents).some(e=>Number.isFinite(e?.at)&&e.at>=events[0].at&&e.knownBatch!==batch))return null;
    return {owner:expected,changes:clone(changes),batch,eventIds:events.map(e=>e.id),signature};
    }catch(_){return null;}
  }
  function undoSnapshotCurrent(snapshot){
    if(!snapshot||snapshot.owner!==owner()||workflowBlocked())return false;
    try{
      const current=vault(false);
      if(knownLedgerSignature(current)!==snapshot.signature)return false;
      if(snapshot.eventIds.some(id=>current.knowledgeEvents[id]?.knownBatch!==snapshot.batch))return false;
      if(asyncProfile())return knownLedgerSignature(W.GH_PROGRESS45.snapshot?.()?.v4?.reviewWorkflowR2)===snapshot.signature;
      const storageKey=W.GH_PROGRESS45?.KEY;if(!storageKey)return false;
      const raw=W.localStorage.getItem(storageKey);if(!raw)return false;
      const stored=JSON.parse(raw);
      return JSON.stringify([stored._save45?.profileId||'',stored._save45?.epoch||''])===snapshot.owner&&knownLedgerSignature(stored.v4?.reviewWorkflowR2)===snapshot.signature;
    }catch(_){return false;}
  }
  function recoverKnownUndo(){
    if(undoKnown||workflowBlocked()||undoRecoveryBlockedOwner===owner())return;
    let events,eventMap;try{eventMap=vault(false)?.knowledgeEvents||{};events=Object.values(eventMap);}catch(_){return;}
    const own=events.filter(e=>e&&e.knownBatchOwner===owner()&&typeof e.knownBatch==='string'&&Number.isFinite(e.at)).sort((a,b)=>b.at-a.at||String(b.id).localeCompare(String(a.id)));
    const last=own[0];if(!last||last.knownBatchVersion!==3||last.knownBatchAction!=='change')return;
    // Concurrent batches with tied clocks, and pre-v3 metadata, have no
    // trustworthy total order. Never pick an undo by a random event ID.
    if(events.some(e=>Number.isFinite(e?.at)&&e.at>=last.at&&e.knownBatch!==last.knownBatch))return;
    const batch=own.filter(e=>e.knownBatch===last.knownBatch);
    if(!Number.isInteger(last.knownBatchSize)||last.knownBatchSize!==batch.length||new Set(batch.map(e=>knownKey(e.wordId))).size!==batch.length||batch.some(e=>typeof e.id!=='string'||!e.id||!Object.prototype.hasOwnProperty.call(eventMap,e.id)||eventMap[e.id]!==e||typeof e.known!=='boolean'||typeof e.wordId!=='string'||typeof e.sourceWordId!=='string'||!Object.prototype.hasOwnProperty.call(byId,e.sourceWordId)||!Number.isSafeInteger(e.at)||!latestKnown(eventMap,e.wordId)||e.knownBatchVersion!==3||e.at!==last.at||e.knownBatchSize!==batch.length||e.knownBatchAction!=='change'||typeof e.previousKnown!=='boolean'||!byId[e.sourceWordId]||knownKey(key(e.sourceWordId))!==e.wordId||latestKnown(vault(false)?.knowledgeEvents,e.wordId)?.id!==e.id))return;
    undoKnown=captureKnownUndo(batch.map(e=>({id:e.sourceWordId,known:e.previousKnown})),batch,owner());
  }
  function applyKnownChanges(changes, expected, remember=true,precondition=null) {
    if(asyncProfile())return asyncRequired;
    if(workflowBlocked())return {ok:false,uncertain:true,reason:uncertaintyMessage};
    if (expected !== owner() || !profileCurrent(expected)) return {ok:false, reason:'This page is stale. Reopen vocabulary before changing it.'};
    if (!changes.length || changes.some(x=>!byId[x.id])) return {ok:false, reason:'No valid words selected.'};
    const groups=new Map();
    for(const x of changes) if(!groups.has(knownKey(key(x.id)))) groups.set(knownKey(key(x.id)),x);
    const events=[],previous=[];
    try {
      for(const [group,x] of groups){
        const current=latestKnown(vault(false)?.knowledgeEvents,group);
        if((current?.known===true)===!!x.known)continue;
        previous.push({id:x.id,known:current?.known===true});
        events.push({id:uuid(),wordId:group,sourceWordId:x.id,known:!!x.known,at:Math.max(Date.now(),(current?.at||0)+1),evidence:'self-reported; no mastery, listening evidence or XP'});
      }
    }catch(error){return {ok:false,reason:clean(error.message,500)};}
    if(!events.length)return {ok:true,unchanged:true};
    // Advance across the entire ledger, not only the changed groups. Disjoint
    // batches remain ordered even in one millisecond or after a clock rollback.
    let newest=Date.now();
    for(const event of Object.values(vault(false)?.knowledgeEvents||{}))if(Number.isFinite(event?.at))newest=Math.max(newest,event.at);
    const at=Math.floor(newest)+1;
    if(!Number.isSafeInteger(at)||at<=newest)return {ok:false,reason:'Known history has an unsupported timestamp. Keep a recovery backup; no save was attempted.'};
    const batch=uuid();
    events.forEach((event,i)=>Object.assign(event,{at,knownBatchVersion:3,knownBatch:batch,knownBatchOwner:expected,knownBatchSize:events.length,knownBatchAction:remember?'change':'undo',previousKnown:previous[i].known}));
    const result=persistMutation(v=>{if(precondition&&!precondition())throw Error('Known history changed or could not be checked. No undo was attempted. Reload before choosing another undo.');for(const event of events)v.knowledgeEvents[event.id]=event;});
    if(!result.ok){notify(result.reason);if(result.uncertain&&typeof render==='function')render();return result;}
    undoKnown=remember?captureKnownUndo(previous,events,expected):null;
    undoRecoveryBlockedOwner=remember&&!undoKnown?expected:null;
    // Leave frozen assignments and all earned evidence unchanged.
    const knownGroups=new Set(events.filter(x=>x.known).map(x=>x.wordId));
    if(typeof trainer!=='undefined'&&trainer&&['learn','new','check','chapter-new'].includes(trainer.kind)){
      const from=trainer.i;
      trainer.queue=trainer.queue.filter((id,i)=>i<from||!knownGroups.has(knownKey(key(id))));
      if(trainer.encounters452){
        trainer.encounters452.slots=trainer.encounters452.slots.filter((slot,i)=>i<from||!knownGroups.has(knownKey(key(slot.id))));
        trainer.encounters452.selected=trainer.encounters452.selected.filter(id=>!knownGroups.has(knownKey(key(id))));
      }
    }
    notify(remember?'Self-reported known updated. No XP, listening credit or mastery awarded. '+(undoKnown?'Undo is available for this change.':'An undo could not be verified. Reload to review the saved status.'):'Last known change undone. Earned learning evidence is unchanged.');
    if(typeof render==='function')render();
    return {...result,events};
  }
  async function applyKnownChangesAsync(changes, expected, remember=true,precondition=null) {
    if(workflowBlocked())return {ok:false,uncertain:true,reason:uncertaintyMessage};
    if (expected !== owner() || !profileCurrent(expected)) return {ok:false, reason:'This page is stale. Reopen vocabulary before changing it.'};
    if (!changes.length || changes.some(x=>!byId[x.id])) return {ok:false, reason:'No valid words selected.'};
    const groups=new Map();
    for(const x of changes) if(!groups.has(knownKey(key(x.id)))) groups.set(knownKey(key(x.id)),x);
    const events=[],previous=[];
    try {
      for(const [group,x] of groups){
        const current=latestKnown(vault(false)?.knowledgeEvents,group);
        if((current?.known===true)===!!x.known)continue;
        previous.push({id:x.id,known:current?.known===true});
        events.push({id:uuid(),wordId:group,sourceWordId:x.id,known:!!x.known,at:Math.max(Date.now(),(current?.at||0)+1),evidence:'self-reported; no mastery, listening evidence or XP'});
      }
    }catch(error){return {ok:false,reason:clean(error.message,500)};}
    if(!events.length)return {ok:true,unchanged:true};
    // Advance across the entire ledger, not only the changed groups. Disjoint
    // batches remain ordered even in one millisecond or after a clock rollback.
    let newest=Date.now();
    for(const event of Object.values(vault(false)?.knowledgeEvents||{}))if(Number.isFinite(event?.at))newest=Math.max(newest,event.at);
    const at=Math.floor(newest)+1;
    if(!Number.isSafeInteger(at)||at<=newest)return {ok:false,reason:'Known history has an unsupported timestamp. Keep a recovery backup; no save was attempted.'};
    const batch=uuid();
    events.forEach((event,i)=>Object.assign(event,{at,knownBatchVersion:3,knownBatch:batch,knownBatchOwner:expected,knownBatchSize:events.length,knownBatchAction:remember?'change':'undo',previousKnown:previous[i].known}));
    const result=await persistMutationAsync(v=>{if(precondition&&!precondition())throw Error('Known history changed or could not be checked. No undo was attempted. Reload before choosing another undo.');for(const event of events)v.knowledgeEvents[event.id]=event;});
    if(!result.ok){notify(result.reason);if(result.uncertain&&typeof render==='function')render();return result;}
    undoKnown=remember?captureKnownUndo(previous,events,expected):null;
    undoRecoveryBlockedOwner=remember&&!undoKnown?expected:null;
    // Leave frozen assignments and all earned evidence unchanged.
    const knownGroups=new Set(events.filter(x=>x.known).map(x=>x.wordId));
    if(typeof trainer!=='undefined'&&trainer&&['learn','new','check','chapter-new'].includes(trainer.kind)){
      const from=trainer.i;
      trainer.queue=trainer.queue.filter((id,i)=>i<from||!knownGroups.has(knownKey(key(id))));
      if(trainer.encounters452){
        trainer.encounters452.slots=trainer.encounters452.slots.filter((slot,i)=>i<from||!knownGroups.has(knownKey(key(slot.id))));
        trainer.encounters452.selected=trainer.encounters452.selected.filter(id=>!knownGroups.has(knownKey(key(id))));
      }
    }
    notify(remember?'Self-reported known updated. No XP, listening credit or mastery awarded. '+(undoKnown?'Undo is available for this change.':'An undo could not be verified. Reload to review the saved status.'):'Last known change undone. Earned learning evidence is unchanged.');
    if(typeof render==='function')render();
    return {...result,events};
  }
  function setKnown(id,known,expected=lastRenderOwner){const result=applyKnownChanges([{id,known}],expected);return {...result,event:result.events?.[0]||null};}
  function undoKnownChange(){
    if(asyncProfile())return asyncRequired;
    recoverKnownUndo();
    if(!undoKnown)return {ok:false,reason:'No known change to undo.'};
    const snapshot=undoKnown,guard=()=>undoSnapshotCurrent(snapshot);
    if(!guard()){undoKnown=null;undoRecoveryBlockedOwner=owner();return {ok:false,reason:'Known history changed or could not be checked. No undo was attempted. Reload before choosing another undo.'};}
    const result=applyKnownChanges(snapshot.changes,snapshot.owner,false,guard);
    if(!result.ok&&!result.uncertain){undoKnown=null;undoRecoveryBlockedOwner=owner();}
    if(result.ok){undoKnown=null;if(typeof render==='function')render();}
    return result;
  }
  async function undoKnownChangeAsync(){
    recoverKnownUndo();
    if(!undoKnown)return {ok:false,reason:'No known change to undo.'};
    const snapshot=undoKnown,guard=()=>undoSnapshotCurrent(snapshot);
    if(!guard()){undoKnown=null;undoRecoveryBlockedOwner=owner();return {ok:false,reason:'Known history changed or could not be checked. No undo was attempted. Reload before choosing another undo.'};}
    const result=await applyKnownChangesAsync(snapshot.changes,snapshot.owner,false,guard);
    if(!result.ok&&!result.uncertain){undoKnown=null;undoRecoveryBlockedOwner=owner();}
    if(result.ok){undoKnown=null;if(typeof render==='function')render();}
    return result;
  }
  async function setKnownAsync(id,known,expected=lastRenderOwner){const result=await applyKnownChangesAsync([{id,known}],expected);return {...result,event:result.events?.[0]||null};}
  let bulkKnown=null;
  function bulkContext(){
    const chapter=Number(typeof vocabFilter==='object'?vocabFilter.chapter:0);
    if(!installedChapterSem2(chapter)){bulkKnown=null;return null;}
    if(!bulkKnown||bulkKnown.owner!==owner()||bulkKnown.chapter!==chapter)bulkKnown={owner:owner(),chapter,selected:[],page:0};
    return bulkKnown;
  }
  function bulkKnownHTML(){
    const b=bulkContext();if(!b)return '';
    const ids=chapterIds(b.chapter),pages=Math.max(1,Math.ceil(ids.length/25));b.page=Math.min(b.page,pages-1);
    const page=ids.slice(b.page*25,(b.page+1)*25);
    return `<section class="card" data-bulk-known><h2>Mark a block as known · Chapter ${b.chapter}</h2><p>Select source rows below. This list includes the whole chapter, independent of Bank, Status and Search above. Shared recall groups change together, including equivalent rows in other chapters. No XP or mastery is awarded.</p><div class="actions"><button type="button" data-bulk-action="all">Select whole chapter</button><button type="button" data-bulk-action="page">Select this page</button><button type="button" data-bulk-action="clear">Clear selection</button></div><div class="actions"><label>First row <input id="bulkKnownFirst" type="number" min="1" max="${ids.length}" value="1"></label><label>Last row <input id="bulkKnownLast" type="number" min="1" max="${ids.length}" value="${Math.min(25,ids.length)}"></label><button type="button" data-bulk-action="range">Select range</button></div><p role="status">${b.selected.length} selected source rows · ${new Set(b.selected.map(key)).size} shared recall groups</p><div class="actions"><button type="button" data-bulk-action="prev" ${b.page?'':'disabled'}>Previous block</button><span>Page ${b.page+1} / ${pages}</span><button type="button" data-bulk-action="next" ${b.page+1<pages?'':'disabled'}>Next block</button></div>${page.map((id,i)=>`<label style="display:block"><input type="checkbox" data-bulk-word="${esc(id)}" ${b.selected.includes(id)?'checked':''}> ${b.page*25+i+1}. <span lang="ar">${esc(byId[id].ar)}</span> · ${esc(byId[id].en)}${isKnown(id)?' (already known)':''}</label>`).join('')}<button type="button" data-bulk-action="mark" ${b.selected.length&&!workflowBlocked()?'':'disabled'}>Mark selected as known</button></section>`;
  }
  D.addEventListener('change',ev=>{
    const el=ev.target;if(!el?.dataset?.bulkWord)return;
    const b=bulkKnown;if(!b||b.owner!==owner()||b.chapter!==Number(vocabFilter.chapter)||!profileCurrent(b.owner))return;
    const id=el.dataset.bulkWord;if(!chapterIds(b.chapter).includes(id))return;
    b.selected=el.checked?unique([...b.selected,id]):b.selected.filter(x=>x!==id);render();
  });
  D.addEventListener('click',async ev=>{
    const el=ev.target.closest?.('[data-bulk-action]');if(!el||el.disabled)return;
    ev.preventDefault();ev.stopImmediatePropagation();
    const b=bulkKnown;if(!b||b.owner!==owner()||b.chapter!==Number(vocabFilter.chapter)||!profileCurrent(b.owner)){notify('This chapter selection is stale. Reopen vocabulary.');return;}
    const ids=chapterIds(b.chapter),action=el.dataset.bulkAction;
    if(action==='all')b.selected=[...ids];
    if(action==='page')b.selected=unique([...b.selected,...ids.slice(b.page*25,(b.page+1)*25)]);
    if(action==='clear')b.selected=[];
    if(action==='prev')b.page=Math.max(0,b.page-1);
    if(action==='next')b.page=Math.min(Math.ceil(ids.length/25)-1,b.page+1);
    if(action==='range'){
      const first=Number(D.getElementById('bulkKnownFirst').value),last=Number(D.getElementById('bulkKnownLast').value);
      if(!Number.isInteger(first)||!Number.isInteger(last)||first<1||last<first||last>ids.length){notify('Choose a valid inclusive row range within this chapter.');return;}
      b.selected=unique([...b.selected,...ids.slice(first-1,last)]);
    }
    if(action==='mark'){
      const selected=[...b.selected];if(!selected.length||selected.some(id=>!ids.includes(id)))return;
      if(!W.confirm(`Mark ${selected.length} source rows (${new Set(selected.map(key)).size} shared recall groups) as self-reported known? Equivalent rows share this status. No XP, listening credit or mastery will be awarded. You can undo this batch.`))return;
      const result=await applyKnownChangesAsync(selected.map(id=>({id,known:true})),b.owner);
      if(result.ok)b.selected=[];else notify(result.reason);
    }
    render();
  },true);
  function selectionPermit(id) {
    return !!(permit && permit.owner === owner() && permit.ids.includes(id) && permit.expires >= Date.now());
  }
  function pendingScope(){return permit?.owner===owner()&&permit.scope?clone(permit.scope):null;}
  function sourceAdmissionBlocked(id) { const bad=k=>{const x=byId[k];return !x||(x.sourceHold===true&&!['quizlet','memrise'].includes(x.bank))||!!x.conflict||!!x.sourceRow?.conflict;};try{if(bad(id))return true;const target=typeof canonicalId==='function'?canonicalId(id):id;return bad(target);}catch{return true;} }
  function newEligible(id) {
    if (sourceAdmissionBlocked(id) || isKnown(id)) return false;
    const l=typeof learningRec==='function'?learningRec(id):state.learning?.[key(id)]||{};
    const r=typeof rec==='function'?rec(id):state.cards?.[key(id)]||{};
    return !l.learned && !(Array.isArray(l.six452)&&l.six452.length===6&&l.six452.every(done=>done===true)) && !r.seen && !r.firstRetrieved;
  }
  function installedChapterSem2(n){
    return Number.isInteger(n)&&((n>=1&&n<=15)||(n>=16&&n<=25&&W.GH_CH16_25?.ready)||(n>=26&&n<=50&&W.GH_SEM2_INTEGRATION?.ready&&W.GH_SEM2_INTEGRATION.rows.some(r=>r.chapter===n)));
  }
  function chapterIds(chapter, mode='review') {
    const n=Number(chapter);
    if(!installedChapterSem2(n))return [];
    return Object.values(byId).filter(x=>Number(x.chapter)===n&&!sourceAdmissionBlocked(x.id)&&(mode!=='new'||newEligible(x.id))).map(x=>x.id);
  }
  function scopeCurrent(s) {
    if(!s||!profileCurrent(s.owner))return false;
    if(s.source==='required-stage-filter'){const selected=s.scheduledAssignment;if(!selected||JSON.stringify(W.ICPT_STAGE2?.model?.()?.snapshot)!==selected.assignment)return false;}
    if(s.source==='scheduled-pages')return W.GH_WEEKLY_SCHEDULE?.validateStudySelection?.(s.selectionToken,s.requestedIds)===true;
    if(s.source==='next-class'){
      const n=W.GH_WEEKLY_SCHEDULE?.nextClass?.(),ids=n?.vocabulary?.sourceIds||n?.vocabulary?.ids||[];
      return n?.date===s.date&&n?.versionId===s.versionId&&s.requestedIds.every(id=>ids.includes(id));
    }
    return true;
  }
  function openBlock(s,offset=0) {
    // A failed save is not an ID mismatch. Preserve all activity/save guards.
    const saveStatus=W.GH_PROGRESS45?.getStatus?.();
    if(saveStatus?.ok===false){
      notify(saveStatus.ready===true&&saveStatus.pending===true&&!saveStatus.readError&&!saveStatus.reloadRequired
        ?'Your progress is still saving. Keep this tab open and try this selection again after saving finishes. No activity was launched.'
        :'Practice is paused because your progress could not be saved. Keep this tab open. Open Save & recovery and download a full progress backup, then resolve the save error and retry. No replacement words were launched.');return false;
    }
    if(!Array.isArray(s?.allIds)||s.allIds.slice(offset).some(sourceAdmissionBlocked)){notify('This selection contains a held or conflicted source. Nothing launched.');return false;}
    if(!scopeCurrent(s)){notify('This saved selection or hunter changed. Return to the selection screen; no replacement queue was opened.');return false;}
    const size=offset===0&&s.resumeChapter452&&Number.isInteger(s.resumeBlockSize452)?Math.min(15,Math.max(1,s.resumeBlockSize452)):15;
    const expected=s.allIds.slice(offset,offset+size);
    if(!expected.length){notify('All words in this exact selection have been reached. No unrelated words were added.');return false;}
    const blockScope={...s,blockOffset:offset,nextOffset:offset+expected.length,selectedIds:[...expected],actualIds:[...expected],outsideIds:[],skippedIds:[],schema:2};
    permit={ids:expected,owner:s.owner,expires:Date.now()+5000,scope:blockScope};
    let result;
    try{W.GH457_AUDIO_QUEUE?.setStudySet?.(s.allIds,{source:s.source,owner:s.owner,mode:s.mode});result=startSession(s.mode==='new'?'chapter-new':s.mode==='chapter-review'?'chapter-review':'selection',expected);}finally{permit=null;}
    if(result===false||!Array.isArray(result)){
      W.GH457_AUDIO_QUEUE?.cancel?.('activity admission stopped');
      if(typeof trainer!=='undefined')trainer=null;
      const stoppedStatus=W.GH_PROGRESS45?.getStatus?.();
      const saveFailed=stoppedStatus?.ok===false;
      if(saveFailed&&stoppedStatus.ready===true&&stoppedStatus.pending===true&&!stoppedStatus.readError&&!stoppedStatus.reloadRequired){
        notify('Your progress is still saving. Keep this tab open and try this selection again after saving finishes. No replacement activity was launched.');return false;
      }
      notify(saveFailed?'Practice is paused because your progress could not be saved. Keep this tab open. Open Save & recovery and download a full progress backup, then resolve the save error and retry. No replacement words were launched.':'Practice was stopped by a progress or review-identity safety check. No replacement words were launched. Keep this tab open, download a full progress backup in Save & recovery, and reopen this selection after resolving the safety warning.');return false;
    }
    const actual=result,validation=validateScope(expected,actual);
    if(!validation.ok||actual.length!==expected.length||actual.some((id,i)=>id!==expected[i])){
      W.GH457_AUDIO_QUEUE?.cancel?.('invalid exact selection');
      if(typeof trainer!=='undefined')trainer=null;
      notify('The actual launched IDs did not match this exact block. The block was stopped; no full-queue substitution was made.');return false;
    }
    lastScope=blockScope;
    if(typeof trainer!=='undefined'&&trainer)trainer.selectionR2=clone(lastScope);
    return [...actual];
  }
  function launchExact(ids, meta = {}) {
    const requested = unique(ids);
    if(requested.some(id=>sourceAdmissionBlocked(id))){notify('This selection includes a source-review hold. Review its source before graded practice. Nothing launched.');return false;}
    if(requested.some(id=>!byId[id])){notify('This selection contains an unavailable word ID. Nothing was substituted or launched.');return false;}
    if (!requested.length || !profileCurrent(owner())) { notify('No exact checked vocabulary selection is available, or this page is stale. Nothing was launched.'); return false; }
    const now = typeof localDay === 'function' ? localDay() : '', shown = typeof day === 'function' ? day() : now;
    if (shown !== now) { notify('Return to the current date before starting practice. Preview dates cannot create study credit.'); return false; }
    if (meta.source === 'next-class') {
      const next = W.GH_WEEKLY_SCHEDULE?.nextClass?.();
      const checkedIds = next?.vocabulary?.sourceIds || next?.vocabulary?.ids || [];
      if (meta.sourceChecked !== true || !next || meta.date !== next.date || meta.versionId !== next.versionId || !requested.every(id => checkedIds.includes(id))) {
        notify('The checked next-class selection changed. Review the current saved schedule before starting.'); return false;
      }
    }
    const candidates=meta.mode==='new'?requested.filter(newEligible):requested;
    // Completed steps and XP are shared by the existing canonical group.
    // Practice one explicitly chosen source form per new-learning group,
    // rather than falsely counting skipped aliases as independent encounters.
    const seenGroups=new Set(),allIds=meta.mode==='new'?candidates.filter(id=>{const group=key(id);if(seenGroups.has(group))return false;seenGroups.add(group);return true;}):candidates;
    if(!allIds.length){notify('No eligible new words in this chapter. Already learned and self-reported known words remain available in chapter review. Nothing else was added.');return false;}
    const s={schema:2,owner:owner(),source:clean(meta.source||'selection',100),mode:meta.mode||'chapter-review',date:meta.date||null,
      versionId:meta.versionId||null,selectionToken:meta.selectionToken||null,chapter:meta.chapter||null,
      resumeChapter452:meta.resumeChapter452===true,resumeBlockSize452:meta.resumeBlockSize452||null,
      requestedIds:requested,allIds,excludedNewIds:requested.filter(id=>!allIds.includes(id)),
      scheduledAssignment:meta.scheduledAssignment?clone(meta.scheduledAssignment):null,
      selectedRanges:meta.selectedRanges?clone(meta.selectedRanges):null,
      filterSnapshot:meta.filterSnapshot?clone(meta.filterSnapshot):null};
    return openBlock(s,0);
  }
  function continueExact() {
    const now=typeof localDay==='function'?localDay():'',shown=typeof day==='function'?day():now;
    if(shown!==now){notify('Return to the current date before continuing this selection. Preview dates keep the existing block paused.');return false;}
    const s=typeof trainer!=='undefined'?trainer?.selectionR2:null;
    if(!s||trainer.i<trainer.queue.length){notify('Complete the current block before continuing this selection.');return false;}
    if(!pickerContinuationAllowedR8(s)){notify('The source membership for this selection changed. Reopen the same source list before continuing. No outside words were substituted.');return false;}
    if(s.allIds.slice(s.nextOffset).some(sourceAdmissionBlocked)){notify('This selection contains a held or conflicted source. Nothing launched.');return false;}
    if(s.mode==='new'){
      const remaining=s.allIds.slice(s.nextOffset).filter(newEligible);
      const skipped=s.allIds.slice(s.nextOffset).filter(id=>!remaining.includes(id));
      s.excludedNewIds=unique([...(s.excludedNewIds||[]),...skipped]);
      s.allIds=[...s.allIds.slice(0,s.nextOffset),...remaining];
    }
    if(s.mode==='scheduled-review'){
      const active=s.source==='required-stage-filter'?(W.ICPT_STAGE2?.model?.()?.rows.find(r=>r.key===s.scheduledAssignment?.stage)?.remaining||[]):unique([...dueItems(),...firstQueue(),...checkQueue()].map(x=>x.id));
      const remaining=s.allIds.slice(s.nextOffset).filter(id=>active.includes(id));
      s.excludedNewIds=unique([...(s.excludedNewIds||[]),...s.allIds.slice(s.nextOffset).filter(id=>!remaining.includes(id))]);
      s.allIds=[...s.allIds.slice(0,s.nextOffset),...remaining];
    }
    return openBlock(s,s.nextOffset);
  }
  // Resume only a validated unfinished block from this exact chapter. Do not
  // refill it as completed source rows disappear from the new-word list.
  function chapterResume452(chapter, available) {
    const old=state.learningSession452;
    if(old?.schema!==1||old.owner!==(state._save45?.profileId||'')||old.date!==day()||old.kind!=='chapter-new'||!Array.isArray(old.selected)||!old.selected.length||old.selected.length>15||new Set(old.selected).size!==old.selected.length||!old.selected.every(id=>typeof id==='string'&&Number(byId[id]?.chapter)===Number(chapter))||!Array.isArray(old.remaining)||old.remaining.length>90)return null;
    const steps=id=>{const l=typeof learningRec==='function'?learningRec(id):state.learning?.[key(id)]||{};return Array.from({length:6},(_,i)=>l.six452?.[i]===true);};
    if(!old.remaining.every(slot=>slot&&old.selected.includes(slot.id)&&Number.isInteger(slot.step)&&slot.step>=0&&slot.step<6))return null;
    const pending=old.remaining.filter(slot=>!steps(slot.id)[slot.step]),token=slot=>JSON.stringify([slot.id,slot.step]),tokens=pending.map(token),expected=old.selected.flatMap(id=>steps(id).flatMap((done,step)=>done?[]:[token({id,step})])),last=new Map();
    if(!pending.length||new Set(tokens).size!==tokens.length||JSON.stringify([...tokens].sort())!==JSON.stringify(expected.sort()))return null;
    for(const slot of pending){if(!available.includes(slot.id)||(last.get(slot.id)??-1)>=slot.step)return null;last.set(slot.id,slot.step);}
    return old.selected.filter(id=>pending.some(slot=>slot.id===id));
  }
  function launchChapter(chapter,mode='review') {
    const ids=chapterIds(chapter,mode),resume=mode==='new'?chapterResume452(chapter,ids):null;
    const ordered=resume?[...resume,...ids.filter(id=>!resume.includes(id))]:ids;
    return launchExact(ordered,{source:'whole-chapter',chapter:Number(chapter),mode:mode==='new'?'new':'chapter-review',resumeChapter452:!!resume,resumeBlockSize452:resume?.length||null});
  }
  function chapterControlsHTML() {
    recoverKnownUndo();
    const selected=Number(typeof vocabFilter==='object'?vocabFilter.chapter:0),valid=installedChapterSem2(selected);
    return `<section class="card r3-chapter-study"><h2>Whole-chapter study</h2>${uncertaintyHTML()}<p>Separate from tomorrow’s assigned pages. Choose a chapter above to study every installed source entry in it; the Source, Status and Search filters apply only to “Study filtered set.”</p>${valid?`<div class="actions"><button type="button" data-r2-action="chapter-review" data-chapter="${selected}">Study/review this chapter (${chapterIds(selected).length})</button><button type="button" data-r2-action="chapter-new" data-chapter="${selected}" ${chapterIds(selected,'new').length?'':'disabled'}>Learn new words from this chapter (${chapterIds(selected,'new').length})</button></div>`:'<p>Select one installed chapter (not All or a whole Unit) to see chapter counts and actions.</p>'}<p class="mini">New = not completed in the saved learning record, not previously recorded as learned/retrieved, and not self-reported known. Introduced but unfinished words remain eligible. New learning practices one chosen source form per shared group, without claiming every alternate form was independently practiced. Mark as known is reversible and never grants XP, listening credit or demonstrated mastery.</p>${undoKnown?.owner===owner()?'<div class="actions" data-r2-known-undo-toolbar><button type="button" data-r2-action="undo-known">Undo last known change</button></div>':''}</section>`;
  }
  function controlsHTML(id, placement = 'review') {
    recoverKnownUndo();
    if (!byId[id]) return '';
    const known = isKnown(id);
    return `<div class="r2-word-tools actions" data-r2-word="${esc(id)}" data-r2-placement="${esc(placement)}"><button type="button" data-r2-action="report" data-word="${esc(id)}">Report this word</button><button type="button" data-r2-action="known" ${workflowBlocked()?'disabled':''} data-word="${esc(id)}" aria-pressed="${known}">${known ? 'Needs practice' : 'Mark as known'}</button>${undoKnown?.owner===owner()?'<button type="button" data-r2-action="undo-known">Undo last known change</button>':''}${uncertaintyHTML()}${known ? '<span class="mini">Self-reported known · not certified mastery</span>' : ''}${placement === 'review' ? '<span class="mini" id="r2PracticeResult" role="status" aria-live="polite"></span>' : ''}</div>`;
  }
  function isVisible(el) {
    if (!el || el.nodeType !== 1) return false;
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      if (node.hidden || node.getAttribute?.('aria-hidden') === 'true') return false;
      if (['SCRIPT','STYLE','TEMPLATE','NOSCRIPT'].includes(node.tagName)) return false;
      const style = W.getComputedStyle ? W.getComputedStyle(node) : node.style;
      if (style && (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' || style.opacity === '0')) return false;
      if (node.tagName === 'DETAILS' && !node.open) {
        const summary = Array.from(node.children || []).find(x => x.tagName === 'SUMMARY');
        if (el !== node && !(summary && (el === summary || summary.contains(el)))) return false;
      }
    }
    return true;
  }
  function visibleText(root) {
    if (!root || !isVisible(root)) return '';
    function walk(node) {
      if (node.nodeType === 3) return clean(node.nodeValue);
      if (node.nodeType !== 1 || !isVisible(node) || ['INPUT','TEXTAREA','SELECT'].includes(node.tagName) || node.matches?.('.r2-word-tools,.r2-study-scope')) return '';
      if (node.tagName === 'DETAILS' && !node.open) {
        const summary = Array.from(node.children || []).find(x => x.tagName === 'SUMMARY');
        return summary ? walk(summary) : '';
      }
      return Array.from(node.childNodes || []).map(walk).join(' ');
    }
    return normalizeText(walk(root));
  }
  function visibleSnapshot(root) {
    const texts = selector => unique(Array.from(root?.querySelectorAll?.(selector) || []).map(visibleText).filter(Boolean)).join('\n');
    return {definition:texts('[data-r2-visible-definition],.lesson-prompt452 > strong') || null,
      context:texts('.wordhint43,.ctx453-anatomy,.ctx453,[data-r2-visible-context]') || null, screenText:visibleText(root)};
  }
  function activeWord() { return typeof trainer !== 'undefined' && trainer && trainer.i < trainer.queue.length ? byId[trainer.queue[trainer.i]] : null; }
  function stageLabel() {
    const x = activeWord();
    if (!x || typeof tab === 'undefined' || tab !== 'recall') return typeof tab === 'string' ? tab : 'vocabulary';
    const lesson = D.querySelector('.lesson452');
    return lesson ? 'guided vocabulary step ' + W.ICPT_LESSON452?.completion?.(x.id) : 'vocabulary ' + trainer.kind + ' / ' + trainer.phase + (trainer.revealed ? ' / feedback' : ' / pre-answer');
  }
  function reportSnapshot(id, root) {
    let audio = null;
    try { audio = W.GH457_AUDIO?.reportSnapshot?.({id, text:byId[id]?.speech, kind:'vocabulary'}) || W.GH457_AUDIO?.resolve?.({id, text:byId[id]?.speech, kind:'vocabulary'}); } catch (_) {}
    return makeReport({id:uuid(), build:build(), wordId:id, canonicalWordId:key(id), stage:stageLabel(),
      visible:visibleSnapshot(root), audio, comment:'', at:new Date().toISOString()});
  }
  function download(obj, name) {
    const url = URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)], {type:'application/json'}));
    const a = D.createElement('a'); a.href=url; a.download=name; a.click();
    W.setTimeout(() => URL.revokeObjectURL(url),5000);
    return {filename:name, bytes:new Blob([JSON.stringify(obj,null,2)]).size};
  }
  function reports() { try { return Object.values(vault(false)?.reports || {}).map(clone).sort((a,b)=>String(a.at).localeCompare(String(b.at))); } catch (_) { return []; } }
  function saveReport(report, expected) {
    if (!report || expected !== owner()) return {ok:false, reason:'The active hunter changed. Export this draft if needed, then reopen the report in the intended profile.'};
    if (!clean(report.comment,4000).trim()) return {ok:false, reason:'Add a short comment describing the problem before saving.'};
    return persistMutation(v => { v.reports[report.id] = clone(report); });
  }
  async function saveReportAsync(report, expected) {
    if (!report || expected !== owner()) return {ok:false, reason:'The active hunter changed. Export this draft if needed, then reopen the report in the intended profile.'};
    if (!clean(report.comment,4000).trim()) return {ok:false, reason:'Add a short comment describing the problem before saving.'};
    return persistMutationAsync(v => { v.reports[report.id] = clone(report); });
  }
  function closeDialog() {
    if (dialog) { try { dialog.close?.(); } catch (_) {} dialog.remove(); }
    dialog=null; draftReport=null;
  }
  function openReport(id, root) {
    if (!byId[id] || lastRenderOwner !== owner()) { notify('Reopen the active hunter before reporting. The visible page belongs to another profile.'); return false; }
    closeDialog();
    draftReport = {report:reportSnapshot(id, root), owner:owner(), saved:false};
    dialog = D.createElement('dialog'); dialog.id='r2WordReport'; dialog.className='card r2-word-report';
    dialog.style.cssText='max-width:min(720px,94vw);max-height:90vh;overflow:auto;color:var(--ink,#eee);background:var(--panel,#111827);border:1px solid #657080;border-radius:12px';
    const shown = draftReport.report.displayed;
    dialog.innerHTML = `<h2>Report this word</h2><p class="mini">Word ID: ${esc(id)} · ${esc(build())}</p><p>Only the text already visible in your review is captured. Opening this report does not reveal the answer.</p><p><b>Displayed definition:</b> ${shown.definition ? esc(shown.definition) : 'Hidden or not separately displayed — omitted.'}</p><p><b>Displayed context:</b> ${shown.context ? esc(shown.context) : 'Hidden or not displayed — omitted.'}</p><p class="mini">Current audio-route metadata is attached to the report, with no hidden model text. Reports stay on this browser until you export and send them.</p><label for="r2WordComment">What needs correction?</label><textarea id="r2WordComment" rows="4" maxlength="4000" style="width:100%" placeholder="Describe the audio, wording, context, or other problem you noticed."></textarea><p id="r2ReportResult" role="status" aria-live="polite"></p><div class="actions"><button type="button" data-r2-action="save-report">Save report on this browser</button><button type="button" data-r2-action="export-report">Export this report</button><button type="button" data-r2-action="export-reports">Export all saved word reports</button><button type="button" data-r2-action="close-report">Close</button></div>`;
    D.body.append(dialog);
    try { if (typeof dialog.showModal === 'function') dialog.showModal(); else dialog.setAttribute('open',''); } catch (_) { dialog.setAttribute('open',''); }
    D.getElementById('r2WordComment')?.focus();
    return clone(draftReport.report);
  }
  function updateReportComment() {
    if (draftReport) draftReport.report.comment = clean(D.getElementById('r2WordComment')?.value,4000);
  }
  function scopeHTML() {
    const s = typeof trainer !== 'undefined' && trainer?.selectionR2;
    if (!s) return '';
    const ids = unique(trainer.encounters452?.selected || s.selectedIds || s.actualIds || trainer.queue);
    const filter = s.filterSnapshot;
    const total=s.allIds?.length||s.requestedIds?.length||ids.length,offset=s.blockOffset||0;
    return `<div class="r2-study-scope mini"><b>${['next-class','scheduled-pages'].includes(s.source) ? 'Scheduled lesson · '+esc(s.date) : s.source==='whole-chapter'?'Chapter '+esc(s.chapter)+(s.mode==='new'?' · new learning':' · optional review'):'Selected study set'}</b> · ${ids.length} source entries in this block (${offset+1}–${Math.min(offset+ids.length,total)} of ${total}). No outside words are added.${s.mode==='new'?' One chosen source form per shared learning group; completion does not independently verify every alternate form.':''}${filter ? ' Pinned filter: chapter '+esc(filter.chapter)+' · '+esc(filter.scope)+(filter.status?' · '+esc(filter.status):'')+(filter.search?' · search '+esc(filter.search):'')+'.' : ''}<details><summary>Exact source IDs in this block</summary>${esc(ids.join(', '))}</details>${s.scheduledAssignment?'<details><summary>Original scheduled assignment and selected page range</summary><pre>'+esc(JSON.stringify({scheduled:s.scheduledAssignment,selected:s.selectedRanges},null,2))+'</pre></details>':''}</div>`;
  }
  function attemptState() {
    const x=activeWord();
    if (!x || tab !== 'recall' || W.GH_HINT_REWARDS5?.isStaleTrainer?.(trainer)) return null;
    const lesson = !!D.querySelector('.lesson452');
    const step = lesson ? W.ICPT_LESSON452?.completion?.(x.id) : null;
    const rec = lesson ? W.ICPT_LESSON452?.getProgress?.(x.id) : null;
    if (lesson && (!Number.isInteger(step) || step < 1 || step > 5)) return null;
    if (!lesson && !D.getElementById('learnInput')) return null;
    let bag=attempts.get(trainer); if (!bag) {bag=new Map();attempts.set(trainer,bag);}
    const identity=JSON.stringify([trainer.i,x.id,lesson?'lesson-'+step:'text-'+trainer.mode]);
    if (!bag.has(identity)) {
      // Never create a fresh reward attempt from already-submitted feedback.
      if (lesson ? rec?.checked452?.step===step : trainer.revealed) return null;
      const captured=trainer,index=trainer.i,expected=owner();
      const current=()=>trainer===captured&&trainer.i===index&&tab==='recall'&&owner()===expected&&profileCurrent(expected)&&!W.GH_HINT_REWARDS5?.isStaleTrainer?.(trainer);
      const token=W.GH_PRACTICE_REWARDS457?.begin?.('vocabulary',x.id,{source:'actual-vocabulary-review',sourceWordId:x.id,kind:trainer.kind,index,step});
      bag.set(identity,{id:x.id,token,owner:expected,target:captured,index,step,lesson,current,consumed:false,hinted:false,revealed:false});
    }
    return bag.get(identity);
  }
  function currentAudioAssistance(id) {
    if(typeof trainer==='undefined'||!trainer)return {hinted:false,revealed:false};
    const audio=trainer.audioSupportR2, current=W.GH457_AUDIO?.reviewContext?.({id,kind:'vocabulary'});
    if(!audio?.attemptToken||audio.attemptToken!==current?.attemptToken||key(audio.wordId)!==key(id))return {hinted:false,revealed:false};
    return {hinted:audio.hinted===true||audio.independentExcluded===true,revealed:audio.revealed===true};
  }
  async function completeSubmission(a, options = {}) {
    if (!a || !a.current()) return;
    let correct, extraAssistance=false;
    if (a.lesson) {
      const l=W.ICPT_LESSON452?.getProgress?.(a.id),r=l?.checked452;
      if (!r || r.step!==a.step || typeof r.correct!=='boolean') return;
      correct=r.correct;extraAssistance=!!r.assisted||!!l.letterHint452?.used;
    } else {if (!trainer.revealed || typeof trainer.auto!=='boolean') return;correct=trainer.auto;}
    // Answer correctness is established by the actual engine above, never by
    // an audio event. Wrong feedback does not unlock answer-revealing audio.
    // A later correct retry may unlock audio, but it cannot resurrect an XP
    // attempt that was already consumed by the first incorrect submission.
    if(correct?!a.audioCorrectSent:!a.audioWrongSent){
      if(correct)a.audioCorrectSent=true;else a.audioWrongSent=true;
      W.GH457_AUDIO_QUEUE?.onAnswer?.(a.id,{correct,revealed:false,attemptId:a.token,auto:options.audioAuto !== false});
    }
    if(a.consumed)return;
    a.consumed=true;
    const audio=currentAudioAssistance(a.id);
    const result=await W.GH_PRACTICE_REWARDS457?.complete?.(a.token,{correct,assisted:!!(a.hinted||extraAssistance||trainer.pictureHint||audio.hinted),revealed:!!(a.revealed||audio.revealed),isCurrent:a.current});
    if(!a.current())return result;
    const status=D.getElementById('r2PracticeResult');
    if(status)status.textContent=result?.xp>0?'+'+result.xp+' practice XP · no mastery or listening credit':result?.reason||'';
    return result;
  }
  const priorRecall=renderRecall;
  renderRecall=function(...args){
    let html=priorRecall.apply(this,args);const x=activeWord();
    if(!x){
      const s=typeof trainer!=='undefined'?trainer?.selectionR2:null;
      if(s&&trainer.i>=trainer.queue.length&&day()===localDay()){
        html=html.replace(/<button\b[^>]*data-v3="start-due"[^>]*>[\s\S]*?<\/button>/,'');
        html+=`<section class="card r3-selection-continuation">${scopeHTML()}<p>${s.nextOffset<s.allIds?.length?(s.allIds.length-s.nextOffset)+' source entries remain in this same selection.':'This exact selection is complete. No unrelated words were substituted.'}</p>${s.nextOffset<s.allIds?.length?'<button type="button" data-r2-action="next-block">Continue this selection · next '+Math.min(15,s.allIds.length-s.nextOffset)+'</button>':''}</section>`;
      }
      return html;
    }
    const tools=controlsHTML(x.id)+scopeHTML();
    const card=/(<section\b[^>]*class="[^"]*\b(?:lesson452|flash)\b[^"]*"[^>]*>)/;
    return card.test(html)?html.replace(card,'$1'+tools):html+tools;
  };
  if(typeof renderVocab==='function'){
    const previousVocab=renderVocab;
    renderVocab=function(...args){return previousVocab.apply(this,args)+chapterControlsHTML()+bulkKnownHTML();};
  }
  function selectCurrentAudio(attempt) {
    const x=activeWord(),inReview=typeof tab!=='undefined'&&tab==='recall'&&x;
    const token=inReview?JSON.stringify([owner(),trainer.responseOwner5||'',trainer.selectionR2?.source||trainer.kind,trainer.i,x.id,trainer.encounters452?.slots?.[trainer.i]?.step??null]):null;
    const encounter=attempt?.token||token;
    if(token!==audioSelection||inReview&&audioTrainer!==trainer||encounter!==audioEncounter){
      if(!inReview||audioOwner&&audioOwner!==owner())W.GH457_AUDIO_QUEUE?.cancel?.('review exited or profile changed');
      audioSelection=token;
      audioTrainer=inReview?trainer:null;
      audioEncounter=encounter;
      audioOwner=inReview?owner():null;
      if(inReview){
        const introductory=!!D.querySelector('.lesson452')&&W.ICPT_LESSON452?.completion?.(x.id)===0||!D.querySelector('.lesson452')&&trainer.phase==='prompt'&&['learn','new','chapter-new'].includes(trainer.kind);
        const sourceIndex=trainer.selectionR2?.allIds?.indexOf(x.id);
        W.GH457_AUDIO_QUEUE?.select?.(x.id,{index:sourceIndex>=0?sourceIndex:trainer.i,owner:owner(),review:!introductory,stage:introductory?'study':'arabic-only',encounterId:encounter});
      }
    }
  }
  const priorRender=render;
  render=function(...args){const result=priorRender.apply(this,args);lastRenderOwner=owner();const attempt=attemptState();selectCurrentAudio(attempt);return result;};
  if(typeof updateRetrieval==='function'){
    const previousRetrieval=updateRetrieval;
    updateRetrieval=function(x,rating,...args){
      const support=currentAudioAssistance(x?.id);
      if(rating==='good'&&(support.hinted||support.revealed)){
        notify('This response used pre-answer audio support. Saved as Hard for another independent review, with no Good-response XP.');
        rating='hard';
      }
      return previousRetrieval.call(this,x,rating,...args);
    };
  }
  let directReviewStartPendingR4=false;
  async function launchDirectReviewAfterSaveR4(button,readSelection){
    if(directReviewStartPendingR4){notify('Waiting for the current save before starting this review.');return false;}
    const selected=readSelection(),P=W.GH_PROGRESS45;
    if(P?.getStatus?.()?.pending===true){
      if(typeof P.whenSettled!=='function'){notify('A save is still pending. Keep this page open and retry review after it finishes.');return false;}
      const capturedOwner=owner(),capturedTab=tab,capturedTrainer=typeof trainer==='undefined'?null:trainer,capturedDay=day();
      const fingerprint=JSON.stringify(selected),mapping=JSON.stringify(selected.ids.map(id=>[id,key(id)]));
      directReviewStartPendingR4=true;
      try{
        notify('Waiting for the current save before starting this review.');
        await P.whenSettled();
        if(owner()!==capturedOwner||!profileCurrent(capturedOwner)||tab!==capturedTab||(typeof trainer==='undefined'?null:trainer)!==capturedTrainer||day()!==capturedDay||button.disabled||!D.body.contains(button)){notify('This review or hunter changed while saving. Reopen the selection; nothing launched.');return false;}
        const current=readSelection();
        if(JSON.stringify(current)!==fingerprint||JSON.stringify(current.ids.map(id=>[id,key(id)]))!==mapping){notify('The filtered review selection changed while saving. Review the selection again; nothing launched.');return false;}
        if(P.getStatus?.()?.pending===true){notify('A save is still pending. Keep this page open and retry review after it finishes.');return false;}
      }catch(error){notify('The pending save could not be verified. Keep this page open and use Save & recovery before retrying. Nothing launched.');return false;}
      finally{directReviewStartPendingR4=false;}
    }
    return launchExact(selected.ids,selected.meta);
  }
  D.addEventListener('click',async ev=>{
    const selectedAction=ev.target.closest?.('[data-action="study-filter"],[data-action="study-supp"],[data-action="study-one"]');
    if(selectedAction&&!selectedAction.disabled){
      ev.preventDefault();ev.stopImmediatePropagation();
      const action=selectedAction.dataset.action;
      const readSelection=()=>({ids:action==='study-one'?[selectedAction.dataset.id]:action==='study-supp'&&typeof supplementRows==='function'?supplementRows().map(x=>x.id):filteredVocab().map(x=>x.id),meta:{source:action==='study-filter'?'filtered-set':action==='study-supp'?'supplement-filter':'one-word',filterSnapshot:clone(action==='study-filter'?vocabFilter:action==='study-supp'&&typeof supplementFilter==='object'?supplementFilter:null)}});
      await launchDirectReviewAfterSaveR4(selectedAction,readSelection);
      return;
    }
    const independent=ev.target.closest?.('[data-v3="audit-known"]'),word=activeWord();
    if(independent&&!independent.disabled&&word){
      const support=currentAudioAssistance(word.id);
      if(support.hinted||support.revealed){ev.preventDefault();ev.stopImmediatePropagation();notify('Pre-answer audio support was used. Choose Needs learning, or Mark as known as an explicitly self-reported choice with no XP or mastery credit.');return;}
    }
    const b=ev.target.closest?.('[data-r2-action]');
    if(b&&!b.disabled){
      ev.preventDefault();ev.stopImmediatePropagation();const action=b.dataset.r2Action;
      if(action==='export-pending-workflow'){download({schema:1,owner:uncertainWorkflow?.owner,pendingLedger:uncertainWorkflow?.candidateLedger},'Gatehouse_pending_vocabulary_change.json');}
      if(action==='known'){const r=await setKnownAsync(b.dataset.word,!isKnown(b.dataset.word));if(!r.ok)notify(r.reason);}
      if(action==='undo-known'&&undoKnown){const r=await undoKnownChangeAsync();if(!r.ok)notify(r.reason);}
      if(action==='chapter-review'||action==='chapter-new')launchChapter(b.dataset.chapter,action==='chapter-new'?'new':'review');
      if(action==='next-block')continueExact();
      if(action==='report')openReport(b.dataset.word,b.closest('tr[data-r2-word],.lesson452,.flash')||D.getElementById('content'));
      if(action==='close-report')closeDialog();
      if(action==='save-report'&&draftReport){updateReportComment();const captured=draftReport,submitted=JSON.stringify(captured.report);const r=await saveReportAsync(JSON.parse(submitted),captured.owner);if(draftReport===captured&&JSON.stringify(captured.report)===submitted){const resultEl=D.getElementById('r2ReportResult');if(resultEl)resultEl.textContent=r.ok?'Saved on this browser. Nothing was sent automatically.':r.reason;if(r.ok){captured.saved=true;b.disabled=true;}}}
      if(action==='export-report'&&draftReport){updateReportComment();download(draftReport.report,'Gatehouse_word_report_'+draftReport.report.wordId+'_'+draftReport.report.id+'.json');D.getElementById('r2ReportResult').textContent='Report export requested. Check your browser downloads; no automatic delivery occurred.';}
      if(action==='export-reports')download({schema:1,build:build(),reports:reports(),delivery:'manual export only'},'Gatehouse_saved_word_reports_'+new Date().toISOString().slice(0,10)+'.json');
      return;
    }
    const a=attemptState();
    if(a&&ev.target.closest?.('[data-v3="learn-again"]')){a.revealed=true;W.GH457_AUDIO_QUEUE?.onAnswer?.(a.id,{correct:false,revealed:true,attemptId:a.token});}
    if(!a)return;
    const answer=ev.target.closest?.('[data-v3="train-check"],[data-l452="option"],[data-l452="spell"]');
    if(answer&&!answer.disabled){
      // Native capture-listener microtasks can run before the answer engine's
      // bubble listener. Defer completion until after that event dispatch.
      const queue=W.GH457_AUDIO_QUEUE, revision=queue?.cancellationRevision?.();
      setTimeout(()=>completeSubmission(a,{audioAuto:Number.isSafeInteger(revision)&&queue===W.GH457_AUDIO_QUEUE&&queue.cancellationRevision()===revision}),0);
    }
    if(ev.target.closest?.('[data-v4="picture-hint"],[data-l452="next-letter"]'))a.hinted=true;
  },true);
  D.addEventListener('toggle',ev=>{
    if(ev.target.tagName!=='DETAILS'||!ev.target.open||!ev.target.closest?.('.lesson452,.flash')||ev.target.closest?.('.r2-study-scope'))return;
    const a=attemptState();if(a){a.revealed=true;W.GH457_AUDIO_QUEUE?.onAnswer?.(a.id,{correct:false,revealed:true,attemptId:a.token});}
  },true);
  W.addEventListener('gh457:audio-support',ev=>{
    const d=ev.detail,a=attemptState();if(!a||a.consumed||!d||d.phase!=='started'||d.owner&&d.owner!==a.owner||key(d.wordId)!==key(a.id))return;
    if(d.attemptToken&&d.attemptToken!==W.GH457_AUDIO?.reviewContext?.({id:a.id,kind:'vocabulary'})?.attemptToken)return;
    if(d.answerRevealing)a.revealed=true;else if(d.purpose==='pre-answer-hint')a.hinted=true;
  });
  // Dashboard vocabulary navigation is separate from the frozen daily plan.
  // Every learning launch reuses the existing exact-source six-step engine.
  let wordPickerR4=null;
  function currentChapterR4(){const n=Number(W.ICPT_SYSTEM?.chapterCeiling?.());return Number.isInteger(n)&&n>=1&&n<=15?n:null;}
  function backlogRowsR4(){return ITEMS.filter(x=>newEligible(x.id));}
  function pickerScopeR4(p){
    if(p.owner!==owner()||!profileCurrent(p.owner))return {error:'The active hunter changed. Reopen this word selection.',ids:[]};
    if(p.purpose==='required'){
      const m=W.ICPT_STAGE2?.model?.(),r=m?.rows.find(r=>r.key===p.stage);
      if(!m||JSON.stringify(m.snapshot)!==p.assignment)return {error:'The required assignment changed. Reopen Continue required block to choose from its current saved IDs.',ids:[]};
      if(m.snapshot.preview||m.snapshot.unsaved||m.snapshot.unusable)return {error:'The required assignment is not ready or could not be saved. Keep a backup and review the date or assignment settings.',ids:[]};
      return {ids:r?.remaining||[]};
    }
    if(p.scopeIds)return {ids:p.scopeIds.filter(id=>!!byId[id])};
    if(p.purpose==='familiar')return {ids:unique([...dueItems(),...firstQueue(),...checkQueue()].map(x=>x.id))};
    return {ids:ITEMS.map(x=>x.id)};
  }
  // Membership comes from installed source lists, never an inferred exam/chapter mapping.
  let pickerSetCacheR7=null;
function buildPickerMembershipR8(api, sourceMemberships=[]){
  const conflicts=new Set(sourceMemberships.filter(m=>m&&(m.conflict||m.sourceRow?.conflict||m.sourceMembershipConflict)).map(m=>m.id).filter(Boolean));
  const blocked=o=>!!(o?.conflict||o?.sourceRow?.conflict||o?.sourceMembershipConflict||conflicts.has(o?.membershipId||o?.sourceMembershipId));
  const sets=[], byId=new Map();
  const add=(map,id,m)=>{if(!id)return;if(!map.has(id))map.set(id,[]);const a=map.get(id);if(!a.some(x=>x.source===m.source&&x.label===m.label))a.push(m);};
  for(const exam of ['sources','101','102','201','202','301','302'])for(const raw of api?.sets?.(exam)||[]){
    const source=exam==='sources'?(/^memrise/i.test(raw.name)?'memrise':/^quizlet/i.test(raw.name)?'quizlet':null):null;
    const match=String(raw.id).match(/^memrise-ch(\d+)$/)||String(raw.id).match(/^memrise-p2-U\d+C(\d+)$/);
    const chapter=match?Number(match[1]):null;
    const unit=String(raw.id).match(/^memrise-p2-U(\d+)C\d+$/);
    const semester=chapter?(chapter<=25?1:2):/SEM III/i.test(raw.name)?3:null;
    const category=exam!=='sources'?'Exam focus · ICPT '+exam:source==='quizlet'?'Quizlet · original source lists':chapter?'Memrise · chapter lists':/SEM III/i.test(raw.name)?'Memrise · Semester III book / lesson lists':/all \d+ original source rows/i.test(raw.name)?'Memrise · complete original list':'Memrise · topics and miscellaneous lists';
    const item={value:exam+':'+raw.id,label:raw.name,category,chapter,unit:unit?Number(unit[1]):chapter?Math.ceil(chapter/5):null,exam,source,semester,ids:new Set(),members:new Map()};
    for(const row of api.eligible(raw.rows)){
      if(blocked(row))continue;
      const occurrences=(row.supplementaryOccurrences?.length?row.supplementaryOccurrences:[{id:row.id,viewSource:raw.name,sourceMembershipId:row.sourceMembershipId}]).filter(o=>!blocked(o));
      if(!occurrences.length)continue;
      for(const o of occurrences){
        const family=source||(/^Memrise/i.test(o.viewSource||'')?'memrise':/^Quizlet/i.test(o.viewSource||'')?'quizlet':raw.id==='memrise'?'memrise':raw.id==='quizlet125'?'quizlet':null);
        const m={source:family,label:raw.name,chapter:family==='quizlet'?null:chapter,semester:family==='quizlet'?null:semester,exam:exam==='sources'?null:exam};
        item.ids.add(o.id);add(item.members,o.id,m);
        // Global provenance uses original source lists, not recommended unions.
        if(exam==='sources')add(byId,o.id,m);
      }
      item.ids.add(row.id);for(const o of occurrences){const ms=item.members.get(o.id)||[];for(const m of ms)add(item.members,row.id,m);}
    }
    sets.push(item);
  }
  const categories=['Memrise · complete original list','Memrise · chapter lists','Memrise · Semester III book / lesson lists','Memrise · topics and miscellaneous lists','Quizlet · original source lists'];
  sets.sort((a,b)=>{const ai=a.exam==='sources'?categories.indexOf(a.category):100+Number(a.exam),bi=b.exam==='sources'?categories.indexOf(b.category):100+Number(b.exam);return ai-bi||(a.chapter||0)-(b.chapter||0)||a.label.localeCompare(b.label,undefined,{numeric:true});});
  // Include Quizlet exam-only memberships, without assigning them a chapter.
  for(const set of sets)if(set.exam!=='sources'&&set.label==='Quizlet')for(const [id,ms] of set.members)for(const m of ms)add(byId,id,m);
  return {sets,byId};
}

  let pickerMembershipR8=null;
  function pickerSetsR7(){if(!pickerSetCacheR7){pickerMembershipR8=buildPickerMembershipR8(W.GH_SUPPLEMENTARY_VOCAB,[...(W.GH_PRIORITY2?.members||[]),...(W.GH_QUIZLET_SUPPLEMENT?.members||[])]);pickerSetCacheR7=pickerMembershipR8.sets;}return pickerSetCacheR7;}
  function pickerMembershipsR8(x,p){pickerSetsR7();const selected=p.suppSet&&p.suppSet!=='all'?pickerSetCacheR7.find(s=>s.value===p.suppSet):null;return p.suppSet&&p.suppSet!=='all'?(selected?.members.get(x.id)||[]):(pickerMembershipR8.byId.get(x.id)||[]);}
  function pickerSourceR8(x,p,source=p.source){if(source==='all')return true;const ms=pickerMembershipsR8(x,p);if(p.suppSet&&p.suppSet!=='all')return ms.some(m=>m.source===source);return source==='core'?x.bank==='core':ms.some(m=>m.source===source)||x.bank===source;}
  function pickerChapterR8(x,p,ch){
    const ms=pickerMembershipsR8(x,p).filter(m=>p.source==='all'||m.source===p.source);
    if(ms.some(m=>m.chapter===Number(ch)))return true;
    // Exam-only Quizlet lists never acquire the chapter of a reused target.
    if(p.source==='quizlet'||p.suppSet&&p.suppSet!=='all')return false;
    return (p.source==='all'||p.source==='core')&&x.bank==='core'&&matchesSourceScopeR2(x,String(ch));
  }
  function pickerSemesterR8(x,p){if(!p.semester||p.semester==='all')return true;const ms=pickerMembershipsR8(x,p).filter(m=>p.source==='all'||m.source===p.source);if(ms.some(m=>String(m.semester)===p.semester))return true;if(p.suppSet&&p.suppSet!=='all'||p.source==='quizlet'||p.source==='memrise')return false;return x.bank==='core'&&String(x._semester3Mastery?3:(x.semester||(Number(x.chapter)>0?(Number(x.chapter)<=25?1:2):0)))===p.semester;}
  const pickerBridgeScopesR8=new Map();
  let pickerBridgeCounterR8=0;
  function bridgeMembersR8(row){
    const concrete=x=>!!(x?.sourceMembershipConflict||x?.conflict||x?.sourceRow?.conflict);
    const registry=new Map([...(W.GH_PRIORITY2?.members||[]),...(W.GH_QUIZLET_SUPPLEMENT?.members||[])].map(m=>[String(m.id),m]));
    if(concrete(row))return [];
    const occurrences=row.supplementaryOccurrences?.length?row.supplementaryOccurrences:[row];
    return occurrences.filter(o=>!concrete(o)&&!concrete(registry.get(String(o.membershipId||o.sourceMembershipId||'')))).map(o=>({target:String(o.id||row.id),membership:String(o.membershipId||o.sourceMembershipId||o.id||row.id)}));
  }
  function registerBridgeScopeR8(rows,ids){
    const allowed=new Map();for(const row of rows||[]){if(!ids.includes(String(row.id)))continue;const entries=bridgeMembersR8(row);if(entries.length){if(!allowed.has(String(row.id)))allowed.set(String(row.id),[]);allowed.get(String(row.id)).push(...entries);}}
    if(ids.some(id=>!allowed.has(String(id))))return null;
    const token='picker-membership-r8:'+String(++pickerBridgeCounterR8)+':'+Date.now();
    pickerBridgeScopesR8.set(token,{owner:owner(),allowed});
    return token;
  }
  function bridgeScopeAllowedR8(token,ids){
    if(!token||!String(token).startsWith('picker-membership-r8:'))return true;
    const scope=pickerBridgeScopesR8.get(token);if(!scope||scope.owner!==owner())return false;
    const api=W.GH_SUPPLEMENTARY_VOCAB;if(!api?.sets||!api?.eligible)return false;
    const current=new Set();
    try{for(const exam of ['sources','101','102','201','202','301','302'])for(const set of api.sets(exam)||[])for(const row of api.eligible(set.rows))for(const m of bridgeMembersR8(row))current.add(m.target+'\u0000'+m.membership);}catch(_){return false;}
    return ids.every(id=>(scope.allowed.get(String(id))||[]).some(m=>current.has(m.target+'\u0000'+m.membership)));
  }

  function pickerContinuationAllowedR8(s){
    if(!bridgeScopeAllowedR8(s?.selectionToken,s.allIds.slice(s.nextOffset)))return false;
    const f=s?.filterSnapshot;if(!f||!Object.prototype.hasOwnProperty.call(f,'supplementList'))return true;
    const remaining=s.allIds.slice(s.nextOffset);if(!remaining.length)return true;
    pickerSetCacheR7=null;pickerMembershipR8=null;
    const p={owner:s.owner,purpose:'filtered',scopeIds:remaining,mode:'chapter-review',source:f.scope||'all',suppSet:f.supplementList||'all',chapter:f.chapter||'all',chapters:f.chapters||[],semester:f.semester||'all',search:f.search||''};
    try{const permitted=new Set(pickerRowsR4(p).map(x=>x.id));return remaining.every(id=>permitted.has(id));}catch(_){return false;}
  }
  function pickerSetOptionsR8(p){const groups=new Map();for(const s of pickerSetsR7()){if(!groups.has(s.category))groups.set(s.category,[]);groups.get(s.category).push(s);}return [...groups].map(([label,sets])=>`<optgroup label="${esc(label)}">${sets.map(s=>`<option value="${esc(s.value)}" ${p.suppSet===s.value?'selected':''}>${esc(s.label)}</option>`).join('')}</optgroup>`).join('');}
  function pickerProvenanceR8(x,p){const ms=pickerMembershipsR8(x,p);const labels=[...new Set(ms.filter(m=>p.source==='all'||m.source===p.source).map(m=>m.label))];if(labels.length)return labels.join(' · ');return x.bank==='quizlet'?'Quizlet · exam source; no assigned chapter':x.bank==='core'?'Primary DLI · '+(x.chapter?chLabel(x.chapter):x._semester3Mastery?'Semester III · Lesson '+x.lesson:'Source lesson not assigned'):'Memrise · source chapter not assigned';}
  function pickerRowsR4(p=wordPickerR4){
    if(!p)return [];
    const scope=pickerScopeR4(p);if(scope.error)return [];
    let rows=scope.ids.map(id=>byId[id]).filter(Boolean);
    if(p.mode==='new')rows=rows.filter(x=>newEligible(x.id));
    rows=rows.filter(x=>pickerSourceR8(x,p));
    rows=rows.filter(x=>pickerSemesterR8(x,p));
    if(p.suppSet&&p.suppSet!=='all'){const set=pickerSetsR7().find(s=>s.value===p.suppSet);rows=rows.filter(x=>set?.ids.has(x.id));}
    if(p.chapter==='supplements')rows=rows.filter(x=>pickerSourceR8(x,p,'memrise')||pickerSourceR8(x,p,'quizlet'));
    else if(String(p.chapter).startsWith('sem3:'))rows=rows.filter(x=>(!p.suppSet||p.suppSet==='all')&&(p.source==='all'||p.source==='core')&&x.bank==='core'&&x._semester3Mastery&&Number(x.lesson)===Number(p.chapter.slice(5)));
    else if(p.chapter==='current-plus'){const ch=currentChapterR4();rows=rows.filter(x=>pickerSourceR8(x,p,'memrise')||pickerSourceR8(x,p,'quizlet')||!ch||pickerChapterR8(x,p,ch));}
    else if(p.chapter==='selected-chapters')rows=rows.filter(x=>(p.chapters||[]).some(c=>pickerChapterR8(x,p,String(c))));
    else if(p.chapter!=='all')rows=rows.filter(x=>pickerChapterR8(x,p,p.chapter));
    const q=normalize(p.search||'');if(q)rows=rows.filter(x=>(W.GH_AVAILABLE_DEFINITIONS?W.GH_AVAILABLE_DEFINITIONS.matches(x,q):normalize([x.ar,x.en,x.studyMeaning,x.meaningDisplay,x.id,x.ling?.root,x.originalAr,x.originalEn,x.sourceRow?.arabic,x.sourceRow?.english].join(' ')).includes(q)));
    // Do not canonicalize explicit source rows. Shared progress is still read
    // through newEligible; distinct source forms and their recordings survive.
    return rows;
  }
  function openPickerR4(options={}){
    if(options.scopeRowsR8){const token=registerBridgeScopeR8(options.scopeRowsR8,(options.scopeIds||[]).map(String));if(!token){notify('The source membership could not be checked. Reopen the supplemental list. Nothing launched.');return false;}options={...options,bridgeTokenR8:token};delete options.scopeRowsR8;}
    stopSpeech();session=null;trainer=null;pickerSetCacheR7=null;
    const mode=options.mode||'new',purpose=options.purpose||'new';
    wordPickerR4={owner:owner(),mode,purpose,chapter:purpose==='new'?'selected-chapters':'all',chapters:currentChapterR4()?[currentChapterR4()]:[],source:'all',semester:'all',suppSet:'all',search:'',page:0,selected:[],...options};
    tab='recall';render();D.getElementById('wordPickerR4')?.focus();return true;
  }
  function openRequiredR4(stage){
    const m=W.ICPT_STAGE2?.model?.();if(!m)return false;
    return openPickerR4({purpose:'required',stage,mode:stage==='learn'?'new':'scheduled-review',assignment:JSON.stringify(m.snapshot)});
  }
  function recoveryPickerR4(from){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(from)||from>=localDay()){notify('Choose a missed day before today.');return false;}
    const prior=state.v4?.stage2?.days?.[from];let ids;
    if(prior!==undefined){
      if(![1,2].includes(prior?.schema)||prior.date!==from||!['checks','learn','first','due'].every(k=>Array.isArray(prior[k])&&prior[k].every(id=>typeof id==='string'&&byId[id]))){notify('This historical saved assignment is unfamiliar and was preserved. Export a recovery backup before changing it.');return false;}
      ids=unique(['checks','learn','first','due'].flatMap(k=>prior[k]));
    }else{const map=planMap();ids=ITEMS.filter(x=>map[x.id]===from).map(x=>x.id);}
    return openPickerR4({purpose:'recovery',mode:'new',chapter:'all',scopeIds:ids,from,historicalSource:prior?'saved daily assignment':'legacy calendar allocation'});
  }
  function pickerTitleR4(p){return p.purpose==='required'?'Choose required '+({checks:'familiarity checks',learn:'new learning',first:'first retrieval',due:'spaced review'}[p.stage]||'words'):p.purpose==='familiar'?'Check familiar words':p.purpose==='recovery'?'Learn missed-day words':p.purpose==='filtered'?'Learn the filtered new words':p.purpose==='backlog'?'Unlearned vocabulary backlog':'Learn new words';}
  function renderPickerR4(){
    const p=wordPickerR4,scope=pickerScopeR4(p),rows=pickerRowsR4(p),ch=currentChapterR4(),size=30,pages=Math.max(1,Math.ceil(rows.length/size));p.page=Math.min(p.page,pages-1);
    const visibleIdsR7=new Set(rows.map(x=>x.id));p.selected=p.selected.filter(id=>visibleIdsR7.has(id));
    const grouped=new Set(rows.map(x=>key(x.id))).size,showMeaning=p.mode==='new',preview=day()!==localDay();
    const chapterOptions=[...(p.purpose==='new'?[['current-plus',ch?'Schedule shortcut: chapter '+ch+' + all supplements':'Current chapter unavailable · all chapters']]:[]),['all','All chapters and supplements'],['supplements','All supplements (no chapter restriction)'],...DATA.chapters.map(c=>[String(c.chapter),chLabel(c.chapter)+' · '+c.title]),...(W.GH_CH16_25?.ready?[...new Set(W.GH_CH16_25.rows.map(r=>r.chapter))].map(c=>[String(c),chLabel(c)+' · '+chTitle(c)]):[]),...(W.GH_SEM2_INTEGRATION?.ready?[...new Set(W.GH_SEM2_INTEGRATION.rows.map(r=>r.chapter))].map(c=>[String(c),chLabel(c)+' · '+chTitle(c)]):[])];
    const chapterChoices=[...new Map(chapterOptions.filter(([v])=>/^\d+$/.test(v)).map(([v,t])=>[Number(v),[v,t]])).values()].sort((a,b)=>Number(a[0])-Number(b[0]));
    chapterOptions.push(...[...new Set(ITEMS.filter(x=>x._semester3Mastery).map(x=>x.lesson))].sort((a,b)=>a-b).map(n=>['sem3:'+n,'Semester III · Lesson '+n]));
    chapterOptions.unshift(['selected-chapters','Choose several chapters…']);
    const sourceOptions=[['all','All sources'],['core','Primary DLI'],['memrise','Memrise supplement'],['quizlet','Quizlet']];
    const counts=Object.fromEntries(sourceOptions.slice(1).map(([bank])=>[bank,rows.filter(x=>pickerSourceR8(x,p,bank)).length]));
    const note=p.purpose==='required'?'Filters select only from this stage’s remaining saved required IDs. Unselected required words stay outstanding.':p.purpose==='recovery'?'These words come from the '+p.historicalSource+' for '+p.from+'. Work is recorded today; the missed day is not marked completed retroactively.':p.purpose==='familiar'?'This list contains actual due spaced reviews, due first retrievals, and eligible familiarity checks. No future review is made due.':'Learned/retrieved and self-reported known words are excluded. Introduced but unfinished words remain. Each selected shared group uses the normal six steps through one chosen source form; this does not independently verify every alternate form.';
    return heading(pickerTitleR4(p),note)+`<section class="card" id="wordPickerR4" tabindex="-1" aria-label="Vocabulary selection">
    ${preview?'<p class="banner" role="status">This is a date preview. Return the Study date control to today before starting. No learning will be backdated.</p>':''}
    ${reviewOnly()&&showMeaning?'<p class="banner"><b>The mandatory schedule is review-only.</b> You may explicitly choose optional learning from this backlog. That does not add it to the required assignment, erase due reviews, or change the exam date.</p>':''}
    ${scope.error?`<p class="banner" role="status">${esc(scope.error)}</p>`:''}
    <div class="toolbar"><label>Semester<select id="wordPickerSemesterR7">${[['all','All semesters'],['1','Semester I'],['2','Semester II'],['3','Semester III']].map(([v,t])=>`<option value="${v}" ${p.semester===v?'selected':''}>${t}</option>`).join('')}</select></label><label>Chapter / lesson<select id="wordPickerChapterR4">${chapterOptions.map(([v,t])=>`<option value="${v}" ${p.chapter===v?'selected':''}>${esc(t)}</option>`).join('')}</select></label><label>Source<select id="wordPickerSourceR4">${sourceOptions.map(([v,t])=>`<option value="${v}" ${p.source===v?'selected':''}>${t}</option>`).join('')}</select></label><label>Supplement source list or exam focus<select id="wordPickerSetR7"><option value="all">All installed lists (no list restriction)</option>${pickerSetOptionsR8(p)}</select></label><label>Search<input id="wordPickerSearchR4" type="search" value="${esc(p.search)}" placeholder="Arabic, meaning or source ID"></label></div>
    ${p.chapter==='selected-chapters'?`<fieldset aria-describedby="chapterHelpR5" style="min-width:0;margin:12px 0"><legend>Choose chapters to learn from</legend><p id="chapterHelpR5">Select one or several chapters across units. Only these chapters are included. Future chapters and unassigned supplements are excluded unless you explicitly choose another scope.</p><div class="actions"><button type="button" data-r4-learning="clear-chapters">Clear chapter choices</button></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr));gap:8px;max-height:320px;overflow:auto;padding:4px">${chapterChoices.map(([v,t])=>`<label style="display:flex;align-items:center;gap:8px;min-height:44px"><input type="checkbox" id="wordChapterR5-${v}" data-r5-chapter="${v}" ${(p.chapters||[]).includes(Number(v))?'checked':''}><span>Semester ${Number(v)<=25?'I':'II'} · Unit ${Math.ceil(Number(v)/5)} · ${esc(typeof chTitle==='function'?chLabel(Number(v))+' · '+chTitle(Number(v)):t)}</span></label>`).join('')}</div><p role="status">${(p.chapters||[]).length} chapters selected${(p.chapters||[]).length?': '+(p.chapters||[]).join(', '):'. Choose at least one chapter to start.'}</p></fieldset>`:''}
    <p class="mini">Semester, chapter/lesson, source and supplement-list filters apply together. Choose a specific ICPT list to avoid mixing exam levels. Changing a filter clears the selection. To browse every Memrise or Quizlet supplement, choose All supplements and then its source. The schedule shortcut uses your saved schedule; it does not limit the other choices.</p>
    <p role="status">${rows.length} source entries · ${grouped} shared progress groups. Source memberships: Primary DLI ${counts.core}; Memrise ${counts.memrise}; Quizlet ${counts.quizlet}. Membership counts may overlap; words and saved progress are not duplicated.</p>
    <div class="actions"><button type="button" class="primary" data-r4-learning="start" ${!rows.length||preview||scope.error?'disabled':''}>${showMeaning&&reviewOnly()?'Start optional learning':showMeaning?'Start six-step learning':'Start review/check block'} · ${p.selected.length?Math.min(15,p.selected.length)+' selected':Math.min(15,showMeaning?grouped:rows.length)+' from this filter'}</button><button type="button" data-r4-learning="select-page" ${rows.length?'':'disabled'}>Select this page</button><button type="button" data-r4-learning="select-filtered" ${rows.length?'':'disabled'}>Select all filtered</button><button type="button" data-r4-learning="clear-selection" ${p.selected.length?'':'disabled'}>Clear selected words (${p.selected.length})</button></div>
    <p class="mini">Choose individual words below, or start the next block from the current filter. ${showMeaning?'Up to 15 shared groups are selected per block, using one exact source form for each group. Selecting another form in the same group replaces your prior form choice. Shared completion is not proof every alternate form was practiced independently.':'Up to 15 source entries are selected per block. Definitions are hidden here so this list does not reveal your next retrieval answers.'} No outside source form is substituted.</p>
    ${rows.length?`<div class="scroller">${rows.slice(p.page*size,(p.page+1)*size).map(x=>`<div class="dailyWord"><label><input type="checkbox" data-r4-word="${esc(x.id)}" ${p.selected.includes(x.id)?'checked':''}> <span class="ar inline" lang="ar">${esc(x.ling?.head||x.ar)}</span></label><span>${showMeaning?esc(x.meaningDisplay)+'<br>':''}<small>${esc(x.id)} · ${esc(pickerProvenanceR8(x,p))}</small>${showMeaning&&members(x.id).length>1?`<br><small>Shares saved learning with ${esc(members(x.id).filter(y=>y.id!==x.id).map(y=>y.id).join(', '))}. Choose one form per group.</small>`:''}</span></div>`).join('')}</div>`:'<p class="empty">No eligible words match this selection. Choose another chapter/source or open the full backlog. Nothing has been marked learned or added to your due queue.</p>'}
    <div class="actions"><button type="button" data-r4-learning="prev" ${p.page?'':'disabled'}>Previous</button><span>Page ${p.page+1}/${pages}</span><button type="button" data-r4-learning="next" ${p.page+1<pages?'':'disabled'}>Next</button></div>
    <div class="actions spacer"><button type="button" data-r4-learning="backlog">Browse all unlearned backlog</button><button type="button" data-r4-learning="familiar">Review/check due and familiar words</button><button type="button" data-action="tab" data-tab="today">Return to dashboard</button></div></section>`;
  }
  // The picker uses the recall engine, but has its own navigation identity.
  // Keep routing/save formats unchanged and distinguish optional learning from due recall.
  const pickerNavR6=nav;
  nav=function(...args){
    const result=pickerNavR6.apply(this,args), host=D.getElementById('nav');
    if(!host)return result;
    const learning=tab==='recall'&&((wordPickerR4&&wordPickerR4.mode==='new')||trainer?.kind==='learn');
    const recall=host.querySelector('[data-tab="recall"]');
    if(learning&&recall){recall.classList.remove('active');recall.removeAttribute('aria-current');}
    const button=D.createElement('button');button.type='button';button.dataset.r4Learning='new';button.innerHTML='<svg class="icon43" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v16M3 4h4q5 0 5 3 0-3 5-3h4v15h-4q-5 0-5 2 0-2-5-2H3Z"/></svg><span>Learn New Words</span>';
    if(learning){button.classList.add('active');button.setAttribute('aria-current','page');}
    if(recall)recall.insertAdjacentElement('beforebegin',button);else host.appendChild(button);
    return result;
  };
  // Clicking Spaced Recall explicitly leaves the optional word-picker screen.
  D.addEventListener('click',async ev=>{if(ev.target.closest?.('[data-action="tab"][data-tab="recall"]'))wordPickerR4=null;},true);
  const previousPickerRecallR4=renderRecall;
  renderRecall=function(...args){
    if(wordPickerR4&&!trainer){if(wordPickerR4.owner!==owner()){wordPickerR4=null;}else return renderPickerR4();}
    return previousPickerRecallR4.apply(this,args);
  };
  const pickerRenderR4=render;
  render=function(...args){if(tab!=='recall'||trainer)wordPickerR4=null;return pickerRenderR4.apply(this,args);};
  let pickerStartPendingR4=false;
  async function startPickerR4(){
    if(pickerStartPendingR4){notify('Waiting for the current save before starting this selection.');return false;}
    const p=wordPickerR4;if(!p||day()!==localDay()||pickerScopeR4(p).error){notify('Reopen this selection for the active hunter and today’s date.');return false;}
    const P=W.GH_PROGRESS45;
    if(P?.getStatus?.()?.pending===true){
      if(typeof P.whenSettled!=='function'){notify('A save is still pending. Keep this page open and retry this selection after it finishes.');return false;}
      const capturedOwner=owner(),capturedTab=tab,capturedTrainer=typeof trainer==='undefined'?null:trainer,capturedDay=day(),pickerFingerprint=JSON.stringify(p);
      pickerSetCacheR7=null;pickerMembershipR8=null;
      const rowFingerprint=JSON.stringify(pickerRowsR4(p).map(x=>[x.id,key(x.id)]));
      pickerStartPendingR4=true;
      try{
        notify('Waiting for the current save before starting this selection.');
        await P.whenSettled();
        if(wordPickerR4!==p||JSON.stringify(p)!==pickerFingerprint||owner()!==capturedOwner||tab!==capturedTab||(typeof trainer==='undefined'?null:trainer)!==capturedTrainer||day()!==capturedDay||day()!==localDay()||!profileCurrent(capturedOwner)||pickerScopeR4(p).error){notify('This selection or hunter changed while saving. Reopen the selection; nothing launched.');return false;}
        pickerSetCacheR7=null;pickerMembershipR8=null;
        if(JSON.stringify(pickerRowsR4(p).map(x=>[x.id,key(x.id)]))!==rowFingerprint){notify('The eligible source membership changed while saving. Review this selection again; nothing launched.');return false;}
        if(P.getStatus?.()?.pending===true){notify('A save is still pending. Keep this page open and retry this selection after it finishes.');return false;}
      }catch(error){notify('The pending save could not be verified. Keep this page open and use Save & recovery before retrying. Nothing launched.');return false;}
      finally{pickerStartPendingR4=false;}
    }
    // Re-read installed source membership at launch, not the cached dropdown view.
    // This is transient UI state only; no profile/schema or source identity changes.
    pickerSetCacheR7=null;pickerMembershipR8=null;
    const rows=pickerRowsR4(p),ids=rows.map(x=>x.id);
    if(p.selected.some(id=>!ids.includes(id))){notify('The selected source list changed or a selected membership is now conflicted. Review the selection again. Nothing launched.');render();return false;}
    const chosen=p.selected.length?[...p.selected]:ids;
    if(!chosen.length){notify('No eligible words remain in this exact filter. Nothing else was added.');render();return false;}
    if(!bridgeScopeAllowedR8(p.bridgeTokenR8,chosen)){notify('The original supplemental membership changed or is unavailable. Reopen that source list. Nothing launched.');return false;}
    wordPickerR4=null;
    const result=launchExact(chosen,{source:p.purpose==='required'?'required-stage-filter':p.purpose==='recovery'?'missed-day-learning':'dashboard-'+p.purpose,mode:p.mode,...(p.bridgeTokenR8?{selectionToken:p.bridgeTokenR8}:{}),filterSnapshot:{chapter:p.chapter,chapters:p.chapter==='selected-chapters'?[...(p.chapters||[])]:null,scope:p.source,semester:p.semester,supplementList:p.suppSet,status:p.mode==='new'?'unlearned':'eligible-review',search:p.search},date:p.from||null,scheduledAssignment:p.purpose==='required'?{stage:p.stage,assignment:p.assignment}:null});
    if(!result){wordPickerR4=p;render();}return result;
  }
  const pickerTodayR4=renderToday;
  renderToday=function(...args){
    const rows=backlogRowsR4(),groups=new Set(rows.map(x=>key(x.id))).size;
    let html=pickerTodayR4.apply(this,args);
    html=html.replace('These stage buttons open today’s saved finite assignment. Eligible carry-over and legacy calendar allocations remain visible below; they are not all required today.','Check familiar words opens due and eligible checks. Learn new words opens a filterable unlearned selection. Use Continue required block below to choose within today’s saved finite assignment.').replace('A check is a familiarity audit, two same-day rehearsals are learning, and next-day retrieval is a separate event.','A check is a familiarity audit; six guided steps are learning; next-day retrieval is separate.');
    html=html.replace(/<div class="banner"><b>Review-only period\.<\/b>[\s\S]*?<\/div>/,`<div class="banner"><b>Mandatory route: review-only.</b> No new words are added to the required daily assignment. ${groups} unlearned groups remain available for explicit optional learning. Due first and spaced retrievals remain required. <button type="button" data-r4-learning="backlog">Browse and learn this backlog</button></div>`);
    return `<section class="card" aria-label="Vocabulary access"><div class="actions"><button type="button" data-r4-learning="new">Learn new words · choose chapter/source</button><button type="button" data-r4-learning="backlog">Browse all unlearned backlog (${groups} groups)</button><button type="button" data-r4-learning="familiar">Check familiar and due words</button></div><p class="mini">Choose one or several chapters for optional learning. Other chapter/source scopes remain available explicitly. Required daily assignments remain separately tracked below.</p></section>`+html;
  };
  const pickerVocabR4=renderVocab;
  renderVocab=function(...args){return pickerVocabR4.apply(this,args).replace('<button data-action="study-filter">Study filtered set</button>','<button data-action="study-filter">Review filtered set</button><button type="button" class="primary" data-r4-learning="filtered-new">Learn unlearned words in this filtered set</button>');};
  D.addEventListener('click',async ev=>{
    const legacy=ev.target.closest?.('[data-v3="start-learn"],[data-v3="start-check"],[data-v3="study"],[data-stage2="stage"],[data-system="catchup"]'),b=ev.target.closest?.('[data-r4-learning]');
    if(!legacy&&!b||legacy?.disabled||b?.disabled)return;
    ev.preventDefault();ev.stopImmediatePropagation();
    if(legacy){if(legacy.dataset.v3==='study'){const id=legacy.dataset.id;if(newEligible(id))openPickerR4({purpose:'filtered',chapter:'all',scopeIds:[id]});else launchExact([id],{source:'individual-review',mode:'chapter-review'});}else if(legacy.dataset.v3==='start-learn')openPickerR4();else if(legacy.dataset.v3==='start-check')openPickerR4({purpose:'familiar',mode:'scheduled-review'});else if(legacy.dataset.stage2==='stage')openRequiredR4(legacy.dataset.kind);else recoveryPickerR4(legacy.dataset.date);return;}
    const action=b.dataset.r4Learning;
    if(action==='new')openPickerR4();
    if(action==='backlog')openPickerR4({purpose:'backlog',chapter:'all'});
    if(action==='familiar')openPickerR4({purpose:'familiar',mode:'scheduled-review'});
    if(action==='filtered-new')openPickerR4({purpose:'filtered',chapter:'all',scopeIds:filteredVocab().map(x=>x.id)});
    if(action==='start')await startPickerR4();
    if(wordPickerR4&&['select-page','select-filtered'].includes(action)){const p=wordPickerR4,rows=pickerRowsR4(p),xs=action==='select-page'?rows.slice(p.page*30,(p.page+1)*30):rows;const ids=unique([...p.selected,...xs.map(x=>x.id)]),seen=new Set();p.selected=p.mode==='new'?ids.filter(id=>{const k=key(id);if(seen.has(k))return false;seen.add(k);return true;}):ids;render();D.getElementById('wordPickerR4')?.focus();}
    if(wordPickerR4&&action==='clear-chapters'){wordPickerR4.chapters=[];wordPickerR4.selected=[];wordPickerR4.page=0;render();D.getElementById('wordPickerR4')?.focus();}
    if(wordPickerR4&&['prev','next','clear-selection'].includes(action)){if(action==='clear-selection')wordPickerR4.selected=[];else wordPickerR4.page=Math.max(0,wordPickerR4.page+(action==='next'?1:-1));render();D.getElementById('wordPickerR4')?.focus();}
  },true);
  D.addEventListener('change',ev=>{
    const p=wordPickerR4;if(!p||p.owner!==owner()||tab!=='recall'||trainer)return;
    const chapter=Number(ev.target.dataset?.r5Chapter);
    if(p.chapter==='selected-chapters'&&Number.isInteger(chapter)&&chapter>=1&&chapter<=50){p.chapters=ev.target.checked?[...new Set([...(p.chapters||[]),chapter])].sort((a,b)=>a-b):(p.chapters||[]).filter(c=>c!==chapter);p.selected=[];p.page=0;render();D.getElementById('wordChapterR5-'+chapter)?.focus();return;}
    const field={wordPickerSemesterR7:'semester',wordPickerSetR7:'suppSet',wordPickerChapterR4:'chapter',wordPickerSourceR4:'source',wordPickerSearchR4:'search'}[ev.target.id];
    if(field){if(p[field]===ev.target.value)return;const id=ev.target.id;p[field]=ev.target.value;if(field==='semester'){p.chapter='all';p.chapters=[];}p.page=0;p.selected=[];render();D.getElementById(id)?.focus();return;}
    const id=ev.target.dataset?.r4Word;if(id&&pickerRowsR4(p).some(x=>x.id===id)){p.selected=ev.target.checked?unique([...(p.mode==='new'?p.selected.filter(other=>key(other)!==key(id)):p.selected),id]):p.selected.filter(x=>x!==id);render();[...D.querySelectorAll('[data-r4-word]')].find(x=>x.dataset.r4Word===id)?.focus();}
  });
  D.addEventListener('input',ev=>{
    if(ev.target.id==='r2WordComment'&&draftReport&&dialog?.contains(ev.target)){
      draftReport.saved=false;const button=dialog.querySelector('[data-r2-action="save-report"]');if(button)button.disabled=false;
      const status=D.getElementById('r2ReportResult');if(status)status.textContent='Unsaved changes. Save or export this report before closing.';
      return;
    }
    const p=wordPickerR4;if(ev.target.id!=='wordPickerSearchR4'||!p||p.owner!==owner()||tab!=='recall'||trainer)return;
    const start=ev.target.selectionStart,end=ev.target.selectionEnd;p.search=ev.target.value;p.page=0;p.selected=[];render();
    const input=D.getElementById('wordPickerSearchR4');input?.focus();if(Number.isInteger(start)&&Number.isInteger(end))input?.setSelectionRange?.(start,end);
  });
  W.GH_DASHBOARD_WORDS_R4=Object.freeze({open:openPickerR4,openRequired:openRequiredR4,openRecovery:recoveryPickerR4,rows:()=>pickerRowsR4(),backlog:backlogRowsR4,currentChapter:currentChapterR4,view:()=>wordPickerR4?clone(wordPickerR4):null});

  W.GH_REVIEW_WORKFLOW_R2=Object.freeze({core:Core,isKnown,setKnown,applyKnownChanges,undoKnownChange,setKnownAsync,applyKnownChangesAsync,undoKnownChangeAsync,saveReportAsync,exportPendingWorkflow:()=>download({schema:1,owner:uncertainWorkflow?.owner,pendingLedger:uncertainWorkflow?.candidateLedger},'Gatehouse_pending_vocabulary_change.json'),recoverKnownUndo,workflowBlocked,selectionPermit,pendingScope,launchExact,continueExact,newEligible,chapterIds,launchChapter,chapterControlsHTML,controlsHTML,visibleText,visibleSnapshot,
    reportSnapshot,openReport,saveReport,reports,exportReports:()=>download({schema:1,build:build(),reports:reports()},'Gatehouse_saved_word_reports.json'),
    scope:()=>lastScope?clone(lastScope):null,owner,profileCurrent,attemptState,completeSubmission,currentAudioAssistance});
})(typeof window==='undefined'?null:window);
