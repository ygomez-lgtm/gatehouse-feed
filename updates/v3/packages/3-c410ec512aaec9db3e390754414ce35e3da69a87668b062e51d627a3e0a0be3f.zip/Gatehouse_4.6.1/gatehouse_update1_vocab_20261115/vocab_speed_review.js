/* Gatehouse Vocabulary Speed Review — separate modest practice rewards in R2.
 * New runtime module. Imported by a guarded loader in dictionary_locator453.js.
 * Shared correct-target audio; practice XP never changes grades, typing,
 * mastery or verified listening evidence. Definition timing remains unchanged.
 */
(()=>{'use strict';
 const ROUTE='vocab-speed-review',S=window.ICPT_SYSTEM;
 if(!S||!S.renderers||!Array.isArray(sections)||typeof DATA==='undefined'||window.ICPT_SPEED_REVIEW)return;
 const MAX_CH=50,UNIT_SIZE=5,FEEDBACK_MS=1800,TICK_MS=70;
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const stripAr=x=>String(x||'').normalize('NFC').replace(/[\u064b-\u065f\u0670\u0640\s]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي');
 const cleanEn=x=>String(x||'').normalize('NFKC').toLowerCase().replace(/\b(?:a|an|the|to)\b/g,' ').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
 const stem=t=>t.replace(/(?:ing|edly|ed|es|s)$/,'');
 const significant=x=>new Set(cleanEn(x).split(' ').map(stem).filter(t=>t.length>2&&!['and','for','with','from','that','this','your','one','some','etc'].includes(t)));
 const ambiguousAr=x=>!/[\u0621-\u064a]/u.test(x)||/[|;]/.test(x)||x.length>140;
 // Keep the full supplied composite gloss as one answer. Semicolon glosses
 // and explanatory parentheticals are not competing multiple-choice answers.
 const ambiguousEn=x=>!/[a-zA-Z]/.test(x)||x.length>110||/\|/.test(x)||/\b(?:or|also|sometimes|and\/or)\b/i.test(x.replace(/\([^)]*\)/g,''));
 const random=()=>Math.random();
 function shuffle(items){const a=items.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
 function overlapped(a,b){const sa=significant(a),sb=significant(b);if(!sa.size||!sb.size)return cleanEn(a)===cleanEn(b);for(const token of sa)if(sb.has(token))return true;return false;}
 function compatible(a,b){if(!a||!b||a.id===b.id||a.arKey===b.arKey||a.enKey===b.enKey)return false;
   if(a.root&&b.root&&a.root===b.root)return false;
   if(a.arParts.some(p=>b.arParts.includes(p)))return false;
   if(a.enKey.includes(b.enKey)||b.enKey.includes(a.enKey)||overlapped(a.en,b.en))return false;
   return true;
 }
 function isSemester2(x){return x?.bank==='core'&&x?._semester2Source===true&&x?.semester===2&&/^glossary:(2[6-9]|[34][0-9]|50)-\d+$/.test(String(x.id||''));}
 function isRecovered(x){return x?.bank==='core'&&x?._ch16_25Source===true&&!x.sourceHold&&/^glossary:(1[6-9]|2[0-5])-\d+$/.test(String(x.id||''));}
 function rawCh(x){const v=Number(x?.chapter);return Number.isInteger(v)&&((v>=1&&v<=15)||(v>=16&&v<=25&&isRecovered(x))||(v>=26&&v<=50&&isSemester2(x)&&Number(String(x.id).split(':')[1].split('-')[0])===v))?v:null;}
 function supplementalScopeSets(){
  const api=window.GH_SUPPLEMENTARY_VOCAB, bank=configuration.bank, exam=configuration.supplementExam||'sources';
  if(!api?.sets)return [];
  const allows=family=>bank==='supplemental'||bank===family;
  const out=[];
  if(exam!=='sources'){
   const sets=api.sets(exam)||[];
   for(const set of sets){const family=set.id==='memrise'?'memrise':set.id==='quizlet125'?'quizlet':null;
    if(family&&allows(family)&&set.rows?.length)out.push({id:family+':'+exam,name:family==='memrise'?'Memrise · ICPT '+exam:'Quizlet · ICPT '+exam,rows:set.rows});}
  }else{
   for(const set of api.sets('sources')||[]){const family=set.id.startsWith('memrise')?'memrise':set.id.startsWith('quizlet')?'quizlet':null;
    if(family&&allows(family)&&set.rows?.length)out.push({id:set.id,name:set.name,rows:set.rows});}
  }
  if(allows('quizlet')&&window.GH_QUIZLET_SUPPLEMENT?.views){
   const groups=new Map();for(const row of window.GH_QUIZLET_SUPPLEMENT.views()||[]){
    if(exam!=='sources'&&String(row.exam)!==exam)continue;
    if(!row.id||!row.listId)continue;const key=String(row.exam||'unassigned')+':'+String(row.listId);
    if(!groups.has(key))groups.set(key,{id:'quizlet-list:'+key,name:'Quizlet · '+(row.exam?'ICPT '+row.exam+' · ':'')+row.listId,rows:[]});groups.get(key).rows.push(row);
   }out.push(...groups.values());
  }
  // Add only actual supplied Memrise groups that also belong to the chosen exam.
  if(exam!=='sources'&&allows('memrise')){
   const examRows=(api.sets(exam)||[]).find(x=>x.id==='memrise')?.rows||[], ids=new Set(examRows.map(x=>String(x.id)));
   for(const set of api.sets('sources')||[]){if(!set.id.startsWith('memrise')||set.id==='memrise267')continue;
    const rows=(set.rows||[]).filter(x=>ids.has(String(x.id)));if(rows.length)out.push({id:set.id,name:set.name+' · ICPT '+exam+' overlap',rows});}
  }
  return out;
 }
 function supplementalScopeHTML(){if(configuration.soundScriptScope)return '<p>Sound &amp; Script · '+esc(configuration.soundScriptScope)+' · '+configuration.supplementIds.length+' selected source entries. Change the source selection in Vocabulary Training.</p>';
  const api=window.GH_SUPPLEMENTARY_VOCAB;if(!api?.sets)return '<p>Supplemental source filters are unavailable in this build.</p>';
  const exams=['101','102','201','202','301','302',...new Set((window.GH_QUIZLET_SUPPLEMENT?.views?.()||[]).map(x=>String(x.exam||'')).filter(x=>/^\d+$/.test(x)))].filter((x,i,a)=>a.indexOf(x)===i).filter(x=>(api.sets(x)||[]).some(s=>(configuration.bank==='quizlet'?s.id==='quizlet125':configuration.bank==='memrise'?s.id==='memrise':['quizlet125','memrise'].includes(s.id))&&s.rows?.length));
  const sets=supplementalScopeSets();
  return '<div class="sr-controls"><label>Exam focus<select id="sr-supp-exam"><option value="sources">All installed source lists</option>'+exams.map(x=>'<option value="'+esc(x)+'" '+(configuration.supplementExam===x?'selected':'')+'>ICPT '+esc(x)+'</option>').join('')+'</select></label><label>'+(configuration.bank==='quizlet'?'ICPT source list':'Memrise source chapter / supplemental set')+'<select id="sr-supp-set"><option value="all">All lists in this scope</option>'+sets.map(x=>'<option value="'+esc(x.id)+'" '+(configuration.supplementSet===x.id?'selected':'')+'>'+esc(x.name)+'</option>').join('')+'</select></label></div><p class="sr-muted">Only supplied source memberships are used. A Quizlet list without chapter metadata stays a named list, not an invented textbook chapter.'+(Array.isArray(configuration.supplementIds)?' The original filtered supplemental selection is still applied. Changing Exam focus or Source chapter/set replaces that selection.':'')+'</p>';
 }
 let supplementalLaunchRows=null;
 function sourceConflictRows(rows){
  const memberships=new Map();for(const m of [...(window.GH_PRIORITY2?.members||[]),...(window.GH_QUIZLET_SUPPLEMENT?.members||[])])if(m?.id)memberships.set(String(m.id),m);
  const concrete=x=>!!(x?.sourceMembershipConflict||x?.conflict||x?.sourceRow?.conflict);
  const occurrenceConflict=x=>concrete(x)||concrete(memberships.get(String(x?.sourceMembershipId||x?.membershipId||'')));
  const chosen=new Map();
  for(const original of rows||[]){if(!original?.id)continue;
   const occurrences=original.supplementaryOccurrences||[];
   const conflict=occurrenceConflict(original)||(occurrences.length>0&&occurrences.every(occurrenceConflict));
   const row=conflict?{...original,sourceMembershipConflict:true}:original;
   const id=String(row.id),previous=chosen.get(id);
   // One conflicting membership must not suppress another legitimate occurrence.
   if(!previous||(concrete(previous)&&!concrete(row)))chosen.set(id,row);
  }
  return [...chosen.values()];
 }
 function supplementalRows(){
  const bank=configuration.bank, seen=new Set();
  if(bank==='supplemental'&&Array.isArray(configuration.supplementIds)&&typeof byId==='object'){const ids=new Set(configuration.supplementIds.map(String));return sourceConflictRows(supplementalLaunchRows||configuration.supplementIds.map(id=>byId[id]).filter(Boolean)).filter(x=>ids.has(String(x.id)));}
  const supplied=supplementalScopeSets();if(window.GH_SUPPLEMENTARY_VOCAB?.sets){const sets=configuration.supplementSet&&configuration.supplementSet!=='all'?supplied.filter(x=>x.id===configuration.supplementSet):supplied;return sourceConflictRows(sets.flatMap(x=>x.rows));}
  return [...(DATA.supplement||[]),...(DATA.memrise||[]),...(DATA.vocab||[])].filter(x=>{
   if(!x||!['quizlet','memrise'].includes(x.bank)||bank!=='supplemental'&&x.bank!==bank||!x.id||seen.has(x.id))return false;
   seen.add(x.id);return true;
  });
 }
 function chapterMetadata(){
  const chapters=new Set(),evidence=new Map();
  for(const x of DATA.vocab||[]){const ch=rawCh(x);if(!ch)continue;chapters.add(ch);const u=Number(x.unit);if(Number.isInteger(u)&&u>=1&&u<=10){if(!evidence.has(ch))evidence.set(ch,new Set());evidence.get(ch).add(u);}}
  const unitByChapter={};for(const ch of chapters){const us=evidence.get(ch);unitByChapter[ch]=us?.size===1?[...us][0]:us?.size>1?null:ch<=15?Math.ceil(ch/5):null;}
  return {chapters:[...chapters].sort((a,b)=>a-b),unitByChapter};
 }
 function chapterScopeRows(){
  const meta=chapterMetadata(),selected=ch=>configuration.mode==='unit'?configuration.units.has(meta.unitByChapter[ch]):configuration.chapters.has(ch),out=[];
  if(configuration.chapterSource!=='memrise')for(const x of DATA.vocab||[])if(selected(rawCh(x)))out.push(x);
  if(configuration.chapterSource!=='textbook')for(const set of window.GH_SUPPLEMENTARY_VOCAB?.sets?.('sources')||[]){
   const a=/^memrise-ch(\d+)$/.exec(set.id),b=/^memrise-p2-U(\d+)C(\d+)$/.exec(set.id);const ch=a?Number(a[1]):b?Number(b[2]):null;
   if(!ch||!selected(ch))continue;
   for(const x of sourceConflictRows(set.rows||[]))if(!x.sourceMembershipConflict&&!x.conflict&&!x.sourceRow?.conflict)out.push({...x,chapter:ch,_speedChapterMemrise:true,sourceLabel:set.name,bank:'memrise'});
  }
  return out;
 }
 function catalogue(){
  // Primary textbook rows only: unassigned Quizlet/Memrise chapters are not assumed equivalent to DLI chapters.
  const supplemental=configuration.bank!=='core', rows=supplemental?supplementalRows():chapterScopeRows(),raw=[];
  const counts={all:rows.length,noChapter:0,noGloss:0,ambiguous:0,homograph:0,duplicate:0};
  const unitEvidence=new Map();
  for(const x of rows){if(supplemental&&(x.sourceMembershipConflict||x.conflict||x.sourceRow?.conflict)){counts.ambiguous++;continue;}const ch=supplemental?(Number.isInteger(x.chapter)&&x.chapter>0?x.chapter:null):(x._speedChapterMemrise?x.chapter:rawCh(x));if(!ch&&!supplemental){counts.noChapter++;continue;}
   const u=Number(x.unit);if(Number.isInteger(u)&&u>=1&&u<=(isSemester2(x)?10:isRecovered(x)?5:3)){const key=ch;const a=unitEvidence.get(key)||[];a.push(u);unitEvidence.set(key,a);}
   const ar=String(x.ar||'').trim(),en=String(x.en||'').trim();
   if(!ar||!en){counts.noGloss++;continue;}
   if(ambiguousAr(ar)||ambiguousEn(en)){counts.ambiguous++;continue;}
   const arKey=stripAr(ar),enKey=cleanEn(en);
   if(!arKey||!enKey){counts.noGloss++;continue;}
   raw.push({id:String(x.id||'ch'+String(ch).padStart(2,'0')+'-'+raw.length),chapter:ch,ar,en,arKey,enKey,
    arParts:ar.split(/\s*\/\s*|\s+[–—-]\s+/u).map(stripAr).filter(Boolean),
    uncertain:!!(x.sourceHold||x.needsCheck||x.studyWarning||x.reviewStatus==='unverified'),canonicalId:String(x.canonicalId||x.id),bank:x.bank,root:stripAr(x?.ling?.root||''),source:x.bank==='sound-script'||x._speedChapterMemrise?x.sourceLabel:isSemester2(x)?'Semester II source glossary (provisional)':'Textbook',semester2:isSemester2(x),recovered:isRecovered(x)});
  }
  // Suppress all conflicting homographs and equivalent answer glosses: isolated prompts cannot disambiguate senses.
  const byAr=new Map(),byEn=new Map();for(const x of raw){
   if(!byAr.has(x.arKey))byAr.set(x.arKey,new Set());byAr.get(x.arKey).add(x.enKey);
   if(!byEn.has(x.enKey))byEn.set(x.enKey,new Set());byEn.get(x.enKey).add(x.arKey);
  }
  const ids=new Set(),canonicalIds=new Set(),items=[];
  for(const x of raw){if(byAr.get(x.arKey).size!==1||byEn.get(x.enKey).size!==1){counts.homograph++;continue;}
   const key=x.arKey+'|'+x.enKey;if(ids.has(key)||supplemental&&canonicalIds.has(x.canonicalId)){counts.duplicate++;continue;}ids.add(key);canonicalIds.add(x.canonicalId);items.push(x);
  }
  const unitByChapter={};for(let chapter=1;chapter<=MAX_CH;chapter++){
   const seen=unitEvidence.get(chapter)||[];
   const values=[...new Set(seen)];
   // Chapter 1-5 / 6-10 / 11-15 comes from the supplied U01/U02/U03 lesson source labels.
   unitByChapter[chapter]=values.length===1?values[0]:values.length>1?null:chapter<=15?Math.ceil(chapter/UNIT_SIZE):null;
  }
  if(!supplemental){const meta=chapterMetadata();return {items,counts,...meta};}
  return {items,counts,unitByChapter,chapters:[...new Set(items.map(x=>x.chapter).filter(Number.isInteger))].sort((a,b)=>a-b)};
 }
 let catalog=null,catalogRows=null,catalogLength=-1,configuration={bank:'core',chapterSource:'textbook',mode:'unit',unit:1,units:new Set([1]),supplementExam:'sources',supplementSet:'all',chapters:new Set([1]),length:10,time:8,direction:'ar-en',autoPronounce:true},session=null,lastSummary=null,message='',ticker=null,previousTail=null,audioRequest=0;
 function stopAudio(reason='Speed Review stopped'){audioRequest++;if(session)session.audioPending=false;window.GH_UPDATE1_AUDIO?.stop?.();window.GH_CH16_25_MEDIA?.stop?.();window.GH_SEM2_MEDIA?.stop?.();window.GH457_AUDIO_QUEUE?.stop?.(reason);window.GH457_AUDIO?.stop?.(reason);}
 async function pronounceCorrect(){
  if(!session||session.phase!=='feedback'||session.paused)return false;
  const s=session,q=s.question,index=s.index,token=++audioRequest,audioOwner=owner();if(q.target.bank==='sound-script')return false;
  const isCurrent=()=>session===s&&s.question===q&&s.index===index&&s.phase==='feedback'&&!s.paused&&token===audioRequest&&owner()===audioOwner&&typeof tab!=='undefined'&&tab===ROUTE;
  s.audioPending=true;s.audioResult=null;s.advanceAt=Infinity;show();
  let result;
  try{
   if(q.target.recovered){result=window.GH_CH16_25_MEDIA?.play?await window.GH_CH16_25_MEDIA.play(q.target.id,{kind:'word',isCurrent:()=>session===s&&s.index===index&&s.phase==='feedback'&&!s.paused&&token===audioRequest&&typeof tab!=='undefined'&&tab===ROUTE}):{ok:false,reason:'No verified recovered audio route'};}else if(q.target.semester2){result=window.GH_SEM2_MEDIA?.play?await window.GH_SEM2_MEDIA.play(q.target.id,{kind:'word',isCurrent:()=>session===s&&s.index===index&&s.phase==='feedback'&&!s.paused&&token===audioRequest&&typeof tab!=='undefined'&&tab===ROUTE}):{ok:false,reason:'Semester II audio adapter unavailable'};}
   else if(window.GH_UPDATE1_AUDIO?.route?.(q.target.id,'word'))result=await window.GH_UPDATE1_AUDIO.play(q.target.id,{kind:'word',isCurrent:()=>session===s&&s.index===index&&s.phase==='feedback'&&!s.paused&&token===audioRequest&&typeof tab!=='undefined'&&tab===ROUTE});
   else if(!window.GH457_AUDIO_QUEUE?.play)result={ok:false,reason:'Bounded word-audio queue is unavailable. Reload the complete R3 build.'};
   else{
    const queue=window.GH457_AUDIO_QUEUE;
    // The queue latches the correct answer only after asynchronous authority preparation.
    // Keep this wait bound to the captured question; never request a wider audio stage.
    if(q.audioUnlocked&&q.wordQueueAdmission){
     let deadline;
     let admission;
     try{admission=await Promise.race([q.wordQueueAdmission,new Promise(resolve=>{deadline=setTimeout(()=>resolve('timeout'),FEEDBACK_MS);})]);}
     finally{if(deadline!==undefined)clearTimeout(deadline);}
     if(!isCurrent())return false;
     if(admission!=='settled')result={ok:false,reason:admission==='timeout'?'Verified word-audio admission did not complete in time.':'Verified word-audio admission failed.'};
    }
    if(!result)result=await queue.play(q.target.id,{stage:q.audioUnlocked?'word-trim':'arabic-only',review:true,isCurrent});
   }
  }catch(error){result={ok:false,reason:String(error?.message||error)};}
  if(!isCurrent())return false;
  s.audioPending=false;s.audioResult=result;s.feedbackRemaining=FEEDBACK_MS;s.advanceAt=now()+FEEDBACK_MS;
  show();return result?.ok===true;
 }
 const owner=()=>typeof state==='undefined'?'no-state':JSON.stringify([state?._save45?.profileId||'',state?._save45?.epoch||'']);
 let ownerSignature=owner();
 const uncertainRewardOwners=new Set();
 const uncertainRewardMessage='Round ended because the last practice reward could not be verified. Its XP may or may not have been saved. Keep your work open and use Save & recovery before starting another round.';
 function checkOwner(){if(ownerSignature===owner())return true;stopAudio('Hunter changed');ownerSignature=owner();session=null;lastSummary=null;stopTick();message='Hunter changed. Private round state was cleared.';return false;}
 let catalogScopeKey='';
 function getCatalog(){if(configuration.bank!=='core')return catalogue();
  const key=JSON.stringify([configuration.chapterSource,configuration.mode,[...configuration.units].sort((a,b)=>a-b),[...configuration.chapters].sort((a,b)=>a-b),DATA.memrise?.length,window.GH_PRIORITY2?.ready,window.GH_PRIORITY2?.members?.length]);
  if(!catalog||catalogRows!==DATA.vocab||catalogLength!==DATA.vocab.length||catalogScopeKey!==key){catalog=catalogue();catalogRows=DATA.vocab;catalogLength=DATA.vocab.length;catalogScopeKey=key;}return catalog;
 }
 const now=()=>performance.now();
 function eligibleScope(c=getCatalog()){if(configuration.bank!=='core')return Array.isArray(configuration.supplementIds)?c.items.filter(x=>configuration.supplementIds.includes(x.id)):c.items;return c.items.filter(x=>configuration.mode==='unit'?configuration.units.has(c.unitByChapter[x.chapter]):configuration.chapters.has(x.chapter));}
 function findDistractors(x,pool,ordered){const others=ordered||pool.slice().sort((a,b)=>a.enKey.localeCompare(b.enKey));const chosen=[];for(const p of others){if(compatible(x,p)&&chosen.every(q=>compatible(p,q))){chosen.push(p);if(chosen.length===3)break;}}return chosen.length===3?chosen:null;}
 function eligibleQuestion(x,pool){return !!findDistractors(x,pool);}
 function targetsFor(pool){const ordered=pool.slice().sort((a,b)=>a.enKey.localeCompare(b.enKey));return pool.filter(x=>!!findDistractors(x,pool,ordered));}
 function directionFor(index){return configuration.direction==='mixed'?(index%2===0?'ar-en':'en-ar'):configuration.direction;}
 function stopTick(){if(ticker!==null){clearInterval(ticker);ticker=null;}}
 function tick(){if(!checkOwner()){show();return;}if(!session)return stopTick();if(typeof tab!=='undefined'&&tab!==ROUTE){stopAudio('Left Speed Review');session=null;stopTick();return;}
  if(typeof state!=='undefined'&&state?.active){stopAudio('Assessment started');session=null;stopTick();message='An assessment started; Speed Review stopped to protect blind content.';return;}
  if(document.hidden){pauseRound(true);return;}
  if(session.paused)return;
  if(session.phase==='question'){
   if(session.timeLimit!==null){session.remaining=Math.max(0,session.deadline-now());
    const clock=document.getElementById('sr-clock');if(clock)clock.textContent=Math.ceil(session.remaining/1000)+'s';
    if(session.remaining<=0){answer(null,true);return;}
   }
  }else if(session.phase==='feedback'&&!session.audioPending&&now()>=session.advanceAt){advance();}
 }
 function keepTick(){if(ticker===null)ticker=setInterval(tick,TICK_MS);}
 function rotateAfterPrevious(items){if(items.length>1&&previousTail&&items[0].id===previousTail){items.push(items.shift());}return items;}
 function start(mistakes=false){
  if(!checkOwner()){show();return false;}
  if(typeof state!=='undefined'&&state?.active){message='Finish the active assessment first.';show();return false;}
  if(uncertainRewardOwners.has(owner())){show();return false;}
  const pool=lastSummary&&mistakes?lastSummary.pool:eligibleScope();
  const viable=targetsFor(pool);if(viable.length<4){message='At least four unambiguous, distinct choices within the selected scope are required. Choose more chapters.';show();return false;}
  let picked=mistakes?viable.filter(x=>new Set(lastSummary?.missedIds||[]).has(x.id)):viable;
  if(!picked.length){message='No missed words to review.';show();return false;}
  picked=rotateAfterPrevious(shuffle(picked));
  const request=configuration.length==='all'?picked.length:Math.min(Number(configuration.length)||10,picked.length);
  picked=picked.slice(0,request);
  stopAudio('New round');stopTick();session={pool,queue:picked,roundKind:mistakes?'mistakes':'normal',index:0,answers:[],phase:'question',paused:false,timeLimit:configuration.time===0?null:configuration.time*1000,deadline:0,remaining:configuration.time*1000,advanceAt:0,feedbackRemaining:FEEDBACK_MS,question:null,locked:false,audioPending:false,audioResult:null};
  if(!configuration.soundScriptScope)window.GH457_AUDIO_QUEUE?.setStudySet?.(picked.map(x=>x.id),{owner:owner(),source:'speed-review',mode:'review'});
  message='';buildQuestion();keepTick();show();return true;
 }
 function optionsFor(target,pool){const distractors=findDistractors(target,pool);return distractors?shuffle([target,...distractors]):null;} 
 function buildQuestion(){if(!session)return;
  const target=session.queue[session.index],direction=directionFor(session.index);
  const choices=optionsFor(target,session.pool);
  if(!choices){ // Defensive fallback: never introduce an out-of-scope or ambiguous option.
    session.answers.push({id:target.id,ar:target.ar,en:target.en,chapter:target.chapter,outcome:'skipped',reason:'no-distinct-distractors'});
    session.index++;if(session.index>=session.queue.length){finish();return;}return buildQuestion();
  }
  session.question={target,choices,direction,selected:null,wasTimeout:false};session.phase='question';session.locked=false;session.audioPending=false;session.audioResult=null;
  session.question.practiceToken=target.bank==='sound-script'?null:window.GH_PRACTICE_REWARDS457?.begin('speed-review',target.id,session.question)||null;
  session.question.audioEncounter='speed:'+owner()+':'+session.index+':'+target.id+':'+now();
  if(target.bank!=='sound-script')window.GH457_AUDIO_QUEUE?.select?.(target.id,{owner:owner(),index:session.index,encounterId:session.question.audioEncounter,review:true});
  session.remaining=session.timeLimit||0;session.deadline=session.timeLimit===null?Infinity:now()+session.remaining;
 }
 async function answer(which,timeout=false){if(!checkOwner()){show();return false;}if(!session||session.phase!=='question'||session.paused||session.locked)return false;
  if(which!==null&&(!Number.isInteger(which)||which<0||which>3))return false;
  session.locked=true;const answeringSession=session,answeringOwner=owner();const q=session.question;const picked=which===null?null:q.choices[which];
  const outcome=which===null?'skipped':picked.id===q.target.id?'correct':'incorrect';
  q.selected=which;q.wasTimeout=!!timeout;
   let reward;
   try{reward=q.target.bank==='sound-script'?{xp:0,reason:'Source recognition only'}:await window.GH_PRACTICE_REWARDS457?.complete(q.practiceToken,{correct:outcome==='correct',answered:which!==null&&!timeout,assisted:false,revealed:false,isCurrent:()=>session?.question===q&&session.phase==='question'&&!session.paused&&tab===ROUTE})||{xp:0,reason:'Practice rewards unavailable'};}
   catch(_){
    uncertainRewardOwners.add(answeringOwner);
    if(session!==answeringSession||owner()!==answeringOwner||session.question!==q||tab!==ROUTE||state?.active)return false;
    session=null;lastSummary=null;stopTick();
    try{stopAudio('Speed Review ended: reward status uncertain');}catch(_){}
    try{window.GH457_AUDIO_QUEUE?.cancel?.('Speed Review ended: reward status uncertain');}catch(_){}
    try{window.GH_PROGRESS45?.markUncommitted?.(uncertainRewardMessage);}catch(_){}
    show();return false;
   }
  if(session!==answeringSession||owner()!==answeringOwner||session.question!==q||tab!==ROUTE)return false;
  session.answers.push({id:q.target.id,ar:q.target.ar,en:q.target.en,chapter:q.target.chapter,source:q.target.source,bank:q.target.bank,outcome,direction:q.direction,
   selected:picked?{ar:picked.ar,en:picked.en}:null,reason:timeout?'time-expired':'',practiceXP:reward.xp,practiceRewardReason:reward.reason});
  session.phase='feedback';session.feedbackRemaining=FEEDBACK_MS;session.advanceAt=now()+FEEDBACK_MS;
  q.audioUnlocked=outcome==='correct';
  // A wrong choice still pronounces the correct Arabic target (when verified),
  // but does not unlock its English audio. Text-feedback timing is unchanged.
  if(q.target.bank!=='sound-script'){
   try{
    const admission=window.GH457_AUDIO_QUEUE?.onAnswer?.(q.target.id,{correct:q.audioUnlocked,revealed:false,attemptId:q.audioEncounter,auto:false});
    q.wordQueueAdmission=Promise.resolve(admission).then(()=> 'settled',()=> 'failed');
   }catch(_){q.wordQueueAdmission=Promise.resolve('failed');}
  }
  show();if(which!==null&&configuration.autoPronounce)void pronounceCorrect();return true;
 }
 function advance(){if(!session||session.phase!=='feedback'||session.paused||session.audioPending)return false;
  session.index++;if(session.index>=session.queue.length){finish();return true;}buildQuestion();show();return true;
 }
 function finish(){if(!session)return;
  const a=session.answers,c=a.filter(x=>x.outcome==='correct').length,w=a.filter(x=>x.outcome==='incorrect').length,k=a.filter(x=>x.outcome==='skipped').length;
  lastSummary={total:a.length,correct:c,incorrect:w,skipped:k,accuracy:a.length?Math.round(100*c/a.length):0,
    misses:a.filter(x=>x.outcome!=='correct'),missedIds:[...new Set(a.filter(x=>x.outcome!=='correct').map(x=>x.id))],
    pool:session.pool.slice(),direction:configuration.direction,roundKind:session.roundKind,practiceXP:a.reduce((n,x)=>n+(x.practiceXP||0),0)};
  previousTail=session.queue.at(-1)?.id||null;stopAudio('Round finished');session=null;stopTick();show();
 }
 function pauseRound(automatic=false){if(!session||session.paused)return false;
  if(session.phase==='question'&&session.timeLimit!==null)session.remaining=Math.max(0,session.deadline-now());
  if(session.phase==='feedback'){session.feedbackRemaining=session.audioPending?FEEDBACK_MS:Math.max(0,session.advanceAt-now());stopAudio('Round paused');}
  session.paused=true;session.autoPause=automatic;show();return true;
 }
 function resumeRound(){if(!checkOwner()){show();return false;}if(!session||!session.paused)return false;
  if(typeof state!=='undefined'&&state?.active)return false;
  session.paused=false;session.autoPause=false;if(session.phase==='question'&&session.timeLimit!==null)session.deadline=now()+session.remaining;
  if(session.phase==='feedback')session.advanceAt=now()+session.feedbackRemaining;
  keepTick();show();return true;
 }
 function exitRound(){const hadRound=!!session;stopTick();let cleanupIssue='';try{stopAudio('Round exited');}catch(error){cleanupIssue=' Audio cleanup reported an error.';}try{window.GH457_AUDIO_QUEUE?.cancel?.('Speed Review exited');}catch(error){cleanupIssue=' Audio cleanup reported an error.';}session=null;lastSummary=null;message='Round exited. Practice XP already earned by submitted answers is kept; no mastery or listening evidence was saved.'+cleanupIssue;show();return hadRound;}
 const button=(label,action,extra='')=>`<button type="button" data-sr-action="${action}" ${extra}>${label}</button>`;
 function css(){if(document.getElementById('gh-sr-style'))return;const style=document.createElement('style');style.id='gh-sr-style';style.textContent=`
 .sr-panel{max-width:850px;margin:1rem auto;padding:1rem 1.5rem;border:1px solid #52708c;border-radius:14px;background:#102238;color:#f0f5fa}
 .sr-panel h1,.sr-panel h2{color:#d0eafb}.sr-panel button,.sr-panel select{font:inherit;max-width:100%}.sr-panel button{border:1px solid #6d9dc5;border-radius:8px;background:#1b4263;color:#fff;padding:.65rem .9rem;cursor:pointer}
 .sr-panel button[disabled]{opacity:.45;cursor:not-allowed}.sr-panel button:focus-visible,.sr-panel input:focus-visible,.sr-panel select:focus-visible{outline:3px solid #f0d36b;outline-offset:2px}
 .sr-panel label{display:block;margin:.5rem 0}.sr-controls{display:flex;flex-wrap:wrap;align-items:end;gap:1rem}.sr-controls label{flex:1;min-width:145px}
 .sr-panel select{background:#091a2b;color:#fff;border:1px solid #6486a8;border-radius:6px;padding:.45rem;width:100%}
 .sr-chapters{display:grid;grid-template-columns:repeat(auto-fill,minmax(125px,1fr));gap:.4rem;padding:.7rem;border:1px solid #486781;border-radius:8px}
 .sr-chapters label{display:flex;gap:.4rem;align-items:center}.sr-options{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin:1rem 0}
 .sr-options button{min-height:76px;text-align:center;font-size:1.1rem;overflow-wrap:anywhere}
 .sr-options button[lang=ar]{direction:rtl;font-size:1.55rem;line-height:1.7}
 .sr-options .sr-right{border-color:#7de3ad;background:#1c5a47}.sr-options .sr-wrong{border-color:#f6a3a3;background:#6c2f3a}
 .sr-prompt{font-size:2.3rem;line-height:1.6;min-height:75px;text-align:center;margin:1rem 0;overflow-wrap:anywhere}
 .sr-prompt[lang=ar]{direction:rtl}.sr-prompt[lang=en]{font-size:1.65rem}
 .sr-status{display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap}.sr-bar{height:8px;background:#193148;border-radius:5px;overflow:hidden}.sr-bar>div{background:#7bbadb;height:100%}
 .sr-feedback{min-height:62px;font-weight:650;padding:.5rem;border-left:3px solid #7bbadb;margin:.5rem 0}
 .sr-muted{color:#bbd0de;font-size:.92rem}.sr-misses{max-height:290px;overflow:auto;padding:0 1rem}.sr-misses li{margin:.5rem 0}
 .sr-launch{padding:1rem;border:1px solid #587b99;border-radius:10px;margin:1rem 0;background:#122b40}.sr-actions{display:flex;flex-wrap:wrap;gap:.6rem;margin:1rem 0}
 @media(max-width:600px){.sr-options{grid-template-columns:1fr}.sr-panel{padding:.8rem}.sr-options button{min-height:60px}}
 `;document.head.append(style);}
 function keyOverlapHTML(){
  const current=eligibleScope(), selected=new Map(current.map(x=>[String(x.canonicalId||x.id),x]));
  const api=window.GH_SUPPLEMENTARY_VOCAB;if(!api?.sets)return '<p>Installed ICPT key-vocabulary lists are unavailable.</p>';
  const exams=[...new Set(['101','102','201','202','301','302',...(window.GH_QUIZLET_SUPPLEMENT?.views?.()||[]).map(x=>String(x.exam||'')).filter(x=>/^\d+$/.test(x))])];
  const blocks=[];
  for(const exam of exams){const key=(api.sets(exam)||[]).find(x=>x.id==='key60');if(!key?.rows?.length)continue;
   const matches=key.rows.map(x=>({row:x,target:selected.get(String(x.canonicalId||x.id))})).filter(x=>x.target);
   if(!matches.length)continue;
   blocks.push('<h3>ICPT '+esc(exam)+' · '+matches.length+' overlapping words</h3><ul>'+matches.map(({row,target})=>'<li><span lang="ar" dir="rtl">'+esc(target.ar)+'</span> — '+esc(target.en)+'<br><small>Textbook Chapter '+esc(target.chapter)+' · ICPT '+esc(exam)+' key-vocabulary overlap. Sources: '+esc((row.keyEvidence?.lists||[]).join('; ')||row.supplementaryViewSource||row.sourceMembershipGroup||row.listId||'Installed ICPT recommendation list')+'</small></li>').join('')+'</ul>');
  }
  return '<p>This is an overlap between existing word identities, not a Quizlet chapter assignment. ICPT key lists are source-recurrence study recommendations, not an official exam key or complete exam coverage.</p>'+(blocks.join('')||'<p>No exact stored-identity overlap was found for the selected textbook scope. Similar-looking words were not guessed to be equivalent.</p>');
 }
 document.addEventListener('toggle',e=>{if(e.target?.id==='sr-key-overlap'&&e.target.open&&typeof tab!=='undefined'&&tab===ROUTE){const box=e.target.querySelector('[data-sr-key-overlap]');if(box&&!box.dataset.loaded){box.innerHTML=keyOverlapHTML();box.dataset.loaded='true';}}},true);
 function renderConfig(){const c=getCatalog(),scope=eligibleScope(c),unitChapters=c.chapters.filter(ch=>configuration.units.has(c.unitByChapter[ch]));
  const chosen=configuration.mode==='unit'?unitChapters:[...configuration.chapters].sort((a,b)=>a-b);
  return `<div class="sr-panel" data-sr-screen="setup"><h1>Vocabulary Speed Review</h1><p class="sr-muted">Recognition practice · ${configuration.soundScriptScope?'Source recognition score only; no XP.':'2 XP per correct answer, with no daily cap.'} Incorrect answers, skips and timeouts earn no XP. No typing/listening mastery or course grades.</p>
  <label>Vocabulary bank<select id="sr-bank"><option value="core" ${configuration.bank==='core'?'selected':''}>Chapter vocabulary</option><option value="quizlet" ${configuration.bank==='quizlet'?'selected':''}>Quizlet supplements</option><option value="memrise" ${configuration.bank==='memrise'?'selected':''}>Memrise supplements</option><option value="supplemental" ${configuration.bank==='supplemental'?'selected':''}>${configuration.soundScriptScope?'Sound &amp; Script selected sources':'All supplemental vocabulary'}</option></select></label><p class="sr-muted">Supplemental banks use their source labels, not assumed textbook chapters. Only concrete conflicts, missing usable text, or ambiguous scored choices are withheld. Missing pronunciation is reported, not fabricated. Existing practice-reward eligibility still applies.</p>
  ${message?`<p role="status">${esc(message)}</p>`:''}
  ${configuration.bank==='core'?`<label>Chapter sources<select id="sr-chapter-source"><option value="textbook" ${configuration.chapterSource==='textbook'?'selected':''}>DLI textbook only</option><option value="memrise" ${configuration.chapterSource==='memrise'?'selected':''}>Chapter Memrise only</option><option value="both" ${configuration.chapterSource==='both'?'selected':''}>DLI textbook + chapter Memrise</option></select></label><fieldset><legend>Choose scope</legend><label><input type="radio" name="sr-scope" value="unit" ${configuration.mode==='unit'?'checked':''}> One or more units</label> <label><input type="radio" name="sr-scope" value="chapters" ${configuration.mode==='chapters'?'checked':''}> One or more chapters</label></fieldset>
  ${configuration.mode==='unit'?`<fieldset><legend>Units</legend><div class="sr-chapters">${[...new Set(c.chapters.map(ch=>c.unitByChapter[ch]).filter(Number.isInteger))].sort((a,b)=>a-b).map(u=>`<label><input type="checkbox" data-sr-unit="${u}" ${configuration.units.has(u)?'checked':''}> Unit ${u}</label>`).join('')}</div></fieldset>`:
  `<fieldset><legend>Chapters</legend><div class="sr-chapters">${c.chapters.map(ch=>`<label><input type="checkbox" data-sr-chapter="${ch}" ${configuration.chapters.has(ch)?'checked':''}> Chapter ${ch}</label>`).join('')}</div></fieldset>`}
  `:supplementalScopeHTML()}
  ${configuration.bank==='core'?'<details id="sr-key-overlap"><summary>Show ICPT key-vocabulary overlap for this textbook scope</summary><div data-sr-key-overlap></div></details>':''}
  <div class="sr-controls"><label>Question direction<select id="sr-direction"><option value="ar-en" ${configuration.direction==='ar-en'?'selected':''}>Arabic → 4 English meanings</option><option value="en-ar" ${configuration.direction==='en-ar'?'selected':''}>English meaning → 4 Arabic choices</option><option value="mixed" ${configuration.direction==='mixed'?'selected':''}>Alternate both directions</option></select></label>
  <label>Round length<select id="sr-length">${[5,10,15,20,30,50,'all'].map(n=>`<option value="${n}" ${String(configuration.length)===String(n)?'selected':''}>${n==='all'?'All available':n+' questions'}</option>`).join('')}</select></label>
  <label>Time per answer<select id="sr-time">${[0,3,5,8,10,15,20,30].map(n=>`<option value="${n}" ${configuration.time===n?'selected':''}>${n===0?'Untimed':n+' seconds'}</option>`).join('')}</select></label></div>
  <label><input type="checkbox" id="sr-auto-pronounce" ${configuration.soundScriptScope?'disabled':''} ${configuration.autoPronounce?'checked':''}> Pronounce the correct Arabic target after I submit an answer</label>
  <p class="sr-muted" data-sr-count>${configuration.bank==='core'?'Selected chapters: '+esc(chosen.join(', ')||'none'): 'Selected bank: '+esc(configuration.bank)}. ${scope.length} distinct source entries. Each question uses four distinct, in-scope choices; ambiguous entries are excluded when the round starts.</p>
  ${button('Start Speed Review','start',scope.length<4?'disabled':'')}
  <p class="sr-muted">Distractors are checked for identical/overlapping English labels, duplicate Arabic spellings, and shared supplied roots. Similar meanings still require instructor review. Chapter Memrise uses only explicitly assigned chapter lists. ICPT, Quizlet, topic and miscellaneous lists remain in their own supplemental filters.</p></div>`;
 }
 function renderQuestion(){const s=session,q=s.question,feedback=s.phase==='feedback',correctAt=q.choices.findIndex(x=>x.id===q.target.id);
  return `<div class="sr-panel" data-sr-screen="question"><h1>${s.roundKind==='mistakes'?'Review mistakes':'Vocabulary Speed Review'}</h1>
   <div class="sr-status"><strong>Question ${s.index+1} of ${s.queue.length}</strong><span id="sr-clock" role="timer">${s.timeLimit===null?'Untimed':Math.ceil(s.remaining/1000)+'s'}</span><span>${s.paused?'Paused':feedback?'Feedback':'Choose 1–4'}</span></div>
   <div class="sr-bar" aria-hidden="true"><div style="width:${Math.round(100*s.index/s.queue.length)}%"></div></div>
   <p class="sr-muted">${q.direction==='ar-en'?'Choose the English meaning':'Choose the Arabic form'} · ${q.target.bank==='sound-script'?esc(q.target.source):q.target.bank==='quizlet'?'Quizlet supplement':q.target.bank==='memrise'?'Memrise supplement':'Chapter '+q.target.chapter}${q.target.semester2?' · Provisional source recognition; not certified mastery':''}</p>
   <div class="sr-prompt" lang="${q.direction==='ar-en'?'ar':'en'}">${esc(q.direction==='ar-en'?q.target.ar:q.target.en)}</div>
   <div class="sr-options" role="group" aria-label="Four answer choices">${q.choices.map((choice,i)=>`<button type="button" lang="${q.direction==='ar-en'?'en':'ar'}" data-sr-choice="${i}" ${feedback||s.paused?'disabled':''} class="${feedback&&i===correctAt?'sr-right':feedback&&i===q.selected?'sr-wrong':''}">${i+1}. ${esc(q.direction==='ar-en'?choice.en:choice.ar)}</button>`).join('')}</div>
   <div class="sr-feedback" role="status" aria-live="polite">${feedback?`${s.answers.at(-1).outcome==='correct'?'Correct.':s.answers.at(-1).reason==='time-expired'?"Time’s up. ":s.answers.at(-1).outcome==='skipped'?'Skipped.':'Incorrect.'} Answer: <span lang="ar">${esc(q.target.ar)}</span> — ${esc(q.target.en)}. ${s.audioPending?'Playing the correct target; feedback stays visible.':s.paused?'Paused.':'Advancing automatically.'}${s.audioResult&&!s.audioResult.ok&&!s.audioResult.cancelled?`<p>Audio unavailable • ${esc(s.audioResult.reason||'Playback failed')}. The round can continue.</p>`:''}${s.audioResult?.warning?`<p class="mini">${esc(s.audioResult.warning)}</p>`:''}${s.audioResult?.kind==='synthetic'?'<p class="mini">Synthetic Arabic</p>':''}`:s.paused?'Paused. Resume to continue.':'Select the correct answer (keys 1–4).'} </div>
   <div class="sr-actions">${s.paused?button('Resume','resume'):button('Pause','pause')}${!feedback?button('Skip','skip',s.paused?'disabled':''):button('↻ Replay correct Arabic','replay',s.paused||q.target.bank==='sound-script'?'disabled':'')+button('Next','next',s.paused||s.audioPending?'disabled':'')}${button('Exit round','exit')}</div>
   <label><input type="checkbox" id="sr-auto-pronounce" ${configuration.soundScriptScope?'disabled':''} ${configuration.autoPronounce?'checked':''}> Automatic pronunciation after answers</label>
   <p class="sr-muted">Practice XP this round: ${s.answers.reduce((n,x)=>n+(x.practiceXP||0),0)} · ${q.target.bank==='sound-script'?'Source recognition only · no XP':'2 XP per correct answer · no daily cap'} · no mastery or listening credit.</p></div>`;
 }
 function renderResults(){const a=lastSummary;
  return `<div class="sr-panel" data-sr-screen="results"><h1>Speed Review results</h1><p class="sr-muted">${a.roundKind==='mistakes'?'Mistake review':'Round complete'} · Practice XP: ${a.practiceXP||0} · no recorded mastery or listening credit.</p>
   <div class="sr-status"><strong data-sr-correct>Correct: ${a.correct}</strong><strong data-sr-incorrect>Incorrect: ${a.incorrect}</strong><strong data-sr-skipped>Skipped: ${a.skipped}</strong><strong data-sr-accuracy>Accuracy: ${a.accuracy}%</strong></div>
   <h2>Missed words (${a.misses.length})</h2>${a.misses.length?`<ol class="sr-misses">${a.misses.map(x=>`<li><span lang="ar">${esc(x.ar)}</span> — ${esc(x.en)} (${esc(x.reason==='time-expired'?'Time expired':x.outcome)}, ${x.bank==='sound-script'?esc(x.source):'Chapter '+x.chapter})</li>`).join('')}</ol>`:'<p>None missed in this round.</p>'}
   <div class="sr-actions">${button('Review mistakes','mistakes',a.missedIds.length?'':'disabled')}${button('Play again','again')}${button('Change scope and settings','settings')}</div></div>`;
 }
 function screen(){css();checkOwner();if(typeof state!=='undefined'&&state?.active)return `<div class="sr-panel"><h1>Vocabulary Speed Review</h1><p>Unavailable during a blind assessment. Finish or exit that assessment first.</p></div>`;
  if(uncertainRewardOwners.has(owner()))return '<div class="sr-panel"><h1>Vocabulary Speed Review</h1><p role="alert">'+esc(uncertainRewardMessage)+'</p></div>';
  if(session)return renderQuestion();return lastSummary?renderResults():renderConfig();}
 function show(){if(typeof tab==='undefined'||tab!==ROUTE||typeof render!=='function')return;render();}
 function goto(){if(typeof state!=='undefined'&&state?.active)return;
  if(typeof go==='function'){go(ROUTE);return;}
  if(typeof tab!=='undefined'){tab=ROUTE;if(typeof nav==='function')nav();if(typeof render==='function')render();}
 }
 // The mode is a direct Vocabulary sub-entry, not gated by dailyReady, arcade locks or XP.
 function installVocabularyShortcut(){for(const section of sections){const id=section?.[0],label=String(section?.[1]||'');
   if(id===ROUTE||!/vocab|word bank/i.test(label))continue;
   const original=S.renderers[id];if(typeof original!=='function'||original.__ghSpeedWrapped)continue;
   const wrapped=function(...args){const result=original.apply(this,args);if(typeof result!=='string'||result.includes('data-sr-launch'))return result;
    return `<aside class="sr-launch" data-sr-launch><strong>Vocabulary Speed Review</strong><p>Rapid four-choice Arabic/English practice by unit or chapter. No unlocks; separate modest practice XP.</p>${button('Open Speed Review','open')}</aside>`+result;};
   wrapped.__ghSpeedWrapped=true;S.renderers[id]=wrapped;
  }}
 // Fallback for native Vocabulary renderers not exposed in S.renderers (legacy app tab switch).
 // Injects only into the current Vocabulary tab; does not modify the game's render() function.
 function nativeVocabShortcut(){
  if(typeof tab==='undefined'||tab===ROUTE||typeof state!=='undefined'&&state?.active)return;
  const activeSection=sections.find(x=>x?.[0]===tab);
  if(!activeSection||!/vocab|word bank/i.test(String(activeSection[1]||'')))return;
  if(document.querySelector('[data-sr-launch]'))return;
  const host=document.querySelector('#app-content,#view,#content,#app,main,#host');if(!host)return;
  const aside=document.createElement('aside');aside.className='sr-launch';aside.dataset.srLaunch='native';
  aside.innerHTML='<strong>Vocabulary Speed Review</strong><p>Four-choice study by unit or chapter; no arcade requirements. Separate modest practice XP, not mastery credit.</p>'+button('Open Speed Review','open');
  host.prepend(aside);
 }
 let shortcutQueued=false;
 function scheduleShortcut(){if(shortcutQueued)return;shortcutQueued=true;queueMicrotask(()=>{shortcutQueued=false;nativeVocabShortcut();});}
 if(typeof MutationObserver==='function'&&document.body){new MutationObserver(scheduleShortcut).observe(document.body,{childList:true,subtree:true});}
 document.addEventListener('change',e=>{
  if(typeof tab==='undefined'||tab!==ROUTE)return;
  if(e.target?.id==='sr-auto-pronounce'){configuration.autoPronounce=!!e.target.checked;if(!configuration.autoPronounce&&session?.audioPending){stopAudio('Automatic pronunciation disabled');session.advanceAt=now()+FEEDBACK_MS;session.feedbackRemaining=FEEDBACK_MS;}show();return;}
  if(session||lastSummary)return;
  const t=e.target;if(!t)return;
  if(t.id==='sr-bank'){delete configuration.soundScriptScope;delete configuration.supplementIds;supplementalLaunchRows=null;configuration.bank=['core','quizlet','memrise','supplemental'].includes(t.value)?t.value:'core';configuration.supplementExam='sources';configuration.supplementSet='all';catalog=null;show();}
  else if(t.id==='sr-chapter-source'){configuration.chapterSource=['textbook','memrise','both'].includes(t.value)?t.value:'textbook';catalog=null;show();}
  else if(t.name==='sr-scope'){configuration.mode=t.value;if(t.value==='chapters'&&!configuration.chapters.size)configuration.chapters=new Set(getCatalog().chapters.filter(ch=>configuration.units.has(getCatalog().unitByChapter[ch])));show();}
  else if(t.dataset.srUnit){const n=Number(t.dataset.srUnit);if(t.checked)configuration.units.add(n);else configuration.units.delete(n);show();}
  else if(t.id==='sr-supp-exam'){delete configuration.supplementIds;supplementalLaunchRows=null;configuration.supplementExam=t.value;configuration.supplementSet='all';show();}
  else if(t.id==='sr-supp-set'){delete configuration.supplementIds;supplementalLaunchRows=null;configuration.supplementSet=t.value;show();}
  else if(t.dataset.srChapter){const n=Number(t.dataset.srChapter);if(t.checked)configuration.chapters.add(n);else configuration.chapters.delete(n);show();}
  else if(t.id==='sr-direction'){configuration.direction=['ar-en','en-ar','mixed'].includes(t.value)?t.value:'ar-en';show();}
  else if(t.id==='sr-length'){configuration.length=t.value==='all'?'all':Number(t.value);show();}
  else if(t.id==='sr-time'){configuration.time=Number(t.value);show();}
 });
 document.addEventListener('click',e=>{
  const b=e.target?.closest?.('[data-sr-action],[data-sr-choice]');if(!b)return;
  const isLaunch=b.dataset.srAction==='open';if(typeof tab!=='undefined'&&tab!==ROUTE&&!isLaunch)return;
  e.preventDefault();if(typeof state!=='undefined'&&state?.active)return;
  if(isLaunch){goto();return;}
  if(b.hasAttribute('data-sr-choice')){answer(Number(b.dataset.srChoice));return;}
  switch(b.dataset.srAction){case 'start':start();break;case 'skip':answer(null);break;
   case 'replay':void pronounceCorrect();break;case 'next':advance();break;
   case 'pause':pauseRound();break;case 'resume':resumeRound();break;case 'exit':exitRound();break;
   case 'mistakes':start(true);break;case 'again':lastSummary=null;start(false);break;
   case 'settings':lastSummary=null;message='';show();break;
  }
 });
 document.addEventListener('keydown',e=>{if(typeof tab==='undefined'||tab!==ROUTE||e.altKey||e.ctrlKey||e.metaKey)return;
  const tag=String(e.target?.tagName||'').toLowerCase();if(['input','textarea','select'].includes(tag))return;
  if(session&&e.repeat&&(/^[1-4]$/.test(e.key)||e.code==='Space')){e.preventDefault();return;}
  if(session&&/^[1-4]$/.test(e.key)){e.preventDefault();answer(Number(e.key)-1);}
  if(session&&e.code==='Space'){e.preventDefault();session.paused?resumeRound():pauseRound();}
 });
 document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseRound(true);});
 // The original section registry is used by the app's nav(); no custom router or saved flags.
 S.renderers[ROUTE]=screen;if(!sections.some(x=>x[0]===ROUTE))sections.push([ROUTE,'Vocabulary Speed Review']);
 installVocabularyShortcut();if(typeof nav==='function')nav();scheduleShortcut();
 window.ICPT_SPEED_REVIEW=Object.freeze({version:'followup3-chapter-sources-20261117',audioVersion:'recreated-shared-private-router-v1',route:ROUTE,catalogue:()=>getCatalog(),eligible:()=>targetsFor(eligibleScope()),
  getStatus:()=>({screen:session?'question':lastSummary?'results':'setup',roundKind:session?.roundKind||null,phase:session?.phase||null,
    paused:!!session?.paused,index:session?.index||0,currentId:session?.question?.target?.id||null,roundLength:session?.queue.length||0,
    timeLimit:session?.timeLimit??null,answerCount:session?.answers.length||0,audioPending:!!session?.audioPending,audioResult:session?.audioResult||null,direction:session?.question?.direction||null,
    choices:(session?.question?.choices||[]).map(x=>({id:x.id,ar:x.ar,en:x.en})),
    records:(session?.answers||[]).map(x=>({...x})),lastSummary:lastSummary?{total:lastSummary.total,correct:lastSummary.correct,incorrect:lastSummary.incorrect,skipped:lastSummary.skipped,accuracy:lastSummary.accuracy,practiceXP:lastSummary.practiceXP,missedIds:lastSummary.missedIds.slice()}:null,
    config:{...configuration,units:[...configuration.units],chapters:[...configuration.chapters]}}),
  openSoundScript:(sourceRows,label)=>{
   const known=new Map((window.GH_SOUND_SCRIPT?.catalog?.()||[]).map(x=>[x.id,x]));
   if(state.active||!Array.isArray(sourceRows)||!sourceRows.length||new Set(sourceRows.map(x=>x.id)).size!==sourceRows.length||sourceRows.some(x=>!known.has(x.id)||known.get(x.id).ar!==x.ar||known.get(x.id).en!==x.en))return false;
   stopAudio();stopTick();session=null;lastSummary=null;configuration.bank='supplemental';configuration.supplementIds=sourceRows.map(x=>x.id);configuration.soundScriptScope=String(label||'Selected glossary pairs');configuration.autoPronounce=false;
   supplementalLaunchRows=sourceRows.map(x=>({...x,bank:'sound-script',canonicalId:x.id,sourceLabel:'Sound & Script · '+(x.lesson?'Lesson '+x.lesson:x.theme)+' · page '+x.printedPage}));catalog=null;goto();return true;
  },
  // Public controls support integration tests; only the separate practice category can award XP.
  start,choose:answer,skip:()=>answer(null),pause:()=>pauseRound(),resume:resumeRound,exit:exitRound,replay:pronounceCorrect,next:advance,
  repeat:()=>{lastSummary=null;return start(false);},mistakes:()=>start(true),tick,
  _test:{compatible,eligibleQuestion,targetsFor,shuffle,stripAr,cleanEn}});
 // Dedicated supplemental entry points share the established learning engine and saved IDs.
 function supplementalSelection(){
  const rows=(window.GH_SUPPLEMENTARY_VOCAB?.eligible?.(window.GH_SUPPLEMENTARY_VOCAB.rows()))||(typeof supplementRows==='function'?supplementRows():supplementalRows());
  return [...new Set(rows.filter(x=>x&&x.id).map(x=>String(x.id)))];
 }
 function launchSupplemental(kind){
  if(typeof state!=='undefined'&&state?.active)return false;
  const ids=supplementalSelection();
  if(kind==='learn'){
   const learning=window.GH_DASHBOARD_WORDS_R4;
   if(!learning?.open){if(typeof toast==='function')toast('The learning engine is not available. No progress was changed.');return false;}
   // Existing newEligible reads canonical saved history, omits learned/known words,
   // retains unfinished learning and launches the normal six-step trainer.
   return learning.open({purpose:'filtered',mode:'new',chapter:'all',scopeIds:ids,scopeRowsR8:(window.GH_SUPPLEMENTARY_VOCAB?.rows?.()||[]).filter(x=>ids.includes(String(x.id))),source:'all'});
  }
  delete configuration.soundScriptScope;configuration.bank='supplemental';configuration.supplementIds=ids;supplementalLaunchRows=(window.GH_SUPPLEMENTARY_VOCAB?.rows?.()||[]).filter(x=>ids.includes(String(x.id)));if(!supplementalLaunchRows.length)supplementalLaunchRows=null;catalog=null;
  if(session)exitRound();lastSummary=null;message='Supplemental Speed Review uses the current supplemental filters.';goto();return true;
 }
 function supplementalControls(html){
  if(typeof html!=='string'||html.includes('data-supp-review-controls'))return html;
  return `<section class="card" data-supp-review-controls><h2>Supplemental vocabulary practice</h2><div class="actions"><button type="button" data-supp-review="speed">Speed Review</button><button type="button" data-supp-review="learn">Learn New Words</button></div><p>Both use the current supplemental filters across all pages. Learn New Words excludes learned and self-reported known words, resumes unfinished learning, and saves through the existing six-step learning system. Speed Review is separate practice, not mastery credit.</p></section>`+html;
 }
 if(typeof renderSupplements==='function'){const prior=renderSupplements;renderSupplements=function(...args){return supplementalControls(prior.apply(this,args));};}
 if(typeof S.renderers.supplements==='function'){const prior=S.renderers.supplements;S.renderers.supplements=function(...args){return supplementalControls(prior.apply(this,args));};}
 document.addEventListener('click',e=>{const b=e.target?.closest?.('[data-supp-review]');if(!b||typeof tab==='undefined'||tab!=='supplements')return;e.preventDefault();launchSupplemental(b.dataset.suppReview);});
 window.GH_SUPPLEMENTAL_REVIEW_R2=Object.freeze({launch:launchSupplemental,selection: supplementalSelection,controls:supplementalControls});

})();
