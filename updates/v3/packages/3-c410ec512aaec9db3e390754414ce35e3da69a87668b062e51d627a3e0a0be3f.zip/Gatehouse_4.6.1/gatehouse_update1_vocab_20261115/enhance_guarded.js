(function(W){'use strict';
const rows=[['icpt101','ICPT 101','RC/LC','2026-11-18','12:45'],['icpt102','ICPT 102','RC/LC','2027-02-18','12:45'],['vlr','VLR','RC/LC','2027-04-01','07:45'],['icpt201-rc','ICPT 201','RC','2027-05-12','12:45'],['icpt201-lc','ICPT 201','LC','2027-05-13','12:45'],['icpt202-rc','ICPT 202','RC','2027-07-14','12:45'],['icpt202-lc','ICPT 202','LC','2027-07-15','12:45'],['icpt301-rc','ICPT 301','RC','2027-08-19','07:45'],['icpt301-lc','ICPT 301','LC','2027-08-20','07:45'],['icpt302-rc','ICPT 302','RC','2027-09-23','07:45'],['icpt302-lc','ICPT 302','LC','2027-09-24','07:45'],['dlpt-rc','DLPT','RC','2027-11-01','12:45'],['dlpt-lc','DLPT','LC','2027-11-02','12:45']].map(([id,label,skill,date,time])=>Object.freeze({id,label,skill,date,time}));
W.GH_CLASS_EXAMS46=Object.freeze({source:Object.freeze({dateColumn:'TEST DATE'}),rows:Object.freeze(rows)});
})(window);
(function(W){'use strict';
 const DAY=86400000, spans=Object.freeze({icpt101:[1,15],icpt102:[16,25]});
 function day(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))throw Error('Invalid calendar day');
 const n=Date.parse(s+'T12:00:00Z');if(!Number.isFinite(n)||new Date(n).toISOString().slice(0,10)!==s)throw Error('Invalid calendar day');return n;}
 const plus=(s,n)=>new Date(day(s)+n*DAY).toISOString().slice(0,10),cmp=(a,b)=>a<b?-1:a>b?1:0;
 function mode(profile){const m=profile?.v4?.calendarTarget46?.mode;return m==='preset'||m==='manual'?m:profile?.settings?.examDate==='2026-11-18'?'preset':'legacy';}
 function next(exams,today){
  day(today);
  if(exams?.source?.dateColumn!=='TEST DATE'||!Array.isArray(exams.rows))return null;
  return exams.rows.filter(r=>Object.prototype.hasOwnProperty.call(spans,r.id)&&day(r.date)>=day(today))
   .slice().sort((a,b)=>cmp(a.date,b.date)||cmp(a.id,b.id))[0]||null;
 }
 function target({profile,today,exams}){
  const selected=mode(profile),buffer=profile?.settings?.buffer;
  if(!Number.isInteger(buffer)||buffer<7||buffer>14)return {mode:selected,badBuffer:true};
  const x=selected==='preset'?next(exams,today):null;
  if(selected==='preset'&&!x)return {mode:selected,date:null};
  const d=x?.date||profile?.settings?.examDate;
  try{day(d);return {mode:selected,date:d,label:x?.label||null,time:x?.time||null,id:x?.id||null,cutoff:plus(d,-buffer-1),daysAway:(day(d)-day(today))/DAY};}
  catch{return {mode:selected,date:null};}
 }
 function allocate({profile,today,exams,weekly,weeklySnapshot,requiredRows,isSeen,studyDates,dueIds}){
  const t=target({profile,today,exams});
  const due=[...new Set(dueIds||[])];
  if(t.mode!=='preset'||!t.id)return {native:true,target:t,due};
  if(!Array.isArray(requiredRows)||typeof isSeen!=='function'||!Array.isArray(studyDates))return {native:false,target:t,due,missingScope:true,assigned:[]};
  const upcoming=weekly?.nextClass?.(weeklySnapshot,today);
  const rows=upcoming?.provisional===false?upcoming.rows.filter(r=>!r.noClass):[];
  // Chapter priority is not a claim a term occurs on an exact source page.
  const chapterPriority=new Set(rows.flatMap(r=>[...(r.chapters||[]),...(r.pageRanges||[]).map(p=>p.chapter)]));
  const exactPriority=new Set(rows.filter(r=>r.mappingVerified).flatMap(r=>r.wordIds||[]));
  const [lo,hi]=spans[t.id],unique=new Map();
  for(const r of requiredRows){
   if(r.required!==true||!Number.isInteger(r.chapter)||r.chapter<lo||r.chapter>hi||typeof r.canonicalId!=='string'||!r.canonicalId||isSeen(r.canonicalId))continue;
   const tier=exactPriority.has(r.id)||exactPriority.has(r.canonicalId)?0:chapterPriority.has(r.chapter)?1:2;
   const before=unique.get(r.canonicalId);
   if(!before||tier<before.tier||tier===before.tier&&r.chapter<before.chapter)unique.set(r.canonicalId,{id:r.canonicalId,tier,chapter:r.chapter});
  }
  const q=[...unique.values()].sort((a,b)=>a.tier-b.tier||a.chapter-b.chapter||cmp(a.id,b.id));
  const days=[...new Set(studyDates.map(d=>plus(d,0)))].filter(d=>d>=today&&d<=t.cutoff).sort();
  let pos=0;
  const assigned=days.map((d,i)=>{const take=Math.ceil((q.length-pos)/(days.length-i)),ids=q.slice(pos,pos+take).map(x=>x.id);pos+=take;return {day:d,ids};});
  return {native:false,target:t,due,assigned,unassigned:q.slice(pos).map(x=>x.id),nextClass:upcoming?.provisional===false?upcoming.date:null};
 }
 W.GH_CALENDAR_TARGET46=Object.freeze({mode,next,target,allocate});
})(typeof window==='object'?window:globalThis);



// Await durable profile writes. Never treat a Promise as a successful save.
const vocabSave47=(()=>{
 let tail=Promise.resolve(true),timer=null;
 const owner=()=>JSON.stringify([state._save45?.profileId,state._save45?.epoch]);
 const content=p=>{const x=JSON.parse(JSON.stringify(p));delete x.studyTime;delete x._save45;return JSON.stringify(x);};
 async function write(expectedOwner){
  if(owner()!==expectedOwner)return false;
  const P=window.GH_PROGRESS45;
  if(typeof P?.commitAsync!=='function')return save()===true;
  if(typeof P.readDurableAsync!=='function'||typeof P.markUncommitted!=='function')return false;
  try{
  if(P.getStatus?.()?.pending){await P.whenSettled();await Promise.resolve();if(owner()!==expectedOwner)return false;}
  const token=JSON.stringify(state),snapshot=JSON.parse(token),fingerprint=content(snapshot);
   const result=await P.commitAsync(snapshot,{source:'vocabulary-async-47'});
   if(!result?.ok||!result.state)throw Error(result?.error||'Save did not complete.');
   let receipt,durable,status;
   // A separate writer can begin after this commit releases its adapter lock.
   // Wait for confirmation reads only; never retry the submitted learning write.
   for(let readAttempt=0;readAttempt<3;readAttempt++){
    if(P.getStatus?.()?.pending){await P.whenSettled();await Promise.resolve();if(owner()!==expectedOwner)return false;}
    receipt=await P.readDurableAsync();durable=receipt.profile;status=P.getStatus?.();
    if(!status?.pending)break;
   }
   const validRevision=n=>Number.isSafeInteger(n)&&n>=0;
   if(JSON.stringify([durable?._save45?.profileId,durable?._save45?.epoch])!==expectedOwner||JSON.stringify([result.state._save45?.profileId,result.state._save45?.epoch])!==expectedOwner||content(durable)!==content(result.state)||![receipt.revision,result.revision,durable._save45?.revision,result.state._save45?.revision].every(validRevision)||receipt.revision<result.revision||durable._save45.revision<result.state._save45.revision||JSON.stringify(P.snapshot())!==JSON.stringify(durable)||status?.ok!==true||status.ready!==true||status.pending||status.readError||status.reloadRequired)throw Error('Saved profile readback did not match.');
   if(owner()!==expectedOwner)return false;
   if(content(state)!==fingerprint){P.markUncommitted('Newer open work remains pending. Export a backup before leaving.');return false;}
   // A clock-only change is not a failed vocabulary save. Preserve interval
   // evidence without replacing newer answers, and adopt verified metadata.
   const accepted=JSON.parse(JSON.stringify(durable));
   if(JSON.stringify(state.studyTime)!==JSON.stringify(snapshot.studyTime)){
    const merge=window.GH_ACTIVE_TIME_CORE?.merge;
    if(typeof merge!=='function')throw Error('Newer study time could not be merged safely.');
    accepted.studyTime=merge(accepted.studyTime,state.studyTime);
   }
   state=accepted;return true;
  }catch(error){if(owner()===expectedOwner){try{P.markUncommitted(error.message);}catch(_){}toast('Saving did not complete. Keep this page open and export a backup.');}return false;}
 }
 function flush(){clearTimeout(timer);const expected=owner(),view=typeof tab==='undefined'?null:tab,t=typeof trainer==='undefined'?null:trainer,i=t?.i;const check=async()=>{const ok=await write(expected);return ok&&(typeof tab==='undefined'||tab===view)&&(typeof trainer==='undefined'||trainer===t&&trainer?.i===i);};const task=tail.then(check,check);tail=task;return task;}
 function background(){clearTimeout(timer);timer=setTimeout(()=>{void flush();},400);}
 return {flush,background};
})();
window.GH_VOCAB_SAVE47=vocabSave47;
// Revision 3: explicit learning stages, objective skill trials and cooperative play.
const MODES={R:'Reading',L:'Listening',S:'Speaking',TE:'Arabic → English',TA:'English → Arabic',T:'Transcription'};
const oldRenderSettings=renderSettings,oldRenderProgress=renderProgress,oldRenderSpeaking=renderSpeaking,oldBind=bindSpecial;
state.settings.supplement=true;state.settings.memrise=true;
state.rpg??={nickname:'',xp:0,awards:{},skills:[],army:{},points:{},peers:[],unlocked:{}};
for(const k of ['awards','army','points','unlocked'])state.rpg[k]??={};for(const k of ['skills','peers'])state.rpg[k]??=[];
state.learning??={};state.checks??={};state.settings.keyBoost??={};state.settings.theme??='gate';
for(const bagName of ['cards','learning','checks']){const bag=state[bagName]||{};for(const [oldId,r]of Object.entries(bag)){const id=DATA.canonicalMap[oldId]||oldId;if(id!==oldId){if(!bag[id])bag[id]=r;else if(bagName==='cards'&&(r.lastDay||'')>(bag[id].lastDay||''))bag[id]=r;else if(bagName==='learning'&&r.learned&&!bag[id].learned)bag[id]=r;delete bag[oldId];}}state[bagName]=bag;}state.version='3.0';

let trainer=null,trial=null,trialFilter='all',gateSkill='TE',gameKind='',bankExpanded=null;
sections.splice(5,0,['army','Shadow Army'],['quests','Gates & team play']);
function vbutton(action,label,data='',cl=''){return `<button class="${cl}" data-v3="${action}" ${data}>${label}</button>`;}
function vf(unit){return unit==='all'?'all':String(unit);}
function matchesScope(x,scope){if(!scope||scope==='all')return true;const cs=members(x.id).map(r=>r.chapter).filter(Boolean);return String(scope).startsWith('u')?cs.some(c=>Math.ceil(c/5)===+scope.slice(1)):cs.includes(+scope);}
// Filters describe source rows, not every alias in a shared progress group.
// Keep canonical progress storage without silently changing the displayed chapter.
function matchesSourceScopeR2(x,scope){if(!scope||scope==='all')return true;const chapter=Number(x?.chapter);return Number.isInteger(chapter)&&chapter>0&&(String(scope).startsWith('u')?Math.ceil(chapter/5)===Number(String(scope).slice(1)):chapter===Number(scope));}
function scopeOptions(value='all'){return [['all','All Units 1–3'],['u1','Unit 1 · Ch 01–05'],['u2','Unit 2 · Ch 06–10'],['u3','Unit 3 · Ch 11–15'],...DATA.chapters.map(c=>[String(c.chapter),chLabel(c.chapter)+' · '+c.title])].map(([v,t])=>`<option value="${v}" ${value==v?'selected':''}>${esc(t)}</option>`).join('');}
render = function(){if(shadowActive46&&(!trial||!shadowCurrent46(shadowActive46.trial)))shadowStop46('Screen or trial changed');nav();clearInterval(examTick);if(state.active&&['vocab','supplements','recall','audio','speaking','settings','army','quests'].includes(tab)&&!markMockAssistedForExposure()){$('content').innerHTML=heading('Study content unavailable','Your active mock is preserved. Restore browser saving before opening study content.');return;}const f={today:renderToday,planner:renderPlanner,vocab:renderVocab,supplements:renderSupplements,recall:renderRecall,mocks:renderMocks,audio:renderAudio,speaking:renderSpeaking,progress:renderProgress,settings:renderSettings,army:renderArmy,quests:renderQuests};$('content').innerHTML=(f[tab]||renderToday)();document.body.dataset.theme=state.settings.theme;bindSpecial();if(tab==='mocks'&&state.active)startExamClock();}
function percent(a,b){return b?Math.max(0,Math.min(100,Math.round(100*a/b))):0;}
function progressBar(a,b){return `<div class="meter" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent(a,b)}"><i style="width:${percent(a,b)}%"></i></div>`;}
function pscore(x){return (x.priority?.score||0)+(+state.settings.keyBoost[canonicalId(x.id)]||0);}
function learningRec(id){return state.learning[canonicalId(id)]||{introduced:false,reps:0,learned:false};}
function hasIntroduced(id){return !!(rec(id).seen||learningRec(id).introduced);}
function checked(id){return !!state.checks[canonicalId(id)];}
function isOldAudit(x){return members(x.id).some(y=>y.bank==='core'&&y.chapter>0&&y.chapter<=10);}
function knownChapters(x){return [...new Set(members(x.id).map(r=>r.chapter).filter(Boolean))].sort((a,b)=>a-b);}
enabledRows = function(){return ITEMS;}
activeItems = function(){return Object.keys(DATA.groups).map(k=>byId[k]);}
planMap = function(){
 const t=effectiveDailyCalendar46(),m={},all=activeItems(),last=t.cutoff;if(!last||last<START)return m;
 function assign(xs,ds){if(!ds.length)return;xs.sort((a,b)=>pscore(b)-pscore(a)||a.id.localeCompare(b.id));xs.forEach((x,i)=>{const d=ds[Math.min(ds.length-1,Math.floor(i*ds.length/xs.length))];members(x.id).forEach(r=>m[r.id]=d);});}
 const oldEnd=last<'2026-10-30'?last:'2026-10-30';
 assign(all.filter(isOldAudit),dates(START,oldEnd));
 assign(all.filter(x=>!isOldAudit(x)&&earliestChapter(x)<=10),dates(START,last));
 assign(all.filter(x=>earliestChapter(x)>15),dates(START,last));
 for(let ch=11;ch<=15;ch++){
  const w=state.settings.release[ch]||DATA.plan.release[ch];let ds=dates(w[0],w[1]).filter(d=>![0,6].includes(new Date(d+'T12:00:00').getDay()));if(!ds.length)ds=dates(w[0],w[1]);
  assign(all.filter(x=>!isOldAudit(x)&&earliestChapter(x)===ch),ds);
 }
 return m;
}
function effectiveDailyCalendar46(){
 const provider=window.GH_CALENDAR_TARGET46;
 if(provider?.mode?.(state)!=='preset')return {preset:false,cutoff:cutoff()};
 const exams=window.GH_CLASS_EXAMS46;
 const target=provider?.target?.({profile:state,today:localDay(),exams});
 const range=target?.id==='icpt101'?[1,15]:target?.id==='icpt102'?[16,25]:null;
 return {preset:true,cutoff:range&&target.cutoff||null,exam:range&&target.date||null,range};
}
function effectiveDailyNotice46(){
 const t=effectiveDailyCalendar46();if(!t.preset)return '';
 const text=t.exam?'Confirmed exam '+t.exam+'; first pass through '+t.cutoff+'. New daily assignments prioritize the next scheduled class when available. Existing saved assignments and due reviews are preserved.':'No confirmed next exam: new daily assignments are on hold. Existing saved assignments and due reviews are preserved.';
 return '<p class="banner" role="status">'+esc(text)+'</p>';
}
function effectiveDailyScope46(x,range){return !!range&&members(x.id).some(y=>y.bank==='core'&&Number.isInteger(y.chapter)&&y.chapter>=range[0]&&y.chapter<=range[1]);}
function allowedDailyAdmission46(x,d,result){
 const t=effectiveDailyCalendar46();
 return result&&(!t.preset||!!t.cutoff&&d<=t.cutoff&&effectiveDailyScope46(x,t.range));
}
function allowedDate(x,d=day(),map=null){const date=(map||planMap())[x.id],last=effectiveDailyCalendar46().cutoff;return allowedDailyAdmission46(x,d,!!last&&!!date&&date<=d&&d<=last&&date<=last&&d>=START);}
eligibleNew = function(x,d=day(),map=null){return !hasIntroduced(x.id)&&!window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id)&&allowedDate(x,d,map);}
newItems = function(d=day()){const rows=activeItems(),map=planMap();return rows.filter(x=>eligibleNew(x,d,map));}
function checkQueue(d=day()){const rows=activeItems(),map=planMap();return rows.filter(x=>isOldAudit(x)&&!checked(x.id)&&!hasIntroduced(x.id)&&!window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id)&&allowedDate(x,d,map));}
function learnQueue(d=day()){const rows=activeItems(),map=planMap();return rows.filter(x=>{const l=learningRec(x.id);return allowedDate(x,d,map)&&!window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id)&&!l.learned&&!rec(x.id).seen&&(!isOldAudit(x)||checked(x.id));});}
function firstQueue(d=day()){return activeItems().filter(x=>{const l=learningRec(x.id),r=rec(x.id);return (l.learned||r.seen)&&!r.firstRetrieved&&((l.readyDate&&l.readyDate<=d)||(!l.readyDate&&r.seen&&r.firstDay&&r.firstDay<d));});}
dueItems = function(d=day()){return activeItems().filter(x=>{const r=rec(x.id);return r.firstRetrieved&&r.due&&r.due<=d;});}
function markIntro(x){if(learningRec(canonicalId(x.id)).introduced)return;const k=canonicalId(x.id),l=learningRec(k);l.introduced=true;l.introducedDate??=day();l.introducedAt??=Date.now();state.learning[k]=l;vocabSave47.background();}
async function learnComplete(x){const k=canonicalId(x.id),l=learningRec(k),r=rec(k);if(l.learned||r.seen)return await vocabSave47.flush();l.introduced=true;l.learned=true;l.learnedDate=day();l.learnedAt=Date.now();l.readyDate=addDays(day(),1);state.learning[k]=l;r.seen=true;r.firstDay??=day();r.firstRetrieved=false;r.due=l.readyDate;state.cards[k]=r;award('learn:'+k,4);return await vocabSave47.flush();}
function award(key,amount){if(state.settings.studyDate&&state.settings.studyDate!==localDay())return;const k=localDay()+':'+key;if(state.rpg.awards[k])return;state.rpg.awards[k]=amount;state.rpg.xp+=amount;}
function skillEvent(id,mode,correct,kind='automatic',assisted=false){
 const x=byId[id];if(!x)return;state.rpg.skills.push({id:canonicalId(id),mode,correct:!!correct,kind,assisted:!!assisted,date:localDay(),at:Date.now(),chapters:knownChapters(x),planning:day()!==localDay()});state.rpg.skills=state.rpg.skills.slice(-6000);
 if(correct&&!assisted)award('skill:'+canonicalId(id)+':'+mode,kind==='automatic'?8:3);vocabSave47.background();
}
function skillStats(mode,unit=0){const xs=state.rpg.skills.filter(e=>e.mode===mode&&!e.planning&&!e.assisted&&(unit===0||e.chapters.some(c=>Math.ceil(c/5)===unit))).slice(-40);return {n:xs.length,correct:xs.filter(e=>e.correct).length,p:xs.length?percent(xs.filter(e=>e.correct).length,xs.length):null,partner:xs.filter(e=>e.kind==='partner').length,self:xs.filter(e=>e.kind==='self').length};}
function masteryCount(unit=0){return Object.entries(state.rpg.army).filter(([id,r])=>{const x=byId[canonicalId(id)];return x&&r?.recruited&&(!unit||knownChapters(x).some(ch=>Math.ceil(ch/5)===unit));}).length;}
function rankInfo(){return [...DATA.rankRules].reverse().find(r=>state.rpg.xp>=r.xp)||DATA.rankRules[0];}
function bestRole(){const ss=DATA.roles.map(r=>({...r,...skillStats(r.id)})).filter(r=>r.n>=5);ss.sort((a,b)=>b.p-a.p||b.n-a.n);return ss[0]||null;}
function xpPanel(){const rank=rankInfo(),next=DATA.rankRules[DATA.rankRules.findIndex(r=>r.rank===rank.rank)+1],b=bestRole();return `<section class="card rankPanel"><div class="rankSeal">${rank.rank}</div><div class="grow"><div class="eyebrow">Training rank · not an ILR score</div><h2>${esc(state.rpg.nickname||'Your field journal')}</h2><p>${state.rpg.xp} XP · ${masteryCount()} recruited words · ${b?'Suggested role: '+b.name:'Role: Explorer — build five scored attempts in a skill'}</p>${progressBar(state.rpg.xp-rank.xp,next?next.xp-rank.xp:1)}<div class="mini">${next?`${next.xp-state.rpg.xp} XP to ${next.rank}`:'S rank reached'} · No lost XP, public error lists, or broken-streak penalties.</div></div></section>`;}
function wordList(xs,action='study',max=200){if(state.active)return '<p class="mini">Word details are hidden while a mock is in progress. Finish or discard it to review them.</p>';return `<div class="scroller">${xs.slice(0,max).map(x=>`<div class="dailyWord"><span class="ar inline" lang="ar">${esc(x.ling.head)}</span><span>${esc(x.meaningDisplay)}<br><small>${esc(groupSummary(x))}</small></span>${vbutton(action,'Open',`data-id="${x.id}"`,'small')}</div>`).join('')||'<p class="mini">Nothing assigned in this stage.</p>'}</div>`;}
renderToday = function(){
 const p=planMap(),all=activeItems(),scheduled=(window.ICPT_SYSTEM?window.ICPT_SYSTEM.sortLearning(all.filter(x=>p[x.id]===day())):all.filter(x=>p[x.id]===day())),checks=checkQueue(),learn=learnQueue(),first=firstQueue(),due=dueItems(),tt=taskOn(day()),c=constraints(),introduced=all.filter(x=>hasIntroduced(x.id)).length;
 const backlogEstimate=Math.ceil(checks.length*.25+learn.length*1.5+first.length*.4+due.length*.25),workload=window.ICPT_STAGE2?.workload?.(day()),minutes=workload?.totalMinutes??backlogEstimate;
 return effectiveDailyNotice46()+heading('Learn it. Retrieve it. Make it yours.',effectiveDailyCalendar46().preset?'Review your current saved assignment or due words.':'November 18 ICPT 101 · vocabulary across all three sources, with a protected review period.',`<a class="buttonlink" href="Gatehouse_4_6_Player_Guide_F33_DRAFT.html" target="_blank">4.6 Player Guide</a>`)+xpPanel()+
 (c.length?`<div class="banner error"><b>Scheduling conflict:</b> ${c.map(esc).join(' ')} Unseen vocabulary stays locked during the buffer; update the teaching dates rather than pretending coverage is complete.</div>`:'')+
 (reviewOnly()?`<div class="banner"><b>Review-only period.</b> No new learning. ${all.length-introduced} unseen groups remain visible as a backlog. First retrieval of an already-learned word is review, not new vocabulary.</div>`:'')+
 `<div class="stats">${stat('Familiarity checks',checks.length,'Previously taught core only; not a first retrieval')}${stat('New-word learning',learn.length,'Read/listen, meaning, two guided rehearsals')}${stat('First delayed retrieval',first.length,'No earlier than the day after learning')}${stat('Spaced reviews',due.length,'Due after prior retrieval; +1 / +3 / +7 / +14')}</div>
 <div class="grid"><section class="card"><div class="eyebrow">${fmt(day())}</div><h2>Today’s four-stage route</h2><p>${esc(tt[1])}</p><div class="actions">${vbutton('start-check','1 · Check familiar words',`data-kind="check"`,'primary')}${vbutton('start-learn','2 · Learn new words','','primary')}${vbutton('start-first','3 · First retrieval')}${vbutton('start-due','4 · Spaced review')}</div><p class="mini">${window.ICPT_STAGE2?"These stage buttons open today’s saved finite assignment. Eligible carry-over and legacy calendar allocations remain visible below; they are not all required today.":"Eligible queues include carry-over."} A check is a familiarity audit, two same-day rehearsals are learning, and next-day retrieval is a separate event. A failed check joins learning without lowering a score.</p><details class="spacer"><summary>Legacy calendar allocation for this date · ${scheduled.length} groups</summary>${wordList(scheduled)}</details><details><summary>Backlog / not yet introduced</summary>${wordList(all.filter(x=>!hasIntroduced(x.id)&&p[x.id]&&p[x.id]<day()),'study')}</details><div class="actions spacer"><button data-action="tab" data-tab="mocks">Separate R / L mocks</button><button data-action="speak-open" data-id="${tt[2]||'speak-01'}">Six sentences + surprise</button></div></section>
 <section class="card"><h2>Small blocks, visible progress</h2><p class="dailyAssignmentEstimate46">${workload?`<b>${minutes} estimated minutes for today’s assignment</b>: ${Math.ceil(workload.assignedMinutes)} for assigned cards, ${workload.comprehensionMinutes} for comprehension and ${workload.speakingMinutes} for speaking. About ${workload.remainingTotalMinutes} minutes remain. These estimates are provisional; the ${workload.budgetMinutes}-minute preference does not cap the deadline vocabulary quota.`:`<b>${minutes} estimated minutes in all eligible card queues</b>, before comprehension and speaking. The finite daily assignment is still loading.`}</p><p class="dailyBacklogEstimate46">${workload?`All eligible card backlog: about ${Math.ceil(workload.backlogMinutes)} minutes, including today’s assigned cards.`:'Unfinished eligible cards remain visible.'} Use 10–15-minute blocks; uncompleted work stays visible and is never marked learned automatically.</p><p>${introduced} / ${all.length} unique study groups introduced. All <b>125 Quizlet rows</b> and <b>267 Memrise rows</b> are included; matching sources share one schedule.</p><div class="banner">${checks.length+learn.length>80?'Large eligible backlog. In new learning, finish next-class textbook targets before supplements; keep due reviews separate. A 7–14-day buffer is editable. Do not mark unknown words learned just to reduce the queue.':'New learning starts with the next class’s textbook targets, then textbook catch-up, then supplements. Spaced reviews remain a separate queue.'}</div><h3>Comprehension first</h3><p>For practice audio, first identify the topic without text. Next listen for the requested details. Reveal the translation only during correction. In a timed mock, follow the simulated test instructions.</p><p class="mini">Use 70–80% comprehension as your own training comfort target, not as a proven vocabulary-coverage threshold. Note what you understood, not just what you missed.</p>${vbutton('open-gates','Open team gates')}${vbutton('open-army','Shadow Army trial')}</section></div>`;
}
renderPlanner = function(){const p=planMap(),all=activeItems();return effectiveDailyNotice46()+heading('A day-by-day plan that separates learning from recall.',effectiveDailyCalendar46().preset?'The table below shows the legacy calendar allocation, not a new saved assignment.':'All three banks are included. Teaching dates after the supplied Week 13 timetable remain provisional.',`<button data-action="print">Print plan</button>`)+`<div class="banner"><b>${effectiveDailyCalendar46().preset?'Legacy calendar cutoff':'New-learning cutoff'} ${fmt(cutoff())}.</b> Review only ${fmt(addDays(cutoff(),1))}–Nov 17. First delayed retrieval of the last learned words falls in review week. All later repeated encounters are review, not added vocabulary.</div>
 <section class="card"><h2>Class-release windows</h2><div class="tablewrap"><table><thead><tr><th>Chapter</th><th>Learn window</th><th>Basis</th></tr></thead><tbody>${[11,12,13,14,15].map(ch=>{const w=state.settings.release[ch];return `<tr><td>${chLabel(ch)}</td><td>${fmt(w[0],true)}–${fmt(w[1],true)}</td><td>${esc(w[2]||DATA.plan.release[ch][2])}</td></tr>`}).join('')}</tbody></table></div><button data-action="tab" data-tab="settings">Edit chapter dates / buffer</button><p class="mini">The confirmed schedule begins Chapter 11 on Oct 21 and Chapter 12 on Oct 23. Learning windows follow classroom order; a late end date raises a conflict instead of overriding the buffer.</p></section>
 <section class="card"><h2>Daily allocation</h2><p class="mini">“First retrieval” below is a projected next-day count assuming the prior day’s learning/checks are completed. The Today page uses actual completion. Due reviews depend on actual ratings.</p><div class="tablewrap"><table><thead><tr><th>Date</th><th>Familiarity checks</th><th>New learning</th><th>Projected first retrieval</th><th>Comprehension / speaking</th><th>Exact words</th></tr></thead><tbody>${dates(START,EXAM).map(d=>{const xs=window.ICPT_SYSTEM?window.ICPT_SYSTEM.sortLearning(all.filter(x=>p[x.id]===d),d):all.filter(x=>p[x.id]===d),o=xs.filter(isOldAudit),n=xs.filter(x=>!isOldAudit(x)),prev=all.filter(x=>p[x.id]===addDays(d,-1)),t=taskOn(d);return `<tr class="${d>cutoff()?'reviewrow':''}"><td><b>${fmt(d,true)}</b><br>${d>cutoff()?'Review only':''}</td><td>${d<=cutoff()?o.length:0}<br><small>~${Math.ceil(o.length*.25)} min</small></td><td>${d<=cutoff()?n.length:0}<br><small>~${Math.ceil(n.length*1.5)} min + failed checks</small></td><td>${prev.length}<br><small>Actual queue adapts</small></td><td>${esc(t[1])}<br><small>${t[2]?'Speaking '+chLabel(+t[2].slice(-2)):''}</small></td><td><details><summary>${xs.length} groups</summary>${wordList(xs)}</details><button class="small" data-action="setday" data-date="${d}">Inspect day</button></td></tr>`}).join('')}</tbody></table></div></section>`;}
function formPanel(x){const l=x.ling;return `<details class="formPanel"><summary>Pronunciation, word forms, root & context</summary><div class="banner mini"><b>Written model, not audio certification.</b> ${esc(l.pronunciationStatus)}</div><p class="mini">${l.root?'Root '+esc(l.root)+' · ':''}${l.measure?'Measure '+esc(l.measure)+' · ':''}${esc(l.pos)}. ${esc(x.studyWarning||'Gender and plural forms are shown only where applicable; forms are not invented for invariable expressions.')}</p><div class="formGrid">${l.forms.map((f,i)=>`<div><span class="mini">${esc(f.label)}</span><div class="ar" lang="ar">${esc(f.ar)}</div>${vbutton('say-form','Pronunciation status',`data-id="${x.id}" data-index="${i}"`,'small')}</div>`).join('')}</div><p class="mini">${esc(l.pluralNote)} ${esc(l.feminineNote)}</p>${x.studyNote?`<div class="note"><b>Tutor correction:</b> ${esc(x.studyNote)}</div>`:''}${x.context?`<h4>Use in context · ${esc(x.context.kind)}</h4><div class="ar" lang="ar">${esc(x.context.ar)}</div><p>${esc(x.context.en)}</p><p class="mini">${esc(x.context.source)}</p>`:`<p class="mini">Sentence exercise: use this word in a sentence about ${esc(chTitle(x.chapter)||'your day')}. Compare with a teacher; no automatically invented source sentence is supplied.</p>`}<div class="actions"><a href="${esc(x.dictionaryURL)}" target="_blank" rel="noopener">Independent dictionary lookup</a>${x.bank==='memrise'?`<a href="${esc(x.sourceURL)}" target="_blank" rel="noopener">Memrise original (sign-in may be required)</a>`:''}</div></details>`;}
filteredVocab = function(){let xs=ITEMS.filter(x=>vocabFilter.scope==='all'||(vocabFilter.scope==='core'?x.bank==='core':vocabFilter.scope==='memrise'?x.bank==='memrise':x.bank==='quizlet'));xs=xs.filter(x=>matchesSourceScopeR2(x,vocabFilter.chapter));if(vocabFilter.search){const q=normalize(vocabFilter.search);xs=xs.filter(x=>normalize([x.ar,x.en,x.ling?.root,x.category,x.meaningDisplay,x.originalAr,x.originalEn,x.sourceRow?.arabic,x.sourceRow?.english].join(' ')).includes(q));}if(vocabFilter.status==='unseen')xs=xs.filter(x=>!hasIntroduced(x.id)&&!window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id));if(vocabFilter.status==='known')xs=xs.filter(x=>window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id));if(vocabFilter.status==='needs-practice')xs=xs.filter(x=>!window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id));if(vocabFilter.status==='due')xs=xs.filter(x=>rec(x.id).due&&rec(x.id).due<=day());if(vocabFilter.status==='stable')xs=xs.filter(x=>stable(rec(x.id)));if(vocabFilter.status==='army')xs=xs.filter(x=>state.rpg.army[canonicalId(x.id)]?.recruited);return xs;}
// Display-only grouping follows existing reviewed identity; never compare spelling or gloss.
function vocabBrowseGroups46(rows){const groups=new Map();for(const x of rows){const key=canonicalId(x.id);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(x);}return groups;}
function vocabBrowseSource46(x){return (x.semester===3?'Semester III'+(x.lesson?' · Lesson '+x.lesson:''):x.chapter?chLabel(x.chapter):x.category||'Source')+' · '+(x._priority2View?'Memrise supplement':rowBank(x));}
function vocabBrowseEvidence46(x){const rows=members(x.id);if(rows.length<=1)return '';return '<details class="sourceVariants"><summary>All source wordings · '+rows.length+'</summary>'+rows.map(y=>'<div class="variant" data-source-id="'+esc(y.id)+'"><p class="mini">'+esc(vocabBrowseSource46(y))+'</p><div class="ar" lang="ar">'+esc(y.ar)+'</div><p>'+esc(y.en)+'</p>'+(y.note?'<p class="note">'+esc(y.note)+'</p>':'')+(y.studyMeaning&&y.studyMeaning!==y.en?'<p>Study meaning: '+esc(y.studyMeaning)+'</p>':'')+sourceDetail(y)+'</div>').join('')+'</details>';}
vocabRows = function(xs,grouped=false,browseGroups=null){return `<div class="tablewrap"><table><thead><tr><th>Chapter / source</th><th>As supplied</th><th>Study meaning & forms</th><th>Status / priority</th></tr></thead><tbody>${xs.map(x=>{const r=rec(x.id),l=learningRec(x.id),date=planMap()[x.id];return `<tr data-r2-word="${esc(x.id)}"${grouped?` data-supplement-group="${esc(canonicalId(x.id))}"`:""}><td>${browseGroups?(browseGroups.get(canonicalId(x.id))||[x]).map(y=>`<div class="vocabMatchedSource" data-matched-source-id="${esc(y.sourceMembershipId||y.id)}">${esc(vocabBrowseSource46(y))}<br>${sourceDetail(y)}</div>`).join(''):`${esc(groupSummary(x))}<br>${sourceDetail(x)}`}</td><td><div class="ar" lang="ar">${esc(x.ar)}</div>${vbutton('say-model','Pronunciation status',`data-id="${x.id}"`,'small')}<div class="mini">${esc(x.ling.head)}</div></td><td><span data-r2-visible-definition>${esc(x.meaningDisplay)}</span>${x.studyMeaning!==x.en?`<details><summary class="mini">Original English wording</summary>${esc(x.en)}</details>`:''}${x.note?`<details><summary class="mini">Source annotation</summary><p>${esc(x.note)}</p></details>`:''}${formPanel(x)}${grouped?supplementEvidence46(x):browseGroups?vocabBrowseEvidence46(x):groupDetails(x)}</td><td>${badge(state.rpg.army[canonicalId(x.id)]?.recruited?'Shadow Army':r.firstRetrieved?'Retrieval started':l.learned?'First retrieval pending':hasIntroduced(x.id)?'Learning':checked(x.id)?'Checked · learn next':'Not checked','blue')}<p class="mini">${date?'Scheduled '+fmt(date,true):'Schedule conflict'}<br>Priority ${pscore(x)}${x.key?' · Key 60':''}</p><details><summary class="mini">Why this priority?</summary>${esc(x.priority.reasons.join('; '))}<label class="mini">Teacher emphasis (0–5)<input class="teacherBoost" data-id="${canonicalId(x.id)}" type="number" min="0" max="5" value="${state.settings.keyBoost[canonicalId(x.id)]||0}"></label></details>${vbutton('study','Study',`data-id="${x.id}"`,'small')}${window.GH_REVIEW_WORKFLOW_R2?.controlsHTML(x.id,'row')||''}</td></tr>`}).join('')}</tbody></table></div>`;}
renderVocab = function(){const rows=filteredVocab(),browseGroups=vocabBrowseGroups46(rows),xs=[...browseGroups.values()].map(group=>group[0]),size=20,n=Math.max(1,Math.ceil(xs.length/size));vocabFilter.page=Math.min(vocabFilter.page,n-1);return heading('Source forms stay visible. Duplicate work does not.','Every source row is retained; matching meanings share a learning record. Search by topic, Arabic form, English, or known root.')+`<div class="toolbar"><label>Unit / chapter<select id="vocabChapter">${scopeOptions(vocabFilter.chapter)}</select></label><label>Source<select id="vocabScope">${[['all','All three banks'],['core','Primary DLI'],['memrise','Memrise supplement'],['supp','Quizlet · all 125']].map(([v,t])=>`<option value="${v}" ${vocabFilter.scope===v?'selected':''}>${t}</option>`).join('')}</select></label><label>Status<select id="vocabStatus">${[['all','All'],['unseen','Not introduced'],['known','Self-reported known'],['needs-practice','Not marked known'],['due','Due'],['stable','Spaced recall'],['army','In Shadow Army']].map(([v,t])=>`<option value="${v}" ${vocabFilter.status===v?'selected':''}>${t}</option>`).join('')}</select></label><label class="grow">Search<input id="vocabSearch" type="search" value="${esc(vocabFilter.search)}" placeholder="Arabic · meaning · topic · root"></label></div><div class="actions"><span class="mini">${rows.length} source rows · ${xs.length} study groups · ${vocabFilter.page+1}/${n}</span><button data-action="vocab-prev" ${!vocabFilter.page?'disabled':''}>Previous</button><button data-action="vocab-next" ${vocabFilter.page>=n-1?'disabled':''}>Next</button><button data-action="study-filter">Study filtered set</button></div><section class="card spacer">${vocabRows(xs.slice(vocabFilter.page*size,(vocabFilter.page+1)*size),false,browseGroups)}</section>`;}
supplementRows = function(){let xs=DATA.memrise.filter(x=>matchesScope(x,supplementFilter.chapter));if(supplementFilter.focus==='key')xs=xs.filter(x=>x.key);if(supplementFilter.focus==='overlap')xs=xs.filter(x=>members(x.id).some(y=>y.bank==='quizlet'));if(supplementFilter.focus==='flagged')xs=xs.filter(x=>x.needsCheck||x.studyNote);if(supplementFilter.search)xs=xs.filter(x=>normalize(x.ar+' '+x.en+' '+x.ling.root).includes(normalize(supplementFilter.search)));return xs.sort((a,b)=>pscore(b)-pscore(a)||a.chapter-b.chapter);}
// The existing canonical map defines identity. Display grouping never compares Arabic surfaces.
function supplementGroups46(rows){return [...new Map(rows.map(x=>[canonicalId(x.id),x])).values()];}
function supplementEvidence46(x){
 const id=canonicalId(x.id),rows=members(id),mem=rows.filter(y=>y.bank==='memrise');
 return `<details class="sourceVariants supplementOccurrences46"><summary>All source occurrences · ${mem.length} Memrise / ${rows.length} total</summary><p class="mini">One existing study group. Every source ID, supplied wording and sense remains available; similar spellings with different meanings keep their own groups.</p>${rows.map(y=>`<div class="variant" data-source-id="${esc(y.id)}"><p class="mini"><b>${esc(y.id)}</b> · ${esc(rowBank(y))} · ${y.chapter?chLabel(y.chapter):'Unassigned'}</p><div class="ar" lang="ar">${esc(y.ar)}</div><p>${esc(y.en)}</p>${y.studyMeaning&&y.studyMeaning!==y.en?`<p>Study meaning: ${esc(y.studyMeaning)}</p>`:''}${y.note?`<p class="note">Source annotation: ${esc(y.note)}</p>`:''}${y.studyNote?`<p class="note">Tutor annotation: ${esc(y.studyNote)}</p>`:''}${sourceDetail(y)}</div>`).join('')}</details><details class="supplementHistory46"><summary>Shared learning and retrieval history</summary><p class="mini">Existing study group ID: ${esc(id)}. This view does not change saved records.</p><pre class="note" style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(JSON.stringify({retrieval:rec(id),learning:state.learning[id]||null,check:state.checks[id]||null,army:state.rpg.army[id]||null},null,2))}</pre></details>`;
}
renderSupplements = function(){const rows=supplementRows(),xs=supplementGroups46(rows),total=supplementGroups46(DATA.memrise).length,sz=20,n=Math.max(1,Math.ceil(xs.length/sz));supplementFilter.page=Math.min(supplementFilter.page,n-1);return heading('All supplemental vocabulary. One optional Key filter.',`${DATA.memrise.length} supplied Memrise source entries appear as ${total} existing study groups. Expand a group for every source ID, wording and saved history. Key 60 changes the view, not the curriculum.`)+`<section class="card"><h2>How the list is selected</h2><div class="priorityFormula">3 × primary overlap + 3 × Quizlet overlap + up to 4 chapter breadth + 6 comprehension function + 2 everyday transfer</div><p>Primary/Quizlet overlap is binary. Chapter breadth counts distinct chapters with a matching surface form in extractable non-glossary text. The last two factors are tutor judgments about connectors, conditions, times, quantities, directions, transactions, announcements and factual reporting.</p><p class="mini">This is not a validated frequency corpus or a forecast of ICPT/DLPT questions. Inflections, image-only passages and untranscribed recordings are not exhaustively counted. No audio-frequency score is invented. Teacher emphasis can add 0–5 points on a card.</p><div class="actions"><a href="Key_Vocabulary.html" target="_blank">Open ranked Key 60 reference</a><a href="sources/Key_Memrise_Priorities.json" download>Download evidence table</a></div></section><div class="toolbar"><label>Unit / chapter<select id="suppChapter">${scopeOptions(supplementFilter.chapter)}</select></label><label>View<select id="suppFocus">${[['all',`All supplemental words (${total} groups / ${DATA.memrise.length} source entries)`],['key','Key vocabulary only · 60 groups'],['overlap','Also in Quizlet'],['flagged','Source annotations']].map(([v,t])=>`<option value="${v}" ${supplementFilter.focus===v?'selected':''}>${t}</option>`).join('')}</select></label><label class="grow">Search<input id="suppSearch" type="search" value="${esc(supplementFilter.search)}"></label><button data-action="study-supp">Study selection</button></div><div class="actions"><span class="supplementCounts46">${xs.length} study groups · ${rows.length} matching source rows · page ${supplementFilter.page+1}/${n}</span><button data-action="supp-prev" ${!supplementFilter.page?'disabled':''}>Previous</button><button data-action="supp-next" ${supplementFilter.page>=n-1?'disabled':''}>Next</button></div><section class="card spacer">${vocabRows(xs.slice(supplementFilter.page*sz,(supplementFilter.page+1)*sz),true)}</section>`;}

startSession = function(kind,ids=null){
 const explicit=Array.isArray(ids),requested=explicit?[...new Set(ids.filter(i=>typeof i==='string'))]:null;
 session=null;stopSpeech();let pool=explicit?requested.map(i=>byId[i]).filter(Boolean):kind==='check'?checkQueue():kind==='learn'||kind==='new'?learnQueue():kind==='first'?firstQueue():kind==='sweep'?activeItems().filter(x=>hasIntroduced(x.id)):dueItems();
 // Explicit study scopes retain every requested source ID. Progress may still
 // be canonical, but a shared progress group is not proof of identical forms,
 // senses, source pages or recordings. Daily queues keep their legacy grouping.
 if(!explicit)pool=[...new Map(pool.map(x=>[canonicalId(x.id),x])).values()];
 pool=pool.filter(x=>hasIntroduced(x.id)||window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id)||allowedDate(x)||window.GH_REVIEW_WORKFLOW_R2?.selectionPermit(x.id));
 if(['check','learn','new','chapter-new'].includes(kind))pool=pool.filter(x=>!window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id));
 if(!pool.length){toast('No eligible words in this exact selection. Check the class date or protected review cutoff; no full-queue fallback was started.');return false;}
 if(!explicit)pool=window.ICPT_SYSTEM&&['check','learn','new','selection'].includes(kind)?window.ICPT_SYSTEM.sortLearning(pool):pool.sort((a,b)=>pscore(b)-pscore(a));
 const chosen=pool.slice(0,15).map(x=>x.id);
 trainer={kind,queue:chosen,i:0,phase:kind==='chapter-review'?'rehearse':'prompt',input:'',rehearsal:{},mode:'TE',played:false,revealed:false,responseOwner5:JSON.stringify([state._save45?.profileId||'',state._save45?.epoch||'']),...(explicit?{selectionR2:{requestedIds:requested,selectedIds:[...chosen],allIds:pool.map(x=>x.id),blockOffset:0,nextOffset:chosen.length,filterSnapshot:typeof vocabFilter==='object'?{...vocabFilter}:null,...(window.GH_REVIEW_WORKFLOW_R2?.pendingScope?.()||{})}}:{})};tab='recall';if(!window.GH_REVIEW_WORKFLOW_R2?.pendingScope?.())window.GH457_AUDIO_QUEUE?.setStudySet?.(pool.map(x=>x.id),{source:'vocabulary',owner:trainer.responseOwner5,mode:kind});render();return [...chosen];
}
function studySourceLabel452(x){
 if(x?._semester3Mastery){const lesson=x.lesson;return 'Semester III'+(lesson!==undefined&&lesson!==null&&String(lesson).trim()?' · Lesson '+String(lesson):'');}
 const chapter=Number(earliestChapter(x));
 if(Number.isInteger(chapter)&&chapter>0)return (x?.bank==='memrise'?'Memrise supplement · ':'')+chLabel(chapter);
 if(x?.bank==='memrise')return 'Memrise supplement';
 if(x?.bank==='supp'||x?.bank==='quizlet')return 'Quizlet supplement';
 return 'Vocabulary practice';
}
function modeForItem(x){if(trainer.kind==='chapter-review')return 'rehearsal';if(['check','learn','new','chapter-new','selection','sweep'].includes(trainer.kind)&&window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id))return 'rehearsal';if(trainer.kind==='selection'||trainer.kind==='sweep'){if(!hasIntroduced(x.id))return isOldAudit(x)&&!checked(x.id)?'check':'learn';const l=learningRec(x.id),r=rec(x.id);return r.firstRetrieved?'due':(l.readyDate?l.readyDate<=day():r.seen&&r.firstDay<day())?'first':(l.learned||r.seen)?'rehearsal':'learn';}return ['new','chapter-new'].includes(trainer.kind)?'learn':trainer.kind;}
renderRecall = function(){
 if(!trainer)return heading('Different stages, different evidence.','Knowing a flashcard looks familiar is not the same as remembering it tomorrow.')+`<section class="card"><div class="actions">${vbutton('start-check','Familiarity check · '+checkQueue().length)}${vbutton('start-learn','New learning · '+learnQueue().length,'','primary')}${vbutton('start-first','First retrieval · '+firstQueue().length)}${vbutton('start-due','Spaced review · '+dueItems().length)}</div><p class="mini">Each block contains up to 15 study groups. A failed old-word check creates learning work. Two successful guided rehearsals complete a learning block; first delayed retrieval is scheduled for the next day.</p></section>`;
 if(trainer.i>=trainer.queue.length)return heading('Block complete in this open page.',window.GH_PROGRESS45?.getStatus?.()?.ok===true?'Check the save status before leaving. There is no penalty for taking a break.':'Saving could not be verified. This block has advanced in memory. Keep this page open and use Save & recovery to retry or export before leaving.')+`<section class="card"><h2>Return when ready.</h2><p>The calendar now reflects completed learning and real delayed-retrieval eligibility.</p>${vbutton('end-trainer','Return to today','','primary')}${vbutton('start-due','Another review block')}</section>`;
 const x=byId[trainer.queue[trainer.i]],k=modeForItem(x),l=learningRec(x.id),r=rec(x.id),learn=k==='learn'||k==='rehearsal',check=k==='check';
 if(k==='learn'&&!l.introduced&&!window.GH_REVIEW_WORKFLOW_R2?.isKnown(x.id))markIntro(x);
 const show=(learn&&trainer.phase==='prompt')||trainer.revealed,unavailable=['L','T'].includes(trainer.mode)&&!assessmentAudioAvailable46();
 return heading(check?'Familiarity check':k==='rehearsal'?(trainer.kind==='chapter-review'?'Optional meaning practice':'Extra practice · first retrieval remains tomorrow'):learn?'New-word learning':k==='first'?'First delayed retrieval':'Spaced retrieval',`${esc(studySourceLabel452(x))} · ${trainer.i+1}/${trainer.queue.length} · ${esc(groupSummary(x))}`)+`<section class="card flash"><div class="tagrow">${badge(check?'Audit only':trainer.kind==='chapter-review'?'Optional practice · no demonstrated mastery':learn?'Guided learning':'Retrieve without the answer')}${badge('No score penalty','grey')}</div>
 <div class="flashface">${trainer.mode==='L'&&!show?'<h2>Listen first.</h2>':`<div class="ar big" lang="ar">${esc(x.ling.head)}</div>`}${vbutton('train-play',unavailable?'Reviewed audio unavailable':assessmentAudioAvailable46()?'Hear reviewed Arabic':'Pronunciation status',unavailable?'disabled':'','small')}${unavailable?'<p class="banner">Reviewed Arabic audio is unavailable for this retrieval. Switch to reading to continue; no answer was graded.</p>':''}${show?`<h2 data-r2-visible-definition>${esc(x.meaningDisplay)}</h2><div class="mini">As supplied: <span lang="ar">${esc(x.ar)}</span></div>${formPanel(x)}`:''}</div>
 ${learn&&trainer.phase==='prompt'?`<p>Listen, read the meaning, say it once, and notice the form. Then hide the answer and rehearse. Successful rehearsal ${l.reps||0}/2.</p>${vbutton('learn-hide','Hide meaning & rehearse','','primary')}`:
 `<label class="answerLabel">Type the English meaning before checking<textarea id="learnInput" rows="2" autocomplete="off" spellcheck="false" ${trainer.revealed?'readonly':''}>${esc(trainer.input||'')}</textarea></label>${!trainer.revealed?vbutton('train-check','Check my answer',unavailable?'disabled':'','primary'):''}${trainer.revealed?`<div class="banner ${trainer.auto?'':'warn'}">${trainer.auto?'Your wording matches an accepted study gloss.':'Compare your wording with the model. An unmatched synonym is not automatically wrong.'}</div>${check?`<p class="mini">This check only decides whether guided learning is needed; it does not certify retention.</p>${vbutton('audit-known','I knew it independently')}${vbutton('audit-new','Needs learning','','primary')}`:learn?`${vbutton('learn-pass','Rehearsed successfully','','primary')}${vbutton('learn-again','Study again')}`:`<p class="mini">Ordinary ratings are self-assessed. Objective Shadow Army trials are separate.</p>${vbutton('retrieve-rate','Again',`data-rating="again"`)}${vbutton('retrieve-rate','Hard',`data-rating="hard"`)}${vbutton('retrieve-rate','Good',`data-rating="good"`,'primary')}`}`:''}`}
 <div class="actions spacer">${vbutton('end-trainer','Pause block')}${!learn&&!check?vbutton('train-toggle',trainer.mode==='L'?'Switch to reading':'Switch to listening'):''}</div><p class="mini">Original DLI recordings are in the Audio tab. Word pronunciation requires a reviewed source recording; unavailable playback does not count as listening evidence.</p></section>`;
}
function englishNorm(s){return String(s).normalize('NFKC').toLowerCase().replace(/\(s\)/g,'s').replace(/[’']/g,'').replace(/[^a-z0-9 ]/g,' ').replace(/\b(?:a|an|the|to|he|she|it|i|is|are|was|be)\b/g,' ').replace(/\s+/g,' ').trim();}
function glosses(x){const src=members(x.id).map(r=>r.studyMeaning);const vals=[];for(let t of src){t=t.replace(/\([^)]*\)/g,'').replace(/\b(?:VN|noun|adjective|verb|adverb)\b/gi,'');for(const s of t.split(/[\/;,]|\bor\b/)){const n=englishNorm(s);if(n.length>=2)vals.push(n,n.endsWith('s')?n.slice(0,-1):n);}}return [...new Set(vals)];}
function meaningOK(text,x){const n=englishNorm(text);return n.length>1&&glosses(x).includes(n);}
function spellingNorm(s){return String(s).normalize('NFKC').replace(/[\u064b-\u065f\u0670\u0640]/g,'').replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,'').replace(/[.,،؛؟?!]/g,'').replace(/\s+/g,' ').trim();}
function nextTrainer(){trainer.i++;trainer.phase=trainer.kind==='chapter-review'?'rehearse':'prompt';trainer.revealed=false;trainer.input='';trainer.played=false;render();}
let pendingRetrieval47=null;
async function updateRetrieval(x,rating){const owner=JSON.stringify([state._save45?.profileId,state._save45?.epoch]);if(pendingRetrieval47&&(pendingRetrieval47.target!==trainer||pendingRetrieval47.owner!==owner))pendingRetrieval47=null;if(pendingRetrieval47){const p=pendingRetrieval47;if(p.id!==x.id)return false;if(!(await vocabSave47.flush()))return false;pendingRetrieval47=null;nextTrainer();return true;}if(['L','T'].includes(trainer?.mode)&&!assessmentAudioAvailable46()){audioUnavailable46();return false;}let r=rec(x.id);const d=day();r.seen=true;r.firstRetrieved??=d;if(!r.firstRetrieved)r.firstRetrieved=d;r.goodDays??=[];r.history??=[];r.modes??={R:0,L:0,P:0};if(rating==='good'){if(!r.goodDays.includes(d)){r.goodDays.push(d);r.stage=Math.min(6,(r.stage||0)+1);}r.due=addDays(d,[2,4,7,14,21,30][Math.max(0,r.stage-1)]);r.modes[trainer.mode==='L'?'L':'R']=(r.modes[trainer.mode==='L'?'L':'R']||0)+1;award('retrieve:'+x.id,5);}else if(rating==='hard'){r.due=addDays(d,1);}else{r.stage=0;r.lapses=(r.lapses||0)+1;r.due=d;}r.lastDay=d;r.lastRating=rating;r.history.push({date:d,rating,mode:trainer.mode,source:'self-assessed delayed retrieval'});state.cards[canonicalId(x.id)]=r;pendingRetrieval47={target:trainer,id:x.id,owner};if(!(await vocabSave47.flush()))return false;pendingRetrieval47=null;nextTrainer();return true;}

/* Shadow extraction PRACTICE only. No assessment eligibility or progress writes.
 * Accepted exact Arabic-only recordings are discovered before generated speech.
 * Two historically approved pairs retain additional fixed pins. Generated
 * local Arabic is explicitly separate when no reviewed answer-safe pair exists.
 * All actual playback is delegated to the installed audio queue/router.
 */
(function (root, factory) {
  'use strict';
  const exported = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = exported;
  if (root && root.document) root.GH_SHADOW_EXTRACTION_AUDIO46 = exported.createAdapter();
})(typeof globalThis === 'object' ? globalThis : this, function (root) {
  'use strict';
  const VERSION = 'SHADOW-EXTRACTION-AUDIO-PRACTICE-3-SAFE-PREVIEW-FALLBACK';
  const QUEUE_VERSION = 'GH458-C64-RECONSTRUCTED-TWO-SOURCE-PREVIEW-ONLY-LOCAL-FILES-BROWSE-CUTS-GENERATED-GAPS-V4-AUTO-OFFLINE1';
  const ROUTER_VERSION = 'recreated-private-audio-router-v8-local-inline-status';
  const APPROVAL = '811fcc72e27fafe5a1bd981cc316b275baff6489de23f5b87f69abc7ee822a12';
  const PINS = Object.freeze({
    'ch04-008': Object.freeze({
      id:'ch04-008', text:'طَابِق',
      source:'private_master_glossary/ch04/CH_04_10.mp3',
      sourceSha256:'e7d019af93d74b24e8f61ee54e0a929fc772910d56960f33897cb428fb92a598',
      clip:'derived_vocab_verified/ch04/ch04-008_floor_859a03ef4ec6_word.wav',
      clipSha256:'859a03ef4ec67c031c4fa6abdc8b156a692394e81c6b986a13727e8b65a0c279',
      previewSha256:'eef166b3774a9aa417a2235f46fbb62a20d5bb8c40f07343ef6ae9d3d5698e02',
      sourceStart:99446, arabicFrames:54331, fullFrames:294191,
      evidenceType:'user_listening_approved_exact_clips_v1',humanApproval:true
    }),
    'ch04-009': Object.freeze({
      id:'ch04-009', text:'شَقَّة',
      source:'private_master_glossary/ch04/CH_04_09.mp3',
      sourceSha256:'a8aa0b58f653d24f59684902c5cc2ae89c1681a6237a6ee8fd178ea460458b14',
      clip:'derived_vocab_verified/ch04/ch04-009_apartment_530b3b59b587_word.wav',
      clipSha256:'530b3b59b58748e3d42cfb9cb8939d163236404144ce239f45f3dff11d58c269',
      previewSha256:'6c6f67e14df5b82b49e6415da04de4585948d7a77d59b4fba9d04289d9ee4476',
      sourceStart:102400, arabicFrames:55610, fullFrames:299086,
      evidenceType:'user_listening_approved_exact_clips_v1',humanApproval:true
    })
  });
  const PARTIAL_EVIDENCE = new Set([
    'user_listening_approved_c56_boundaries_only_v1', 'automated_boundary_v5',
    'automated_nonverbal_boundary_v6', 'automated_catalog_link_and_boundary_v1',
    'automated_nonverbal_catalog_link_and_boundary_v2',
    'automated_literal_verb_sequence_boundary_v7', 'automated_nominal_phrase_boundary_v8'
  ]);
  const norm = value => typeof value === 'string' ? value.normalize('NFC').replace(/\s+/gu,' ').trim() : '';
  const exact = (a,b) => typeof a === 'string' && typeof b === 'string' && norm(a) === norm(b);
  const own = (object,key) => !!object && Object.prototype.hasOwnProperty.call(object,key);
  function ownerDefault() {
    try { return JSON.stringify([state._save45?.profileId || '',state._save45?.epoch || '']); }
    catch (_) { return ''; }
  }
  function screenDefault() { try { return typeof tab === 'string' ? tab : ''; } catch (_) { return ''; } }
  function mockDefault() { try { return typeof state === 'object' && !!state.active; } catch (_) { return true; } }
  function createAdapter(environment = {}) {
    const E = environment;
    const getRouter = E.getRouter || (() => root.GH457_AUDIO);
    const getQueue = E.getQueue || (() => root.GH457_AUDIO_QUEUE);
    const getBoundary = E.getBoundary || (id => root.GH457_VOCAB_AUDIT_R3?.verifiedTwoStage?.[id]);
    const getSourceRegistry = E.getSourceRegistry || (() => root.GH_SOURCE_AUDIO3_REGISTRY);
    const getOwner = E.getOwner || ownerDefault;
    const getScreen = E.getScreen || screenDefault;
    const activeMock = E.activeMock || mockDefault;
    let prepared = null;
    function live(r) {
      try {
        const installed = getRouter()?.item?.(r.id);
        return prepared === r && !r.stopped && getOwner() === r.owner &&
          getScreen() === 'army' && activeMock() === false && r.isCurrent() === true &&
          installed?.id === r.id && installed.kind === 'vocabulary' && exact(installed.text,r.text);
      } catch (_) { return false; }
    }
    function result(r, ok, reason, extra = {}) {
      return Object.freeze({
        ok, completed:ok, category:r.category, evidenceKind:r.evidenceKind,
        target:Object.freeze({id:r.id,text:r.text,kind:'vocabulary'}),
        wordId:r.id, owner:r.owner, token:r.token,
        pronunciationReviewed:false, listeningCredit:false, deviceAudibleVerified:false,
        verifiedAssessment:false, ...extra, ...(reason ? {reason} : {})
      });
    }
    function blocked(reason) { return {available:false,label:'Audio unavailable',reason}; }
    function metadataMatches(pin, row) {
      const s = row?.sourceSamples, t = row?.trimSamples;
      const evidence = row?.evidenceType === 'user_listening_approved_exact_clips_v1' || PARTIAL_EVIDENCE.has(row?.evidenceType);
      const base = !!row && evidence && row.installed === true && row.authorized === true &&
        row.wordId === pin.id && row.sourceWordId === pin.id && exact(row.arabic,pin.text) &&
        row.evidenceType === pin.evidenceType && row.humanApproval === pin.humanApproval &&
        row.sourcePath === pin.source && row.sourceSha256 === pin.sourceSha256 &&
        row.wordTrimPath === pin.clip && row.wordTrimSha256 === pin.clipSha256 &&
        row.includesChapterIntroduction === false && row.includesNeighbouringVocabulary === false && row.arabicOnlyIncludesEnglish === false &&
        s?.sampleRate === 44100 && s.start === pin.sourceStart &&
        s.arabicEnd === pin.sourceStart + pin.arabicFrames && s.end === pin.sourceStart + pin.fullFrames &&
        t?.sampleRate === 44100 && t.arabicEnd === pin.arabicFrames && t.end === pin.fullFrames &&
        Number.isSafeInteger(pin.sourceStart) && pin.sourceStart >= 0 &&
        Number.isSafeInteger(pin.arabicFrames) && pin.arabicFrames > 0 &&
        Number.isSafeInteger(pin.fullFrames) && pin.fullFrames >= pin.arabicFrames &&
        row.wordStartInSourceSeconds === pin.sourceStart/44100 &&
        row.arabicOnlyEndSeconds === pin.arabicFrames/44100 && row.wordTrimEndSeconds === pin.fullFrames/44100;
      if (!base) return false;
      if (pin.metadataSignature) return JSON.stringify(row) === pin.metadataSignature;
      return row.approvalEvidenceSha256 === APPROVAL && row.approvedArabicPreviewSha256 === pin.previewSha256 &&
        [row.semanticReviewStatus,row.wordStartReview,row.arabicOnlyEndReview,row.wordTrimEndReview].every(x => x === 'user-listening-approved');
    }
    function pinAcceptedRoute(r, route) {
      const row = getBoundary(r.id);
      if (!row || !(row.evidenceType === 'user_listening_approved_exact_clips_v1' || PARTIAL_EVIDENCE.has(row.evidenceType))) return null;
      const hash = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x);
      const path = x => typeof x === 'string' && x.length < 1500 && !/^[\/\\]|[:\\?#%\u0000-\u001f]/.test(x) && x.split('/').every(v => v && v !== '.' && v !== '..');
      if (!hash(row.sourceSha256) || !hash(row.wordTrimSha256) || !path(row.sourcePath) || !path(row.wordTrimPath) || row.wordTrimPath === row.sourcePath) return null;
      const pin = own(PINS,r.id) ? PINS[r.id] : Object.freeze({
        id:r.id,text:r.text,source:row.sourcePath,sourceSha256:row.sourceSha256,
        clip:row.wordTrimPath,clipSha256:row.wordTrimSha256,
        sourceStart:row.sourceSamples?.start,arabicFrames:row.trimSamples?.arabicEnd,fullFrames:row.trimSamples?.end,
        evidenceType:row.evidenceType,humanApproval:row.humanApproval === true,
        metadataSignature:JSON.stringify(row)
      });
      const probe = {...r,pin};
      return metadataMatches(pin,row) && recordedRouteMatches(probe,route) ? pin : null;
    }
    function discovery(r, select) {
      const queue = getQueue(), audio = getRouter();
      if (queue !== r.queue || queue?.version !== QUEUE_VERSION || audio !== r.router || audio?.version !== ROUTER_VERSION ||
          typeof queue.setStudySet !== 'function' || typeof queue.select !== 'function' || typeof queue.resolve !== 'function' || typeof queue.play !== 'function')
        return {error:'The installed original-recording queue is unavailable. Source priority cannot be verified.'};
      if (select) {
        queue.setStudySet([r.id],{owner:r.owner,source:'shadow-extraction-practice',mode:'review'});
        if (queue.select(r.id,{owner:r.owner,review:true,encounterId:r.token}) !== true)
          return {error:'Audio could not bind to this extraction attempt.'};
      }
      const route = queue.resolve(r.id,{review:true,stage:'arabic-only'});
      if (!route || route.wordId !== r.id || route.target?.id !== r.id || route.target.kind !== 'vocabulary' ||
          !exact(route.target.text,r.text) || route.stage !== 'arabic-only' || route.purpose !== 'pre-answer-hint' ||
          route.listeningCredit !== false || route.pronunciationReviewed !== false)
        return {error:'The exact original-recording route could not be established.'};
      if (route.kind === 'recording' && route.safeArabicOnly === true) {
        const pin = pinAcceptedRoute(r,route);
        return pin ? {pin} : {error:'The Arabic-only recording does not match its exact source and boundary evidence.'};
      }
      if (own(PINS,r.id)) return {error:'The pinned usable original is unavailable. No generated replacement was selected.'};
      // A provisional source is not an answer-safe recording. Never play its
      // possible-English preview simply because visible study permits it.
      if (route.kind === 'recording' && route.safeArabicOnly === false && (route.provisional === true || route.previewOnly === true))
        return {pin:null,unsafePreview:true,reason:'The source preview may include English. Use separate local generated Arabic for this game practice; never play that preview before an answer.'};
      if (route.generated === true && route.generatedEligible === true && ['synthetic','unavailable'].includes(route.kind))
        return {pin:null,reason:'The current queue explicitly establishes no usable exact recording.'};
      if (route.kind === 'unavailable') return {error:'The original route is unresolved or unavailable: '+(route.reason || 'No answer-safe route.')+' No generated replacement was selected.'};
      return {error:'The original recording status is unresolved; no substitute was selected.'};
    }
    function recordedRouteMatches(r, route) {
      const p = r.pin;
      return !!route && route.kind === 'recording' && route.wordId === r.id &&
        route.target?.id === r.id && route.target.kind === 'vocabulary' && exact(route.target.text,r.text) &&
        route.sourceWordId === r.id && route.explicitCanonicalAlias === false &&
        route.originalSource === p.source && route.sourceSha256 === p.sourceSha256 && route.selectedSource === p.clip &&
        route.stage === 'arabic-only' && route.purpose === 'pre-answer-hint' &&
        route.startSeconds === 0 && route.endSeconds === p.arabicFrames/44100 &&
        route.safeArabicOnly === true && route.humanListeningApproved === p.humanApproval &&
        route.boundaryReview === p.evidenceType &&
        !route.provisional && !route.previewOnly && !route.generated && !route.answerRevealing &&
        route.listeningCredit === false && route.pronunciationReviewed === false;
    }
    function originalReady(r, select) {
      const queue = getQueue();
      if (queue !== r.queue || queue?.version !== QUEUE_VERSION ||
          getRouter() !== r.router || r.router?.version !== ROUTER_VERSION ||
          typeof queue.setStudySet !== 'function' || typeof queue.select !== 'function' ||
          typeof queue.resolve !== 'function' || typeof queue.play !== 'function' ||
          !metadataMatches(r.pin,getBoundary(r.id)))
        return blocked('The selected original clip or its exact evidence is unavailable. No generated replacement was selected.');
      if (select) {
        queue.setStudySet([r.id],{owner:r.owner,source:'shadow-extraction-practice',mode:'review'});
        if (queue.select(r.id,{owner:r.owner,review:true,encounterId:r.token}) !== true)
          return blocked('The original recording could not bind to this extraction attempt.');
      }
      const route = queue.resolve(r.id,{review:true,stage:'arabic-only'});
      if (!recordedRouteMatches(r,route)) return blocked('The accepted Arabic-only route is unavailable or differs from its pinned evidence. No generated replacement was selected.');
      return {available:true,label:r.evidenceKind === 'user-boundary-reviewed-original-arabic-only' ? 'Original Arabic · boundary-reviewed' : r.evidenceKind === 'machine-boundary-validated-original-arabic-only' ? 'Original Arabic · machine-checked boundary' : 'Original Arabic recording',reason:r.pin.evidenceType === 'user_listening_approved_c56_boundaries_only_v1' ? 'User-reviewed clip boundaries; source content and grammatical forms are not independently certified.' : r.pin.humanApproval ? 'Historical user review of the exact Arabic-only clip; practice, not verified listening assessment.' : 'Accepted automated boundary evidence; no human listening or pronunciation certification.'};
    }
    function fallbackEligible(r) {
      if (JSON.stringify(getBoundary(r.id) || null) !== r.discoveryBoundary) return false;
      // Only the explicit possible-English preview case may bypass the presence
      // of source records. It is never played; synthesis uses exact Arabic text.
      const found = discovery(r,false);
      if (found.error || found.pin) return false;
      if (found.unsafePreview === true) return true;
      const entries = getSourceRegistry()?.entries;
      if (entries && Object.keys(entries).some(key => key.startsWith(r.id+'::'))) return false;
      const row = getBoundary(r.id);
      if (row && !(row.evidenceType === 'user_listening_approved_exact_clips_v1' || PARTIAL_EVIDENCE.has(row.evidenceType))) return false;
      // Recheck discovery before generated playback. A newly usable original
      // blocks this prepared generated handle; prepare a new attempt to use it.
      return true;
    }
    function generatedReady(r) {
      const audio = getRouter();
      if (audio !== r.router || audio?.version !== ROUTER_VERSION ||
          typeof audio.resolveOriginalRoute !== 'function' || typeof audio.play !== 'function' || !fallbackEligible(r))
        return blocked('A safe generated route cannot be established, or additional recording evidence needs review.');
      const route = audio.resolveOriginalRoute({id:r.id,text:r.text,kind:'phrase'},{purpose:'study'});
      if (route?.kind !== 'synthetic' || route.localOnly !== true || route.selectedSource !== 'local-system-speech' ||
          route.target?.id !== r.id || route.target.kind !== 'phrase' || !exact(route.target.text,r.text) ||
          route.purpose !== 'study' || route.listeningCredit !== false || route.pronunciationReviewed !== false)
        return blocked(route?.reason || 'No permitted local Arabic speech route is available.');
      return {available:true,label:'Generated Arabic · unreviewed',voiceAvailable:route.voiceAvailable === true,
        reason:'No usable exact Arabic-only original route is installed for this target. Local Arabic speech is checked when you press Play.'};
    }
    function status(r) {
      let s;
      if (!r || !live(r)) s = blocked('This extraction attempt is no longer current.');
      else if (r.initialError) s = blocked(r.initialError);
      else {
        try { s = r.pin ? originalReady(r,false) : generatedReady(r); }
        catch (_) { s = blocked('Audio preparation could not be verified.'); }
      }
      return Object.freeze({...s,evidenceKind:r?.evidenceKind || 'unavailable',category:r?.category || 'unavailable'});
    }
    function stopRecord(r, reason = 'Extraction playback stopped') {
      if (!r) return;
      const wasCurrent = prepared === r;
      r.stopped = true; r.playSerial++;
      if (wasCurrent) {
        prepared = null;
        try { if (r.pin) r.queue?.stop?.(reason); else r.router?.stop?.(reason); } catch (_) {}
      }
    }
    async function playRecord(r) {
      const serial = ++r.playSerial;
      if (!live(r)) return result(r,false,'This extraction attempt is no longer current.',{cancelled:true});
      let ready;
      try { ready = r.initialError ? blocked(r.initialError) : r.pin ? originalReady(r,true) : generatedReady(r); }
      catch (_) { ready = blocked('Audio preparation could not be verified.'); }
      if (!ready.available) return result(r,false,ready.reason);
      const isCurrent = () => live(r) && r.playSerial === serial;
      let playback;
      try {
        playback = await (r.pin
          ? r.queue.play({id:r.id,text:r.text,kind:'vocabulary'},{review:true,stage:'arabic-only',rate:1,isCurrent})
          : r.router.play({id:r.id,text:r.text,kind:'phrase'},{purpose:'study',rate:1,isCurrent}));
      } catch (_) { return result(r,false,'Playback failed. Retry this source; no replacement audio was selected.'); }
      if (!isCurrent()) return result(r,false,'The attempt changed before playback completed.',{cancelled:true});
      if (playback?.ok !== true || playback.cancelled === true)
        return result(r,false,playback?.reason || 'Playback did not complete. No answer was unlocked.',{cancelled:playback?.cancelled === true});
      if (playback.target?.id !== r.id || !exact(playback.target.text,r.text) ||
          playback.pronunciationReviewed !== false || playback.listeningCredit !== false || playback.deviceAudibleVerified !== false)
        return result(r,false,'Playback completion did not match this target and evidence mode.');
      if (r.pin) {
        let valid = false;
        try {
          valid = originalReady(r,false).available && playback.kind === 'recording' &&
            playback.wordId === r.id && playback.stage === 'arabic-only' && playback.purpose === 'pre-answer-hint' &&
            playback.selectedSource === r.pin.clip && playback.originalSource === r.pin.source &&
            playback.startSeconds === 0 && playback.endSeconds === r.pin.arabicFrames/44100 &&
            playback.safeArabicOnly === true && playback.humanListeningApproved === r.pin.humanApproval &&
            playback.boundaryEvidence === r.pin.evidenceType &&
            !playback.provisional && !playback.previewOnly && !playback.generated && !playback.answerRevealing;
        } catch (_) {}
        if (!valid) return result(r,false,'Original playback did not retain its exact Arabic-only evidence.');
        return result(r,true,'',{source:'original-recording',selectedSource:r.pin.clip,
          clipSha256:r.pin.clipSha256,sourceSha256:r.pin.sourceSha256,
          startSeconds:0,endSeconds:r.pin.arabicFrames/44100,
          boundaryEvidence:r.pin.evidenceType,humanBoundaryApproval:r.pin.humanApproval,
          semanticContentCertified:false,originalFailed:false});
      }
      let routeStillValid = false;
      try { routeStillValid = generatedReady(r).available; } catch (_) {}
      if (!routeStillValid || playback.kind !== 'synthetic' || playback.target.kind !== 'phrase' ||
          playback.purpose !== 'study' || playback.selectedSource !== 'local-system-speech' ||
          !/^ar(?:[-_]|$)/i.test(playback.voiceLang || '') || !playback.voiceName)
        return result(r,false,'Generated Arabic playback could not be confirmed for this exact target.');
      return result(r,true,'',{source:'local-system-speech',generated:true,localOnly:true,
        voiceName:playback.voiceName,voiceLang:playback.voiceLang,
        originalAvailability:'no-usable-exact-arabic-only-original-route'});
    }
    function prepare(input = {}) {
      const id = typeof input.id === 'string' ? input.id : '';
      const text = norm(input.text), owner = input.owner, token = input.token;
      if (prepared && !prepared.stopped && prepared.id === id && prepared.text === text &&
          prepared.owner === owner && prepared.token === token) {
        if (typeof input.isCurrent === 'function') prepared.isCurrent = input.isCurrent;
        return prepared.handle;
      }
      stopRecord(prepared,'Extraction attempt replaced');
      const r = {id,text,owner,token,isCurrent:input.isCurrent,router:getRouter(),queue:getQueue(),
        pin:own(PINS,id) ? PINS[id] : null,stopped:false,playSerial:0,initialError:''};
      r.category = r.pin ? 'recorded-arabic-only-practice' : 'generated-arabic-practice';
      r.evidenceKind = r.pin ? 'user-reviewed-original-arabic-only' : 'generated-unreviewed';
      prepared = r;
      try {
        const installed = r.router?.item?.(id);
        if (!id || typeof owner !== 'string' || !owner || typeof token !== 'string' || !token ||
            typeof r.isCurrent !== 'function' || !installed || installed.id !== id ||
            installed.kind !== 'vocabulary' || !exact(installed.text,text) ||
            !/\p{Script=Arabic}/u.test(text) || /\p{Script=Latin}/u.test(text))
          r.initialError = 'An exact installed Arabic target and current extraction identity are required.';
        else if (r.pin && !exact(text,r.pin.text))
          r.initialError = 'The requested form differs from the approved original recording.';
        else if (!live(r)) r.initialError = 'Open a current, unanswered Shadow extraction to play this target.';
        else {
          r.discoveryBoundary = JSON.stringify(getBoundary(r.id) || null);
          const found = discovery(r,true);
          if (found.error) r.initialError = found.error;
          else r.pin = found.pin;
        }
      } catch (_) { r.initialError = 'Audio preparation could not be verified.'; }
      r.category = r.pin ? 'recorded-arabic-only-practice' : 'generated-arabic-practice';
      r.evidenceKind = !r.pin ? 'generated-unreviewed' : r.pin.evidenceType === 'user_listening_approved_c56_boundaries_only_v1' ? 'user-boundary-reviewed-original-arabic-only' : r.pin.humanApproval ? 'user-reviewed-original-arabic-only' : 'machine-boundary-validated-original-arabic-only';
      r.handle = Object.freeze({
        get available() { return status(r).available; },
        get label() { return status(r).label; },
        get reason() { return status(r).reason; },
        get voiceAvailable() { return status(r).voiceAvailable; },
        evidenceKind:r.evidenceKind,category:r.category,
        availability:() => status(r),play:() => playRecord(r),stop:reason => stopRecord(r,reason)
      });
      return r.handle;
    }
    return Object.freeze({version:VERSION,prepare,availability:() => status(prepared),
      play:() => prepared ? playRecord(prepared) : Promise.resolve({ok:false,completed:false,reason:'Prepare an extraction first.'}),
      stop:reason => stopRecord(prepared,reason)});
  }
  return Object.freeze({VERSION,QUEUE_VERSION,ROUTER_VERSION,PINS,createAdapter});
});

window.GH_SHADOW_PHRASE_CHOICES46=(()=>{
/* Pure source-only choice construction. No imports, DOM, storage, audio or grading. */
function normalizeSpelling(value) {
  return String(value).normalize('NFKC')
    .replace(/[\u064b-\u065f\u0670\u0640]/g, '')
    .replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '')
    .replace(/[.,،؛؟?!]/g, '').replace(/\s+/g, ' ').trim();
}

const CONTRACT = Object.freeze({
  version: 1,
  choiceEvidence: 'source-form-recognition-only',
  englishMeaning: 'required-separate-host-typed-grading',
  typedTranscriptionProven: false,
  awardsProgress: false,
  eligibleIntroducedPool: 'host-required; helper-does-not-read-or-verify-exposure',
  canonicalGroups: 'host-resolved; helper-does-not-infer-equivalence',
  sourceTrust: 'host-pinned-exact-source; no-generated-or-corrected-forms',
  selectionAndAttemptLifetime: 'host-owned; build-once-and-retain-per-attempt',
  similarity: 'heuristic-only; two-or-more-Arabic-words, count-difference-at-most-one, edit-similarity-at-least-0.30',
  audio: 'not-provided-or-verified'
});

// Returns a fresh deterministic RNG. Pass a different attempt seed for new orders.
function seededRng(seed) {
  if (!((typeof seed === 'string' && seed.length > 0) ||
        (typeof seed === 'number' && Number.isFinite(seed)))) {
    throw new TypeError('seed must be a nonempty string or finite number');
  }
  let state = 2166136261;
  for (const ch of `${typeof seed}:${seed}`) {
    state = Math.imul(state ^ ch.codePointAt(0), 16777619) >>> 0;
  }
  return () => {
    state = (state + 0x6D2B79F5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function placeholderMeaning(meaning) {
  const text = meaning.trim();
  return !/[A-Za-z]/.test(text) ||
    /^(?:tbd|tbc|n\/?a|unresolved|unverified|placeholder)(?:\b|$)/i.test(text) ||
    /^(?:\[(?:unknown|pending|unresolved|translation|meaning)[^\]]*\]|(?:meaning|translation)\s*[:=-]?\s*(?:pending|unknown|missing|unresolved|tbd|to be determined))$/i.test(text);
}

function view(entry) {
  if (!entry || entry.resolved !== true ||
      (typeof entry.id !== 'string' || !entry.id.trim()) ||
      (typeof entry.canonicalId !== 'string' || !entry.canonicalId.trim()) ||
      (typeof entry.sourceRef !== 'string' || !entry.sourceRef.trim()) ||
      (typeof entry.sourceForm !== 'string' || !entry.sourceForm.trim()) ||
      (typeof entry.meaning !== 'string' || placeholderMeaning(entry.meaning))) return null;
  const normalized = normalizeSpelling(entry.sourceForm);
  const tokens = normalized.split(' ');
  // A slash-delimited paradigm is not a phrase. Do not split or repair source text.
  const singlePhrase = tokens.every(token => token.length > 0 &&
    Array.from(token).every(ch => /\p{Letter}/u.test(ch) && /\p{Script=Arabic}/u.test(ch)));
  return { entry, normalized, tokens, singlePhrase };
}

function editSimilarity(a, b) {
  const left = Array.from(a), right = Array.from(b);
  let previous = Array.from({ length: right.length + 1 }, (_, i) => i);
  for (let i = 1; i <= left.length; i++) {
    const current = [i];
    for (let j = 1; j <= right.length; j++) {
      current[j] = Math.min(current[j - 1] + 1, previous[j] + 1,
        previous[j - 1] + Number(left[i - 1] !== right[j - 1]));
    }
    previous = current;
  }
  return 1 - previous[right.length] / Math.max(left.length, right.length, 1);
}

function option(item) {
  return Object.freeze({
    // A collision-free tuple, not a positional index or a role-revealing label.
    key: JSON.stringify([item.entry.id, item.normalized]),
    sourceId: item.entry.id,
    canonicalId: item.entry.canonicalId,
    sourceForm: item.entry.sourceForm,
    sourceRef: item.entry.sourceRef
  });
}

function result(mode, reason, options = [], correctOptionKey = null, count = 0) {
  return Object.freeze({ mode, reason, options: Object.freeze(options),
    correctOptionKey, eligibleDistractorCount: count, contract: CONTRACT });
}

/**
 * buildPhraseChoices({target, pool, seed?, rng?, maxOptions?})
 * Each entry: {id, canonicalId, sourceForm, meaning, resolved:true, sourceRef}.
 * Host supplies only introduced, eligible source entries; resolved must be explicit.
 * Pass seed OR rng (not both). An RNG must return finite values in [0,1).
 * Returns mode 'source-choice' or explicit 'typed' fallback. Never grades anything.
 */
function buildPhraseChoices({ target, pool = [], seed, rng, maxOptions = 4 } = {}) {
  const chosen = view(target);
  if (!chosen) return result('typed', 'target_unresolved_or_incomplete');
  if (!chosen.singlePhrase) return result('typed', 'target_not_single_arabic_phrase');
  if (chosen.tokens.length < 3) return result('typed', 'short_target');
  if (!Array.isArray(pool)) return result('typed', 'pool_required');
  if (!Number.isInteger(maxOptions) || maxOptions < 2 || maxOptions > 4) {
    return result('typed', 'max_options_must_be_2_to_4');
  }
  const candidates = [];
  for (const entry of pool) {
    const item = view(entry);
    if (!item || !item.singlePhrase || item.tokens.length < 2 ||
        entry.id === target.id || entry.canonicalId === target.canonicalId ||
        item.normalized === chosen.normalized) continue;
    const countDistance = Math.abs(item.tokens.length - chosen.tokens.length);
    const similarity = editSimilarity(chosen.normalized, item.normalized);
    if (countDistance > 1 || similarity < 0.30) continue;
    candidates.push({ ...item, similarity, countDistance });
  }
  candidates.sort((a, b) =>
    // Favor spelling similarity, with a modest penalty for a different word count.
    (b.similarity - 0.15 * b.countDistance) - (a.similarity - 0.15 * a.countDistance) ||
    (a.entry.id < b.entry.id ? -1 : a.entry.id > b.entry.id ? 1 : 0));
  const seenForms = new Set([chosen.normalized]);
  const seenGroups = new Set([target.canonicalId]);
  const seenIds = new Set([target.id]);
  const distinct = candidates.filter(item => {
    if (seenForms.has(item.normalized) || seenGroups.has(item.entry.canonicalId) ||
        seenIds.has(item.entry.id)) return false;
    seenForms.add(item.normalized);
    seenGroups.add(item.entry.canonicalId);
    seenIds.add(item.entry.id);
    return true;
  });
  if (!distinct.length) return result('typed', 'no_defensible_source_distractor');
  if (rng !== undefined && seed !== undefined) return result('typed', 'supply_rng_or_seed_not_both');
  let random = rng;
  if (random === undefined && seed !== undefined) {
    try { random = seededRng(seed); } catch { return result('typed', 'invalid_seed'); }
  }
  if (typeof random !== 'function') return result('typed', 'rng_or_seed_required');
  const correct = option(chosen);
  const options = [correct, ...distinct.slice(0, maxOptions - 1).map(option)];
  // Fisher-Yates shuffles the answer with the distractors; position is not fixed.
  for (let i = options.length - 1; i > 0; i--) {
    const value = random();
    if (!Number.isFinite(value) || value < 0 || value >= 1) {
      return result('typed', 'rng_value_out_of_range');
    }
    const j = Math.floor(value * (i + 1));
    [options[i], options[j]] = [options[j], options[i]];
  }
  return result('source-choice', 'eligible_long_phrase', options, correct.key, distinct.length);
}

return Object.freeze({buildPhraseChoices,CONTRACT});
})();

// Shadow extraction is game practice, separate from the reviewed-assessment gate.
let shadowActive46=null;
function shadowOwner46(){return JSON.stringify([state._save45?.profileId||'',state._save45?.epoch||'']);}
function shadowCurrent46(t){return trial===t&&t.mode==='army'&&tab==='army'&&!t.checked&&!t.revealed&&!state.active&&t.responseOwner5===shadowOwner46()&&!window.GH_HINT_REWARDS5?.isStaleTrial(t);}
function shadowStop46(reason='Extraction changed'){
 if(shadowActive46){
  const t=shadowActive46.trial;
  if(t){t.shadowPlaying46=false;t.shadowPlaySerial46=(t.shadowPlaySerial46||0)+1;if(!t.checked&&!t.revealed){t.played=false;t.shadowAudioResult46=null;}}
  shadowActive46.handle?.stop?.(reason);shadowActive46=null;
 }
}
function shadowPracticeUsable46(p){return p==null||window.GH_PROGRESS45?.shadowPracticeValid46?.(p)===true;}
function shadowEvidenceAvailable46(){
 try{if(typeof window.GH_PROGRESS45?.validateShadowArmy46!=='function')return false;return window.GH_PROGRESS45.validateShadowArmy46(state)===true;}catch{return false;}
}
function shadowRecoveryMessage46(){return 'Shadow Army is unavailable because game-practice evidence could not be validated. Existing evidence and XP are unchanged. Export a full recovery backup in Save & recovery, then restore a valid checkpoint.';}
function shadowPracticeRecruited46(p){
 if(!shadowPracticeUsable46(p))return false;
 const passes=Array.isArray(p?.passes)?p.passes:[];
 // Derive from append/merge-safe evidence, not a stale tab's boolean flag.
 return passes.some((a,i)=>typeof a.date==='string'&&Number.isFinite(a.at)&&passes.some((b,j)=>i!==j&&typeof b.date==='string'&&Number.isFinite(b.at)&&a.date!==b.date&&Math.abs(a.at-b.at)>=18*3600000));
}
function shadowPracticeDates46(a){return shadowPracticeUsable46(a?.practice46)?new Set((a?.practice46?.passes||[]).map(p=>p.date)).size:null;}
function shadowRecruited46(a){return !!a?.recruited||shadowPracticeRecruited46(a?.practice46);}
function shadowCandidate46(a){return shadowPracticeUsable46(a?.practice46)&&!shadowRecruited46(a)&&!!(a?.passes?.length||a?.practice46?.passes?.length);}
function shadowCooldown46(a){return shadowPracticeUsable46(a?.practice46)?Math.max(a?.retryAfter||0,a?.practice46?.retryAfter||0):Infinity;}

function shadowSource46(x){return {id:x.id,canonicalId:canonicalId(x.id),sourceForm:x.speech,meaning:x.studyMeaning,resolved:x.ling?.pos!=='unresolved'&&!x.studyMeaning?.startsWith('['),sourceRef:'installed-vocabulary:'+x.id};}
function shadowPlan46(t){
 if(!t||t.mode!=='army')return null;
 if(!t.shadowPlan46||t.shadowPlan46.targetId!==t.id){
  const x=byId[t.id],pool=trialPool();
  const plan=window.GH_SHADOW_PHRASE_CHOICES46?.buildPhraseChoices({target:shadowSource46(x),pool:pool.map(shadowSource46),seed:t.token});
  t.shadowPlan46={targetId:t.id,mode:plan?.mode||'typed',reason:plan?.reason||'choice_helper_unavailable',options:plan?.options||[],correctOptionKey:plan?.correctOptionKey||null};
  t.shadowChoice46=null;
 }
 return t.shadowPlan46;
}
function shadowAudio46(t){
 const x=byId[t.id];
 if(shadowActive46&&(shadowActive46.trial!==t||shadowActive46.id!==t.id||shadowActive46.owner!==shadowOwner46()))shadowStop46();
 if(!shadowActive46&&shadowCurrent46(t)){
  const handle=window.GH_SHADOW_EXTRACTION_AUDIO46?.prepare({id:t.id,text:x.speech,owner:shadowOwner46(),token:t.token,isCurrent:()=>shadowCurrent46(t)&&byId[t.id]?.speech===x.speech});
  shadowActive46={trial:t,id:t.id,owner:shadowOwner46(),handle:handle||{available:false,label:'Extraction audio unavailable',reason:'Audio adapter did not load.'}};
 }
 return shadowActive46?.handle||{available:false,label:'Extraction audio unavailable',reason:'Start a new extraction trial.'};
}
async function shadowGrade46(){
 const t=trial;if(!t||!shadowCurrent46(t))return false;
 if(!shadowEvidenceAvailable46()){toast(shadowRecoveryMessage46());return false;}
 const retryAt=shadowCooldown46(state.rpg.army[canonicalId(t.id)]);
 if(retryAt>Date.now()){toast('Practice now; this extraction retry is available in '+Math.ceil((retryAt-Date.now())/60000)+' minute(s). No answer was graded.');return false;}
 const x=byId[t.id],plan=shadowPlan46(t);
 if(!t.played||!t.shadowAudioResult46?.ok){toast('Complete Arabic audio playback first.');return false;}
 const selected=plan.mode==='source-choice'?plan.options.find(o=>o.key===t.shadowChoice46):null;
 t.spell=plan.mode==='source-choice'?(selected?.sourceForm||''):($('trialSpell')?.value||'');
 t.meaning=$('trialMeaning')?.value||'';
 if(!spellingNorm(t.spell)||!/[\p{L}\p{N}]/u.test(englishNorm(t.meaning))){toast(plan.mode==='source-choice'?'Select an Arabic spelling and type its English meaning first.':'Type the Arabic spelling and English meaning first.');return false;}
 t.spellCorrect=plan.mode==='source-choice'?selected?.key===plan.correctOptionKey:spellingNorm(t.spell)===spellingNorm(x.speech);
 t.meaningCorrect=meaningOK(t.meaning,x);
 // Retain the existing daily spelling XP key/rate without creating T/L scores.
 if(t.spellCorrect&&!t.assisted)award('skill:'+canonicalId(x.id)+':T',8);
 if(t.meaningCorrect&&!t.assisted)award('skill:'+canonicalId(x.id)+':TE',8);
 const a=state.rpg.army[x.id]||{passes:[],recruited:false};
 // Separate game progress cannot be consumed as legacy assessed Army evidence.
 a.practice46??={schema:1,passes:[]};const practice=a.practice46;
 const evidence={kind:'shadow-extraction-practice',arabicTask:plan.mode==='source-choice'?'source-form-recognition':'typed-spelling',audio:t.shadowAudioResult46.category,audioEvidence:t.shadowAudioResult46.evidenceKind||'not-reported',audioClipSha256:t.shadowAudioResult46.clipSha256||null,sourceId:x.id,reviewedListening:false,typedTranscriptionClaim:false};
 practice.lastAttempt={...evidence,at:Date.now(),spellCorrect:t.spellCorrect,meaningCorrect:t.meaningCorrect,assisted:!!t.assisted};
 if(t.spellCorrect&&t.meaningCorrect&&!t.assisted){
  const d=localDay();
  const now=Date.now(),delayed=practice.passes.some(p=>now-p.at>=18*3600000&&p.date!==d);
  // Keep a same-day later pass when it is the first to cross the delay threshold.
  if(!practice.passes.some(p=>p.date===d)||(delayed&&!shadowPracticeRecruited46(practice)))practice.passes.push({date:d,at:now,token:t.token,evidence});
  if(shadowPracticeRecruited46(practice)){practice.lastPassedAt=Date.now();award('arise:'+x.id,25);}
  t.candidate=!shadowRecruited46(a);
 }else practice.retryAfter=Date.now()+10*60000;
 state.rpg.army[x.id]=a;t.checked=true;shadowStop46('Answer checked');t.shadowSaveUnverified46=!(await vocabSave47.flush());if(trial===t)render();return !t.shadowSaveUnverified46;
}
function renderShadowTrial46(){
 const t=trial,x=byId[t.id],plan=shadowPlan46(t),handle=shadowAudio46(t),choices=plan.mode==='source-choice';
 const unavailable=!t.checked&&!t.revealed&&!handle.available;
 const result=t.shadowAudioResult46;
 const audioEvidence=result?.evidenceKind||handle.evidenceKind;
 const audioDetail=audioEvidence==='user-boundary-reviewed-original-arabic-only'?'Clip boundaries were reviewed; source content and grammatical forms are not independently certified.':audioEvidence==='machine-boundary-validated-original-arabic-only'?'The clip boundary has automated evidence, not human listening or pronunciation certification.':'';
 const audioLabel=result?.category==='generated-arabic-practice'?'Generated Arabic · unreviewed':result?.category==='recorded-arabic-only-practice'?'Original Arabic-only recording · game practice':handle.label;
 return `<section class="card trial"><div class="eyebrow">Shadow extraction · game practice · introduced vocabulary</div><p class="mini">${esc(groupSummary(x))}. Opening Learn makes a word eligible for practice. Learned is not yet a candidate: pass both spelling and meaning without revealing the answer once to become a candidate; repeat on another day, at least 18 hours later, to recruit.</p><h2>Listen, ${choices?'choose the Arabic spelling':'type the Arabic spelling'}, then explain.</h2>
 <p class="mini">${esc(audioLabel||'Extraction audio unavailable')}. This is a study achievement, not a certified listening, pronunciation or transcription score. ${esc(audioDetail)}</p>
 ${!t.checked&&!t.revealed?vbutton('trial-play',t.shadowPlaying46?'Playing Arabic…':t.played?'Replay Arabic':'Play Arabic',unavailable||t.shadowPlaying46?'disabled':'','primary'):''}
 ${unavailable?`<p class="banner">${esc(handle.reason||'No usable Arabic audio route is available.')}. No answer is graded and no cooldown or XP loss is recorded.</p>`:''}
 ${t.shadowAudioMessage46?`<p class="banner" role="status">${esc(t.shadowAudioMessage46)}</p>`:''}
 ${choices?`<fieldset><legend>Choose the spelling you heard</legend><div class="actions">${plan.options.map((o,i)=>vbutton('trial-choice',`<span lang="ar" dir="rtl">${esc(o.sourceForm)}</span>`,`data-choice="${i}" aria-pressed="${t.shadowChoice46===o.key}" ${t.checked||t.revealed||!t.played?'disabled':''}`,t.shadowChoice46===o.key?'primary':'')).join('')}</div><p class="mini">These are distinct forms from introduced source entries. Choosing is recognition, not typing the full phrase.</p></fieldset>`:`<label class="answerLabel">Arabic spelling<input id="trialSpell" dir="rtl" lang="ar" autocomplete="off" spellcheck="false" value="${esc(t.spell||'')}" ${t.checked||t.revealed?'readonly':''}></label>${plan.reason==='no_defensible_source_distractor'?'<p class="mini">No similar introduced source phrase is available yet, so this item uses typing. Diacritics are optional.</p>':'<p class="mini">Diacritics are optional; hamza, ة and ى remain distinct.</p>'}`}
 <label class="answerLabel">English meaning<input id="trialMeaning" autocomplete="off" value="${esc(t.meaning||'')}" ${t.checked||t.revealed?'readonly':''}></label>
 <div class="actions spacer">${!t.checked&&!t.revealed?vbutton('trial-submit','<span lang="ar" dir="rtl">اِنْهَضْ</span> · check both',!t.played||t.shadowPlaying46||unavailable?'disabled':'','primary'):vbutton('trial-next','Next eligible word')}${!t.checked&&!t.revealed?vbutton('trial-hint','Reveal for practice (no recruit)'):''}${vbutton('trial-close','Close')}</div>
 ${t.shadowSaveUnverified46?'<p class="banner warn">Saving could not be verified. Keep this page open and use Save &amp; recovery before leaving.</p>':''}
 ${t.checked?`<div class="banner ${t.spellCorrect&&t.meaningCorrect?'':'warn'}">${choices?'Arabic choice':'Spelling'}: ${t.spellCorrect?'matched':'needs repair'}. Meaning: ${t.meaningCorrect?'matched':'not matched automatically'}. ${shadowRecruited46(state.rpg.army[x.id])?'<span lang="ar" dir="rtl">اِنْهَضْ</span> — recruited (game practice).':t.candidate?'Both passed. Candidate registered. Pass again on a different day, at least 18 hours later, to recruit.':'Practice, then return after the ten-minute cooldown. No XP is removed.'}</div>`:''}
 ${t.checked||t.revealed?`<div class="ar" lang="ar">${esc(x.speech)}</div><p>${esc(x.meaningDisplay)}</p>${formPanel(x)}${!t.meaningCorrect?'<p class="mini">The English check accepts short source glosses, not every valid synonym. This is not a semantic-language grade.</p>':''}${t.revealed?'<p class="mini">Answer revealed for practice. This attempt cannot recruit or earn an independent pass.</p>':''}`:''}</section>`;
}

function trialPool(){return activeItems().filter(x=>hasIntroduced(x.id)&&matchesScope(x,trialFilter)&&x.ling.pos!=='unresolved'&&!x.studyMeaning.startsWith('['));}
function chooseTrial(mode='army',game=''){const introduced=trialPool(),pool=mode==='army'?introduced.filter(x=>shadowCooldown46(state.rpg.army[canonicalId(x.id)])<=Date.now()):introduced;if(!pool.length){toast(introduced.length?'No eligible extraction now. Practice other words or return after the ten-minute cooldown.':'Introduce vocabulary first. Gates and trials do not assign unseen words.');return;}const due=pool.filter(x=>!(mode==='army'?shadowRecruited46(state.rpg.army[x.id]):state.rpg.army[x.id]?.recruited)||rec(x.id).due<=day());const x=(due.length?due:pool)[Math.floor(Math.random()*(due.length||pool.length))];trial={id:x.id,mode,game,played:false,revealed:false,checked:false,spell:'',meaning:'',assisted:false,startedAt:Date.now(),responseOwner5:JSON.stringify([state._save45?.profileId||'',state._save45?.epoch||'']),token:crypto.randomUUID?.()||String(Date.now())};tab=mode==='army'?'army':'quests';render();}
function assessmentAudioAvailable46(){return window.GH_AUDIO_POLICY46?.assessmentAvailable?.()===true;}
function audioUnavailable46(kind='assessment'){if(window.GH_AUDIO_POLICY46?.notify)return GH_AUDIO_POLICY46.notify(kind);toast(kind==='assessment'?'Reviewed Arabic audio is unavailable for this assessment. Continue with reading or text practice; no answer was graded.':'Reviewed Arabic pronunciation is unavailable for this word. Use the written model or a reviewed source recording.');return false;}
function heardTrial(){
 if(!trial||window.GH_HINT_REWARDS5?.isStaleTrial(trial))return;
 if(trial.mode==='army'){
  const t=trial;if(!shadowCurrent46(t)||t.shadowPlaying46)return;
  const handle=shadowAudio46(t);if(!handle.available){toast(handle.reason||'Extraction audio is unavailable.');return;}
  const serial=t.shadowPlaySerial46=(t.shadowPlaySerial46||0)+1;
  const current=()=>shadowCurrent46(t)&&shadowActive46?.handle===handle&&t.shadowPlaySerial46===serial;
  t.played=false;t.shadowAudioResult46=null;t.shadowAudioMessage46='';t.shadowPlaying46=true;render();
  Promise.resolve().then(()=>handle.play()).then(result=>{
   if(!current())return;
   t.shadowPlaying46=false;
   if(result?.ok===true&&result.completed===true&&result.target?.id===t.id&&result.target?.text?.normalize('NFC')===byId[t.id].speech.normalize('NFC')&&result.owner===shadowOwner46()&&result.token===t.token&&['recorded-arabic-only-practice','generated-arabic-practice'].includes(result.category)){
    t.played=true;t.shadowAudioResult46=result;
   }else t.shadowAudioMessage46=result?.reason||'Audio did not complete. Retry playback; nothing was graded.';
   render();
  }).catch(()=>{if(current()){t.shadowPlaying46=false;t.shadowAudioMessage46='Audio could not complete. Nothing was graded.';render();}});
  return;
 }
 if(!assessmentAudioAvailable46()){audioUnavailable46();return;}
 const target=trial,token=trial.token,owner=shadowOwner46();
 speakText(byId[target.id].speech,()=>{if(trial===target&&trial.token===token&&owner===shadowOwner46()&&!window.GH_HINT_REWARDS5?.isStaleTrial(trial)){trial.played=true;render();}});
}
async function certifyTrial(){if(!trial||trial.checked)return;if(trial.mode==='army')return shadowGrade46();if(['army','L','T'].includes(trial.mode)&&!assessmentAudioAvailable46()){audioUnavailable46();return false;}const x=byId[trial.id];trial.spell=$('trialSpell')?.value||'';trial.meaning=$('trialMeaning')?.value||'';if((trial.mode==='army'||['L','T'].includes(trial.mode))&&!trial.played){toast('Complete audio playback first.');return;}
 if(['TE','TA'].includes(trial.mode)&&!/[\p{L}\p{N}]/u.test(spellingNorm(trial.mode==='TE'?trial.meaning:trial.spell))){toast('Enter an answer before checking. No attempt was recorded.');return false;}
 const spellCorrect=spellingNorm(trial.spell)===spellingNorm(x.speech),meaningCorrect=meaningOK(trial.meaning,x);trial.spellCorrect=spellCorrect;trial.meaningCorrect=meaningCorrect;
 if(trial.mode==='TE'||trial.mode==='L'){skillEvent(x.id,trial.mode,meaningCorrect,'automatic',trial.assisted);}else if(trial.mode==='TA'||trial.mode==='T'){skillEvent(x.id,trial.mode,spellCorrect,'automatic',trial.assisted);}trial.checked=true;if(await vocabSave47.flush())render();}
function renderTrial(){if(!trial)return'';if(trial.mode==='army')return renderShadowTrial46();const x=byId[trial.id],m=trial.mode,audio=m==='army'||m==='L'||m==='T',needSpell=m==='army'||m==='TA'||m==='T',needMeaning=m==='army'||m==='TE'||m==='L',unavailable=audio&&!assessmentAudioAvailable46();return `<section class="card trial"><div class="eyebrow">${m==='army'?'Shadow extraction trial':MODES[m]+' skill trial'} · introduced vocabulary only</div><p class="mini">${esc(groupSummary(x))}. No answer reveal before a certified success. Diacritics are optional; letters, hamza, ة and ى are not silently substituted.</p>${audio?`<h2>Listen. Then reconstruct.</h2>${vbutton('trial-play',unavailable?'Reviewed audio unavailable':trial.played?'Replay reviewed audio':'Play reviewed Arabic',unavailable?'disabled':'','primary')}${unavailable?`<p class="banner">Reviewed Arabic audio is unavailable for this trial. No answer is graded and no retry penalty or recruitment credit is recorded. Continue with text practice.</p><div class="actions">${vbutton('skill-start','Arabic → English practice',`data-mode="TE"`)}${vbutton('skill-start','English → Arabic practice',`data-mode="TA"`)}</div>`:''}`:m==='TE'?`<div class="ar big" lang="ar">${esc(x.speech)}</div>`:`<h2>${esc(x.meaningDisplay)}</h2>`}
 ${needSpell?`<label class="answerLabel">Arabic spelling<input id="trialSpell" dir="rtl" lang="ar" autocomplete="off" spellcheck="false" value="${esc(trial.spell||'')}" ${trial.checked?'readonly':''}></label>`:''}${needMeaning?`<label class="answerLabel">English meaning<input id="trialMeaning" autocomplete="off" value="${esc(trial.meaning||'')}" ${trial.checked?'readonly':''}></label>`:''}
 <div class="actions spacer">${!trial.checked?vbutton('trial-submit',m==='army'?'<span lang="ar" dir="rtl">اِنْهَضْ</span> · check both':'Check answer',unavailable?'disabled':'', 'primary'):vbutton('trial-next','Next eligible word')}${!trial.checked?vbutton('trial-hint','Reveal for practice (no recruit)'):''}${vbutton('trial-close','Close')}</div>
 ${trial.checked?`<div class="banner ${((!needSpell||trial.spellCorrect)&&(!needMeaning||trial.meaningCorrect))?'':'warn'}">${needSpell?'Spelling: '+(trial.spellCorrect?'matched':'needs repair')+'. ':''}${needMeaning?'Meaning: '+(trial.meaningCorrect?'matched':'not matched automatically')+'. ':''}${m==='army'?state.rpg.army[x.id]?.recruited?'<span lang="ar" dir="rtl">اِنْهَضْ</span> — recruited.':trial.candidate?'Both passed. Candidate registered; pass again on a different day, at least 18 hours later, to recruit.':'Practice now, then return after the cooldown. No XP is removed.':''}</div>`:''}
 ${trial.checked||trial.revealed?`<div class="ar" lang="ar">${esc(x.speech)}</div><p>${esc(x.meaningDisplay)}</p>${formPanel(x)}${!trial.meaningCorrect&&needMeaning?'<p class="mini">A valid synonym may not be in the automatic key. A teacher/partner can review it, but a manual override does not recruit a shadow. Use an accepted short gloss on the next independent trial.</p>':''}`:''}</section>`;}
function renderArmy(){if(!shadowEvidenceAvailable46())return heading('Shadow Army unavailable','Existing progress is preserved.')+'<section class="card"><p class="banner warn" role="status">'+shadowRecoveryMessage46()+'</p></section>';const pool=trialPool(),n=Object.values(state.rpg.army).filter(shadowRecruited46).length,cand=Object.values(state.rpg.army).filter(shadowCandidate46).length;return heading('Shadow Army','Recruit a word through game practice: listen, check its Arabic spelling, explain, then repeat on another day.')+xpPanel()+`<div class="stats">${stat('Recruited',n,'Two game-practice checks, at least 18 hours apart')}${stat('Candidates',cand,'Passed once; delayed confirmation pending')}${stat('Available vocabulary',pool.length,'Introduced groups only')}${stat('Points lost for errors',0,'Mistakes create practice targets, not penalties')}</div><section class="card"><div class="toolbar"><label>Unit / chapter<select id="trialScope">${scopeOptions(trialFilter)}</select></label>${vbutton('army-start','Begin extraction trial','','primary')}</div><p>Recruitment requires an Arabic spelling check and typed English meaning. Longer phrases use similar introduced source choices when available. Revealing the answer prevents an independent pass. One game-practice pass creates a candidate, not “fully learned.” New game-practice records do not unlock assessed Army or listening requirements. A later pass recruits it. Recruited words remain on the spaced schedule; overdue ones rest rather than disappear.</p><p class="mini">“Recruited” is a study achievement, not a claim of permanent retention, perfect pronunciation, a certified listening/transcription score, or an ILR rating. No public penalty for a failed extraction. Same-day repetitions cannot farm recruitment credit.</p></section>${renderTrial()}${trial?.mode==='army'&&!trial.checked&&!trial.revealed?'<section class="card"><h2>Roster hidden during this trial</h2><p>Finish or close the trial to see word answers.</p></section>':`<section class="card"><h2>Roster</h2><div class="roster">${Object.entries(state.rpg.army).filter(([id])=>byId[id]&&matchesScope(byId[id],trialFilter)).map(([id,a])=>`<article><div class="tagrow">${badge(shadowRecruited46(a)?(a.recruited?'Legacy recruit':'Practice recruit'):shadowCandidate46(a)?'Candidate':'Practice needed',a.recruited?'blue':'grey')}${a.recruited&&rec(id).due<=day()?badge('Resting · review due','amber'):''}</div><div class="ar" lang="ar">${esc(byId[id].speech)}</div><p>${esc(byId[id].meaningDisplay)}</p><small>${shadowPracticeDates46(a)} game-practice dates · ${a.passes?.length||0} legacy dates</small>${vbutton('trial-specific','Verify / strengthen',`data-id="${id}"`,'small')}</article>`).join('')||'<p class="empty">Your first candidate begins after one successful independent extraction.</p>'}</div></section>`}`;}
function renderQuests(){const s=state.rpg.skills.filter(e=>e.correct&&!e.assisted&&!e.planning),intro=activeItems().filter(x=>hasIntroduced(x.id)).length;return heading('Gatehouse','Shared objectives, individual questions. No student needs to be the strongest at every skill.')+xpPanel()+`<section class="card"><h2>Cooperative gates</h2><p>Each player has a nickname, a selected role, and a vocabulary pool from their own progress. Everyone must contribute. Higher gate ranks add rounds and team size, not a secret jump to advanced Arabic.</p><div class="gateGrid">${DATA.rankRules.map(g=>`<div class="gateTier"><b>${g.rank}</b><span>${g.players}+ players</span><small>${g.rounds} objective(s) each</small></div>`).join('')}</div><div class="actions spacer"><a class="buttonlink primary" href="gates.html">Enter co-op lobby</a><a class="buttonlink" href="Multiplayer_Guide.html" target="_blank">How shared play works</a></div><p class="mini">Pass-and-play runs immediately on one device. Live multi-device rooms require the included local-network server. This ZIP is not an already-hosted public service. Live room data is session-only, opt-in and nickname-based.</p></section><section class="card"><h2>Choose a role, keep all skills growing</h2><div class="grid three">${DATA.roles.map(r=>`<article class="role"><h3>${esc(r.name)} <small>· ${esc(r.fantasy)}</small></h3><b>${esc(r.task)}</b><p>${esc(r.description)}</p><small>${skillStats(r.id).n>=5?skillStats(r.id).p+'% · '+skillStats(r.id).n+' attempts':'Not enough evidence to rank this skill'}</small></article>`).join('')}</div><p class="mini">Recommendations use recent recorded accuracy with at least five attempts. Role choice is voluntary. Every third higher-rank round switches to a weaker recorded skill. Speaking requires partner review; no fake pronunciation scoring.</p></section>
 <section class="card"><h2>Optional unlocks</h2><div class="grid three">${[['Memory Relay',intro>=5,'TE','Introduce 5 groups','Short meaning-retrieval trials.'],['Signal Chamber',assessmentAudioAvailable46()&&s.filter(e=>e.mode==='L'||e.mode==='T').length>=5,'L',assessmentAudioAvailable46()?'Pass 5 listening/transcription trials':'Approved listening unavailable · reading practice remains open','Hear without seeing the answer.'],['Rune Forge',assessmentAudioAvailable46()&&nArmy()>=3,'T',assessmentAudioAvailable46()?'Recruit 3 words':'Approved transcription audio unavailable · reading practice remains open','Spell already-introduced words from sound.']].map(([title,open,mode,req,desc])=>`<article class="role"><h3>${open?title:'Locked challenge'}</h3><p>${open?desc:req}</p>${vbutton('game-start',open?'Play':'Not unlocked',`data-mode="${mode}" ${open?'':'disabled'}`,'small')}</article>`).join('')}</div><p class="mini">No essential vocabulary, speaking model, mock or review tool is locked behind a game. Unlocks add optional practice only.</p></section><section class="card"><h2>Direct skill practice</h2><p>${vbutton('focus-practice','Use my attribute-point focus','','primary')} <span class=mini>Points weight the next practice skill; they do not change correctness.</span></p><div class="toolbar"><label>Unit / chapter<select id="trialScope">${scopeOptions(trialFilter)}</select></label>${['TE','TA','L','T'].map(m=>vbutton('skill-start',MODES[m],`data-mode="${m}"`)).join('')}</div><p class="mini">Word-form translation trials accept the displayed study sense. Free speaking and sentence translations are not reliably machine-graded; use the separate speaking model/rubric.</p></section>${trial&&trial.mode!=='army'?renderTrial():''}`;}
function nArmy(){return masteryCount();}
function unitMetrics(u){const items=activeItems().filter(x=>knownChapters(x).some(c=>Math.ceil(c/5)===u));return {total:items.length,intro:items.filter(x=>hasIntroduced(x.id)).length,learned:items.filter(x=>learningRec(x.id).learned||rec(x.id).firstRetrieved).length,first:items.filter(x=>rec(x.id).firstRetrieved).length,stable:items.filter(x=>stable(rec(x.id))).length,army:masteryCount(u)};}
function skillTable(){return `<div class="tablewrap"><table><thead><tr><th>Unit</th><th>Introduced</th><th>First retrieval</th><th>Spaced recall</th><th>Army</th>${Object.values(MODES).map(m=>`<th>${m}</th>`).join('')}</tr></thead><tbody>${[1,2,3].map(u=>{const x=unitMetrics(u);return `<tr><td><b>Unit ${u}</b><br><small>${x.total} applicable groups</small></td><td>${percent(x.intro,x.total)}%<br><small>${x.intro}/${x.total}</small></td><td>${percent(x.first,x.total)}%</td><td>${percent(x.stable,x.total)}%</td><td>${percent(x.army,x.total)}%</td>${Object.keys(MODES).map(m=>{const s=skillStats(m,u);return `<td>${s.p===null?'—':s.p+'%'}<br><small>n=${s.n}${s.partner?' · '+s.partner+' partner':''}${s.self?' · '+s.self+' self':''}</small></td>`}).join('')}</tr>`;}).join('')}</tbody></table></div>`;}
function snapshot(){return {format:'ICPT_TEAM_SNAPSHOT_V3',at:new Date().toISOString(),nickname:(state.rpg.nickname||'Anonymous').slice(0,24),xp:state.rpg.xp,rank:rankInfo().rank,army:masteryCount(),units:[1,2,3].map(u=>({unit:u,...unitMetrics(u),skills:Object.fromEntries(Object.keys(MODES).map(m=>[m,skillStats(m,u)]))})),source:'local self/automatic/partner practice; not official grades'};}
renderProgress = function(){const base=oldRenderProgress();return heading('Your skill profile—not just a coverage counter.','Percentages retain their denominator and evidence type. Small samples stay visible; XP never changes an accuracy score.')+xpPanel()+`<section class="card"><div class="toolbar"><label>Public nickname (optional)<input id="nickname" maxlength="24" value="${esc(state.rpg.nickname)}" placeholder="Use a nickname, not a service ID"></label>${vbutton('save-name','Save nickname')}${vbutton('export-snapshot','Export class-comparison snapshot')}${vbutton('import-peer','Import classmate snapshot')}</div><p class="mini">Only a deliberately exported snapshot shares nickname and aggregate statistics. It contains no wrong answers, personal notes or recordings. A snapshot board is not live; shared rooms are live only while the host runs.</p><h2>Unit × modality</h2>${skillTable()}<p class="mini">Accuracy uses the latest 40 eligible scored events per skill/unit, excluding assisted and planning-date trials. Ordinary self-rated flashcards do not create automatic test accuracy. — means no evidence, not 0%. Coverage percentages use unique applicable study groups; groups can belong to more than one unit.</p></section>
 <section class="card"><h2>Class comparison · optional snapshots</h2><div class="tablewrap"><table><thead><tr><th>Nickname</th><th>Rank / XP</th><th>Army</th><th>U1 introduced</th><th>U2 introduced</th><th>U3 introduced</th><th>Updated</th></tr></thead><tbody>${[snapshot(),...state.rpg.peers].sort((a,b)=>b.xp-a.xp).map(p=>`<tr><td>${esc(p.nickname)}</td><td>${esc(p.rank)} · ${Number(p.xp)||0}</td><td>${Number(p.army)||0}</td>${[1,2,3].map(u=>{const s=p.units?.find(x=>x.unit===u);return `<td>${s?percent(s.intro,s.total)+'%':'—'}</td>`}).join('')}<td>${esc(p.at?.slice(0,10)||'')}</td></tr>`).join('')}</tbody></table></div><p class="mini">Voluntary study snapshots can be edited by their owner and are not a secure grading system. No real classmate data is preloaded.</p></section>
 <section class="card"><h2>Attribute points · focus, not a score boost</h2><p>Each 100 XP grants one planning point. Allocate points to a skill to emphasize it in solo practice. Points do not improve measured accuracy or bypass gate requirements.</p><div class="actions">${Object.entries(MODES).map(([m,t])=>vbutton('allocate',t+' · '+(state.rpg.points[m]||0),`data-mode="${m}"`,'small')).join('')}</div><p class="mini">Unallocated: ${Math.max(0,Math.floor(state.rpg.xp/100)-Object.values(state.rpg.points).reduce((a,b)=>a+b,0))}</p></section>`+base;
}
renderSettings = function(){let s=oldRenderSettings().replace('Revision 2 —','Revision 3 —').replace('Version 1 progress exports','Version 1–3 progress exports');s=s.replace(/<label class="checkline"><input id="includeSupp"[\s\S]*?<\/label>/,'<p><b>All 125 Quizlet entries are included in v3; matching words share schedules.</b></p>').replace(/<label class="checkline"><input type="checkbox" id="includeMem"[\s\S]*?<\/label>/,'<p><b>All 267 Memrise entries are included in v3.</b></p>');return `<section class="card"><h2>Theme and multiplayer</h2><div class="actions">${vbutton('theme','Gate theme',`data-theme="gate"`)}${vbutton('theme','Calm theme',`data-theme="calm"`)}<a href="gates.html">Co-op lobby</a><a href="Multiplayer_Guide.html">Host instructions</a></div><p class="mini">Gate ranks are game tiers, never ILR ratings. Source-specific pronunciation checks remain transparent. The linked Memrise courses require sign-in; no claim is made that their audio was retrieved.</p></section>`+s;}
renderSpeaking = function(){return oldRenderSpeaking()+`<section class="card"><h2>Optional partner-checked speaking event</h2><p>After an independent response, a partner can confirm whether the task was understandable, relevant, and sustained with mostly correct pronouns/time frames. This is practice evidence, not automatic speech recognition.</p>${vbutton('speaking-event','Partner: task met',`data-correct="1"`)}${vbutton('speaking-event','Partner: repair target',`data-correct="0"`)}<p class="mini">No recording leaves this browser. Reading the six-sentence model aloud is supported practice, not an independent speaking pass.</p></section>`;}
function downloadJson(obj,name){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),5000);}
bindSpecial = function(){oldBind();const on=(id,ev,fn)=>{const e=$(id);if(e)e.addEventListener(ev,fn);};on('trialScope','change',e=>{trialFilter=e.target.value;trial=null;render();});document.querySelectorAll('.teacherBoost').forEach(e=>e.addEventListener('change',async ev=>{state.settings.keyBoost[ev.target.dataset.id]=Math.max(0,Math.min(5,+ev.target.value||0));const prioritySaved=await vocabSave47.flush();toast(prioritySaved?'Teacher emphasis saved; future uncompleted ordering uses this priority.':'Teacher emphasis changed in this open page. Could not verify saving. Use Save & recovery to retry or export before leaving.');}));}
// Preserve transient typed inputs during asynchronous playback/render updates.
document.addEventListener('input',e=>{if(e.target.id==='trialSpell'&&trial&&!window.GH_HINT_REWARDS5?.isStaleTrial(trial))trial.spell=e.target.value;if(e.target.id==='trialMeaning'&&trial&&!window.GH_HINT_REWARDS5?.isStaleTrial(trial))trial.meaning=e.target.value;if(e.target.id==='learnInput'&&trainer&&!window.GH_HINT_REWARDS5?.isStaleTrainer(trainer))trainer.input=e.target.value;});
let vocabActionPending47=false;
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-v3]');if(!b||b.disabled)return;e.preventDefault();const a=b.dataset.v3;const x=trainer&&trainer.i<trainer.queue.length?byId[trainer.queue[trainer.i]]:null;
 if(['learn-hide','train-play','train-check','audit-known','audit-new','learn-pass','learn-again','retrieve-rate','train-toggle'].includes(a)&&window.GH_EXACT_ACTIVITY_GUARD?.reject?.(trainer))return;
 if(['learn-hide','train-play','train-check','audit-known','audit-new','learn-pass','learn-again','retrieve-rate','train-toggle'].includes(a)&&window.GH_HINT_REWARDS5?.rejectStaleTrainer(trainer,x))return;
 if(['trial-play','trial-submit','trial-hint','trial-next'].includes(a)&&window.GH_HINT_REWARDS5?.isStaleTrial(trial)){toast('Start a fresh trial for this hunter or restored profile. No answer was graded.');return;}
 if(vocabActionPending47)return;vocabActionPending47=true;try{switch(a){
 case'start-check':startSession('check');break;case'start-learn':startSession('learn');break;case'start-first':startSession('first');break;case'start-due':startSession('due');break;
 case'study':startSession('selection',[b.dataset.id]);break;
 case'learn-hide':trainer.phase='rehearse';trainer.revealed=false;trainer.input='';render();break;
 case'train-play':{if(!assessmentAudioAvailable46()){audioUnavailable46(['L','T'].includes(trainer.mode)?'assessment':'pronunciation');break;}const target=trainer,index=target.i,owner=target.responseOwner5;speakText(x.speech,()=>{if(trainer===target&&trainer.i===index&&owner===JSON.stringify([state._save45?.profileId||'',state._save45?.epoch||''])&&!window.GH_HINT_REWARDS5?.isStaleTrainer(trainer)){trainer.played=true;render();}});break;}
 case'train-check':if(['L','T'].includes(trainer.mode)&&!assessmentAudioAvailable46()){audioUnavailable46();break;}if(trainer.mode==='L'&&!trainer.played){toast('Listen to the model first.');break;}trainer.input=$('learnInput')?.value||trainer.input;trainer.auto=meaningOK(trainer.input,x);trainer.revealed=true;render();break;
 case'audit-known':if(window.GH_HINT_REWARDS5?.rejectStaleTrainer(trainer,x))break;state.checks[window.GH_EXACT_REVIEW_LINKS?.storageKey?.(x.id)||x.id]={date:day(),result:'familiar'};markIntro(x);if(await learnComplete(x,window.GH_HINT_REWARDS5?.trainerOrigin(x)))nextTrainer();break;
 case'audit-new':state.checks[window.GH_EXACT_REVIEW_LINKS?.storageKey?.(x.id)||x.id]={date:day(),result:'needs-learning'};if(await vocabSave47.flush())nextTrainer();break;
 case'learn-pass':{if(window.GH_HINT_REWARDS5?.rejectStaleTrainer(trainer,x))break;if(modeForItem(x)==='rehearsal'){nextTrainer();break;}const l=learningRec(x.id);l.reps=(l.reps||0)+1;state.learning[x.id]=l;if(l.reps>=2){if(await learnComplete(x,window.GH_HINT_REWARDS5?.trainerOrigin(x)))nextTrainer();}else{trainer.phase='prompt';trainer.revealed=false;trainer.input='';if(await vocabSave47.flush())render();}break;}
 case'learn-again':trainer.phase='prompt';trainer.revealed=false;trainer.input='';render();break;
 case'retrieve-rate':await updateRetrieval(x,b.dataset.rating,window.GH_HINT_REWARDS5?.trainerOrigin(x));break;
 case'train-toggle':trainer.mode=trainer.mode==='L'?'TE':'L';trainer.revealed=false;trainer.played=false;trainer.input='';render();break;
 case'end-trainer':if(!(await vocabSave47.flush()))break;window.GH457_AUDIO_QUEUE?.cancel?.('study exited');trainer=null;stopSpeech();go('today');break;
 case'say-model':{const item=byId[b.dataset.id];if(item)window.GH457_AUDIO?.showStatus?.({id:item.id,text:item.speech,kind:'vocabulary'});break;}
 case'say-form':{const item=byId[b.dataset.id],form=item?.ling?.forms?.[Number(b.dataset.index)];if(form)window.GH457_AUDIO?.showStatus?.({id:item.id,text:form.ar,kind:'vocabulary'});break;}
 case'open-gates':trial=null;go('quests');break;case'open-army':trial=null;go('army');break;
 case'army-start':chooseTrial('army');break;case'skill-start':chooseTrial(b.dataset.mode);break;case'game-start':chooseTrial(b.dataset.mode,'unlock');break;
 case'trial-specific':{const id=canonicalId(b.dataset.id),a=state.rpg.army[id];if(shadowCooldown46(a)>Date.now()){toast('Practice now; this extraction retry is available in '+Math.ceil((shadowCooldown46(a)-Date.now())/60000)+' minute(s).');break;}trial={id,mode:'army',played:false,checked:false,spell:'',meaning:'',assisted:false,responseOwner5:JSON.stringify([state._save45?.profileId||'',state._save45?.epoch||'']),token:crypto.randomUUID?.()||String(Date.now())};render();break;}
 case'trial-choice':{if(trial?.mode!=='army'||!shadowCurrent46(trial)||!trial.played)break;const p=shadowPlan46(trial),o=p.options[Number(b.dataset.choice)];if(p.mode==='source-choice'&&o){trial.shadowChoice46=o.key;render();}break;}
 case'trial-play':heardTrial();break;case'trial-submit':await certifyTrial();break;
 case'trial-hint':shadowStop46('Answer revealed');trial.assisted=true;trial.revealed=true;render();break;
 case'trial-next':chooseTrial(trial.mode,trial.game);break;case'trial-close':shadowStop46('Trial closed');trial=null;render();break;
 case'save-name':state.rpg.nickname=$('nickname').value.trim().slice(0,24);if(await vocabSave47.flush())render();break;
 case'export-snapshot':downloadJson(snapshot(),'ICPT_class_snapshot.json');break;
 case'import-peer':{const input=document.createElement('input');input.type='file';input.accept='.json';input.onchange=async()=>{try{const p=JSON.parse(await input.files[0].text());if(p.format!=='ICPT_TEAM_SNAPSHOT_V3'||!Array.isArray(p.units)||p.units.length!==3)throw Error('Not a v3 team snapshot.');state.rpg.peers=state.rpg.peers.filter(x=>x.nickname!==p.nickname);state.rpg.peers.push(p);state.rpg.peers=state.rpg.peers.slice(-40);if(await vocabSave47.flush())render();}catch(er){toast(er.message);}};input.click();break;}
 case'focus-practice':{const pool=Object.keys(MODES).flatMap(m=>Array(1+(state.rpg.points[m]||0)).fill(m));const mode=pool[Math.floor(Math.random()*pool.length)];if(mode==='S'){go('speaking');toast('Focus selected: speaking. Use an independent prompt and a partner rubric.');}else if(mode==='R'){mockView='chapter';go('mocks');toast('Focus selected: reading. Choose a chapter you have studied.');}else chooseTrial(mode);break;}
 case'allocate':{
 const mode=b.dataset.mode,usable=p=>p&&typeof p==='object'&&!Array.isArray(p)&&Object.values(p).every(v=>v==null||(typeof v==='number'&&Number.isFinite(v)&&Number.isInteger(v)&&v>=0));
 if(!Object.hasOwn(MODES,mode)){toast('That focus skill is unavailable. No point was allocated.');break;}
 if(!usable(state.rpg.points)){toast('Focus allocations are unfamiliar. Export a full recovery backup before changing them.');break;}
 // Refresh through the durable merge so unrelated unsaved work is retained.
 if(!(await vocabSave47.flush())){toast('Focus allocation was not started because saving could not be verified. Export a full backup before leaving.');break;}
 if(!usable(state.rpg.points)){toast('Current focus allocations are unfamiliar. Existing progress was kept; export a full recovery backup.');break;}
 const used=Object.values(state.rpg.points).reduce((n,v)=>n+(v||0),0);
 if(used>=Math.floor(state.rpg.xp/100)){toast('No unallocated focus points remain. Current saved allocations are shown.');render();break;}
 const requested=(state.rpg.points[mode]||0)+1;state.rpg.points[mode]=requested;
 const saved=await vocabSave47.flush();
 if(!saved){toast('The focus-point save could not be verified. Keep a full recovery export and reload before trying again.');break;}
 render();if((state.rpg.points[mode]||0)<requested)toast('That point was allocated in another tab. Current saved allocations are shown.');
 break;}
 case'theme':state.settings.theme=b.dataset.theme;if(await vocabSave47.flush())render();break;
 case'speaking-event':{const c=+speakingId.slice(-2),id=DATA.vocab.find(x=>x.chapter===c)?.id;if(confirm('Confirm a real partner reviewed an independent response, without reading the model.')){skillEvent(id,'S',b.dataset.correct==='1','partner');if(!(await vocabSave47.flush()))break;toast('Partner-rated speaking evidence saved separately.');}break;}
 }}finally{vocabActionPending47=false;}
});
// Import/export keeps the legacy storage key; defaults added after imports before first render.
const baseRender=render;render=function(){state.rpg??={nickname:'',xp:0,awards:{},skills:[],army:{},points:{},peers:[],unlocked:{}};state.learning??={};state.checks??={};state.settings.keyBoost??={};state.settings.supplement=true;state.settings.memrise=true;return baseRender();};
// Credit completed legacy mock questions to the measured R/L skills once, never by merely opening a test.
function ingestMocks(){state.rpg.mockIngest??={};for(const a of state.attempts){const key=a.id||a.finishedAt||a.name+'|'+a.date;if(state.rpg.mockIngest[key])continue;state.rpg.mockIngest[key]=true;if(a.assisted)continue;for(const q of a.questions||[]){const ch=q.chapter,id=DATA.vocab.find(x=>x.chapter===ch)?.id;if(!id)continue;const right=a.answers?.[q.id]===q.correct;state.rpg.skills.push({id,mode:a.modality,correct:right,kind:'automatic mock',assisted:false,date:a.date,at:Date.now(),chapters:[ch],planning:a.date!==localDay()});}}}
const beforeProgress=renderProgress;renderProgress=function(){if(state.active&&!durableActiveMatches(state.active.id))return heading('Progress unavailable','This mock changed in another tab or could not be verified. Reload before reviewing results.');const before=JSON.stringify(state);ingestMocks();if(JSON.stringify(state)!==before)vocabSave47.background();return beforeProgress();};
// Portable linkage used by the separate co-op lobby. Only aggregate summaries are shared automatically on join.
window.ICPT_V3={snapshot,spellingNorm,englishNorm,glosses,meaningOK,skillStats,unitMetrics,hasIntroduced,rankInfo,activeItems,canonicalId,chooseTrial,getState:()=>state,save};

const computePlanV3=planMap;let planCacheV3={key:'',map:null};planMap=function(){const k=JSON.stringify([EXAM,effectiveDailyCalendar46(),state.settings.buffer,state.settings.release,state.settings.keyBoost]);if(k!==planCacheV3.key){planCacheV3={key:k,map:computePlanV3()};}return planCacheV3.map;};
// Recruitment cooldown and calendar preview cannot create a certified pass.
const pickTrialV3=chooseTrial;chooseTrial=function(mode='army',game=''){const eligible=trialPool().filter(x=>mode!=='army'||!(shadowCooldown46(state.rpg.army[x.id])>Date.now()));if(!eligible.length){toast('No eligible trial now. Review introduced words; extraction cooldown is ten minutes.');return;}pickTrialV3(mode,game);if(mode==='army'&&shadowCooldown46(state.rpg.army[trial.id])>Date.now()){trial.id=eligible[Math.floor(Math.random()*eligible.length)].id;render();}};
const certifyV3=certifyTrial;certifyTrial=async function(){if(day()!==localDay()){toast('Switch to the actual local date to record assessed skill or recruitment. Preview dates are for planning only.');return;}return await certifyV3();};
render();getLocalAudio();vocabSave47.background();
window.ICPT_QA={...window.ICPT_QA,DATA,planMap,firstQueue,learnQueue,checkQueue,dueItems,newItems,unitMetrics,getTrainer:()=>trainer,getTrial:()=>trial,getState:()=>state,render,startSession,skillEvent,chooseTrial,setDate:d=>{state.settings.studyDate=d;render();}};

/* Sequence 3 calendar sidebar binding; leaves index and save core unchanged. */
function renderCalendarTargetTop46(){
 const w=window.GH_CALENDAR_TARGET46,m=w.target({profile:state,today:day(),exams:window.GH_CLASS_EXAMS46});
 const t=$('topMeta'); if(!t)return;
 const select='<label for="ghCalendarTargetMode46">Exam plan mode</label><select id="ghCalendarTargetMode46">'+(m.mode==='legacy'?'<option value="legacy" selected>Keep current saved date</option>':'')+'<option value="manual"'+(m.mode==='manual'?' selected':'')+'>Use saved date</option><option value="preset"'+(m.mode==='preset'?' selected':'')+'>Next confirmed ICPT</option></select>';
 const status=m.badBuffer?'Saved review buffer requires checking.':!m.date?'No matching confirmed ICPT date.':(m.label||'Planning RC/LC')+': '+m.date+(m.time?' at '+m.time+' local':'')+' · '+(m.daysAway<0?'passed':m.daysAway+' days away')+' · first pass through '+m.cutoff;
 t.innerHTML='<strong>'+esc(status)+'</strong><br>'+select+(m.mode==='preset'?'<p class="mini">The next scheduled class is prioritized when available. Existing saved assignments stay unchanged.</p>':'');
 const control=$('ghCalendarTargetMode46');
 if(control)control.onchange=async()=>{
  const val=control.value;if(val!=='manual'&&val!=='preset')return;
  control.disabled=true;
  try{const saved=await persistCoreChange46(next=>{next.v4??={};next.v4.calendarTarget46={mode:val};});if(saved&&typeof render==='function'&&control.isConnected)render();}
  finally{if(control.isConnected){control.value=w.mode(state);control.disabled=false;}}
 };
}



const navBeforeCalendarSeq3 = nav;
nav=function(){
 const result=navBeforeCalendarSeq3.apply(this,arguments);
 const stale=document.querySelector('#nav[aria-label="Study sections"]')?.previousElementSibling;
 if(stale?.classList.contains('subtitle')&&stale.textContent.trim()==='Units 1–3 · Chapters 01–15')stale.remove();
 renderCalendarTargetTop46();
 return result;
};
if(!window.GH457_STARTUP?.shouldDeferRender()&&document.getElementById('nav'))nav();
