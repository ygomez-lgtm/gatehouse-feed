/* Isolated shared cancellation coordinator; no profile writes or automatic sound. */
(function(W){'use strict';if(W.GH_SOURCE_PLAYBACK_BROKER)return;let current=null,serial=0;
function stop(reason){const old=current;current=null;serial++;if(old)try{old.stop(reason);}catch{}}
function claim(owner,stopper){if(typeof stopper!=='function')return null;stop('Another source recording was selected');const token=++serial;current={owner,stop:stopper,token};return token;}
function claimIfIdle(owner,stopper){if(current)return null;return claim(owner,stopper);}
function release(token){if(current?.token===token)current=null;}
function isCurrent(token){return current?.token===token;}
// Preserve every existing queue method and its original scheduling/guard semantics.
for(const name of ['GH457_AUDIO_QUEUE','GH457_AUDIO']){const prior=W[name];if(!prior)continue;const wrapped={...prior};for(const key of ['play','replay','select','stop','cancel','stopOtherForQueue','setStudySet'])if(typeof prior[key]==='function')wrapped[key]=function(...args){stop('Existing audio controls used');return prior[key].apply(prior,args);};if(name==='GH457_AUDIO_QUEUE'&&typeof prior.onAnswer==='function')wrapped.onAnswer=function(...args){if(current)return Promise.resolve({ok:false,reason:'Stale answer after another source took playback ownership'});return prior.onAnswer.apply(prior,args);};W[name]=Object.freeze(wrapped);}
W.GH_SOURCE_PLAYBACK_BROKER=Object.freeze({claim,claimIfIdle,stop,release,isCurrent});
W.addEventListener?.('pagehide',()=>stop('Page closed'));
W.document?.addEventListener?.('visibilitychange',()=>{if(W.document.hidden)stop('Page hidden');});
})(typeof window==='object'?window:globalThis);
